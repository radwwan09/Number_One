﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Home
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.TabControl6 = New System.Windows.Forms.TabControl()
        Me.TabPage15 = New System.Windows.Forms.TabPage()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.ComboBox25 = New System.Windows.Forms.ComboBox()
        Me.TextBox39 = New System.Windows.Forms.TextBox()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.TextBox40 = New System.Windows.Forms.TextBox()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.TextBox41 = New System.Windows.Forms.TextBox()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.txt_U = New System.Windows.Forms.TextBox()
        Me.DataGridView8 = New System.Windows.Forms.DataGridView()
        Me.TabPage16 = New System.Windows.Forms.TabPage()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.DataGridView13 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button51 = New System.Windows.Forms.Button()
        Me.Button52 = New System.Windows.Forms.Button()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.DataGridView12 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button49 = New System.Windows.Forms.Button()
        Me.Button50 = New System.Windows.Forms.Button()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.DataGridView11 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button47 = New System.Windows.Forms.Button()
        Me.Button48 = New System.Windows.Forms.Button()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.DataGridView10 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.DataGridView9 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.dgvQl = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.dgvPl = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.TabControl5 = New System.Windows.Forms.TabControl()
        Me.TabPage13 = New System.Windows.Forms.TabPage()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.TextBox34 = New System.Windows.Forms.TextBox()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.DateTimePicker14 = New System.Windows.Forms.DateTimePicker()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.DateTimePicker13 = New System.Windows.Forms.DateTimePicker()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.txt_C = New System.Windows.Forms.TextBox()
        Me.DataGridView6 = New System.Windows.Forms.DataGridView()
        Me.TabPage14 = New System.Windows.Forms.TabPage()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.TextBox37 = New System.Windows.Forms.TextBox()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.ComboBox24 = New System.Windows.Forms.ComboBox()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.TextBox36 = New System.Windows.Forms.TextBox()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.txt_T = New System.Windows.Forms.TextBox()
        Me.DataGridView7 = New System.Windows.Forms.DataGridView()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TabControl4 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.txt_mang = New System.Windows.Forms.TextBox()
        Me.DataGridView4 = New System.Windows.Forms.DataGridView()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.DateTimePicker12 = New System.Windows.Forms.DateTimePicker()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.ComboBox23 = New System.Windows.Forms.ComboBox()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.txt_dep = New System.Windows.Forms.TextBox()
        Me.DataGridView5 = New System.Windows.Forms.DataGridView()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TabControl3 = New System.Windows.Forms.TabControl()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Emp_name_A = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Emp_id_A = New System.Windows.Forms.TextBox()
        Me.Day_Emergency_A = New System.Windows.Forms.TextBox()
        Me.Day_Annual_A = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.H_type_A = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.H_end_A = New System.Windows.Forms.DateTimePicker()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.H_start_A = New System.Windows.Forms.DateTimePicker()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Emp_name_E = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Emp_id_E = New System.Windows.Forms.TextBox()
        Me.Day_Emergency_E = New System.Windows.Forms.TextBox()
        Me.Day_Annual_E = New System.Windows.Forms.TextBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.H_type_E = New System.Windows.Forms.ComboBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.H_end_E = New System.Windows.Forms.DateTimePicker()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.H_start_E = New System.Windows.Forms.DateTimePicker()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TabPage12 = New System.Windows.Forms.TabPage()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txt_H = New System.Windows.Forms.TextBox()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.Emp_P = New System.Windows.Forms.TabPage()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Dep_A = New System.Windows.Forms.ComboBox()
        Me.Country_A = New System.Windows.Forms.ComboBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Getting_date_A = New System.Windows.Forms.DateTimePicker()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Costing_A = New System.Windows.Forms.ComboBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Qual_A = New System.Windows.Forms.ComboBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Spec_A = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Cer_id_A = New System.Windows.Forms.TextBox()
        Me.Fun_Level_A = New System.Windows.Forms.ComboBox()
        Me.Job_n_A = New System.Windows.Forms.ComboBox()
        Me.Annual_A = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Data_direct_A = New System.Windows.Forms.DateTimePicker()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Fun_Deg_A = New System.Windows.Forms.ComboBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Emergency_A = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Data_original_A = New System.Windows.Forms.DateTimePicker()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Birth_Place_A = New System.Windows.Forms.ComboBox()
        Me.Conf_Id_A = New System.Windows.Forms.TextBox()
        Me.Emp_Id = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Email_A = New System.Windows.Forms.TextBox()
        Me.Emp_Name = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Phone_A = New System.Windows.Forms.TextBox()
        Me.Emp_M_A = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Address_A = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Emp_NW_A = New System.Windows.Forms.TextBox()
        Me.Nationa_A = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Conf_Type_A = New System.Windows.Forms.ComboBox()
        Me.Gender_A = New System.Windows.Forms.ComboBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Birth_Data_A = New System.Windows.Forms.DateTimePicker()
        Me.Social_Case_A = New System.Windows.Forms.ComboBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Dep_id_E = New System.Windows.Forms.ComboBox()
        Me.Country_E = New System.Windows.Forms.ComboBox()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Getting_date_E = New System.Windows.Forms.DateTimePicker()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Costing_E = New System.Windows.Forms.ComboBox()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Qual_E = New System.Windows.Forms.ComboBox()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Spec_E = New System.Windows.Forms.ComboBox()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Cer_id_E = New System.Windows.Forms.TextBox()
        Me.Fun_Level_E = New System.Windows.Forms.ComboBox()
        Me.Job_E = New System.Windows.Forms.ComboBox()
        Me.Annual_E = New System.Windows.Forms.TextBox()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Data_direct_E = New System.Windows.Forms.DateTimePicker()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Fun_Deg_E = New System.Windows.Forms.ComboBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Emergency_E = New System.Windows.Forms.TextBox()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Data_original_E = New System.Windows.Forms.DateTimePicker()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Birth_Place_E = New System.Windows.Forms.ComboBox()
        Me.Conf_id_E = New System.Windows.Forms.TextBox()
        Me.emp_E = New System.Windows.Forms.TextBox()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Email_E = New System.Windows.Forms.TextBox()
        Me.e_name_E = New System.Windows.Forms.TextBox()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Phon_E = New System.Windows.Forms.TextBox()
        Me.emp_m_E = New System.Windows.Forms.TextBox()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Address_E = New System.Windows.Forms.TextBox()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.emp_NW_E = New System.Windows.Forms.TextBox()
        Me.Nationa_E = New System.Windows.Forms.TextBox()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Conf_type_E = New System.Windows.Forms.ComboBox()
        Me.Gender_E = New System.Windows.Forms.ComboBox()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Birth_date_E = New System.Windows.Forms.DateTimePicker()
        Me.Social_case_E = New System.Windows.Forms.ComboBox()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Family_Serah = New System.Windows.Forms.TextBox()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.TabPage17 = New System.Windows.Forms.TabPage()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_Emp = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.Button53 = New System.Windows.Forms.Button()
        Me.TabPage6.SuspendLayout()
        Me.TabControl6.SuspendLayout()
        Me.TabPage15.SuspendLayout()
        Me.Panel10.SuspendLayout()
        CType(Me.DataGridView8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage16.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        CType(Me.DataGridView13, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox10.SuspendLayout()
        CType(Me.DataGridView12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox9.SuspendLayout()
        CType(Me.DataGridView11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox8.SuspendLayout()
        CType(Me.DataGridView10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        CType(Me.DataGridView9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        CType(Me.dgvQl, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.dgvPl, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        Me.TabControl5.SuspendLayout()
        Me.TabPage13.SuspendLayout()
        Me.Panel8.SuspendLayout()
        CType(Me.DataGridView6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage14.SuspendLayout()
        Me.Panel9.SuspendLayout()
        CType(Me.DataGridView7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.TabControl4.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.Panel7.SuspendLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.TabControl3.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Emp_P.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.TabControl6)
        Me.TabPage6.Location = New System.Drawing.Point(4, 26)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(1199, 740)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "المستخدم"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'TabControl6
        '
        Me.TabControl6.Controls.Add(Me.TabPage15)
        Me.TabControl6.Controls.Add(Me.TabPage16)
        Me.TabControl6.Location = New System.Drawing.Point(3, 3)
        Me.TabControl6.Name = "TabControl6"
        Me.TabControl6.RightToLeftLayout = True
        Me.TabControl6.SelectedIndex = 0
        Me.TabControl6.Size = New System.Drawing.Size(1190, 731)
        Me.TabControl6.TabIndex = 0
        '
        'TabPage15
        '
        Me.TabPage15.Controls.Add(Me.Button53)
        Me.TabPage15.Controls.Add(Me.Button38)
        Me.TabPage15.Controls.Add(Me.Button33)
        Me.TabPage15.Controls.Add(Me.Panel10)
        Me.TabPage15.Controls.Add(Me.Button36)
        Me.TabPage15.Controls.Add(Me.Button37)
        Me.TabPage15.Controls.Add(Me.Label98)
        Me.TabPage15.Controls.Add(Me.txt_U)
        Me.TabPage15.Controls.Add(Me.DataGridView8)
        Me.TabPage15.Location = New System.Drawing.Point(4, 26)
        Me.TabPage15.Name = "TabPage15"
        Me.TabPage15.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage15.Size = New System.Drawing.Size(1182, 701)
        Me.TabPage15.TabIndex = 0
        Me.TabPage15.Text = "المستخدمون"
        Me.TabPage15.UseVisualStyleBackColor = True
        '
        'Button38
        '
        Me.Button38.Location = New System.Drawing.Point(385, 334)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(116, 36)
        Me.Button38.TabIndex = 24
        Me.Button38.Text = "الغاء"
        Me.Button38.UseVisualStyleBackColor = True
        '
        'Button33
        '
        Me.Button33.Location = New System.Drawing.Point(507, 334)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(116, 36)
        Me.Button33.TabIndex = 23
        Me.Button33.Text = "حذف"
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel10.Controls.Add(Me.Label103)
        Me.Panel10.Controls.Add(Me.ComboBox25)
        Me.Panel10.Controls.Add(Me.TextBox39)
        Me.Panel10.Controls.Add(Me.Label102)
        Me.Panel10.Controls.Add(Me.TextBox40)
        Me.Panel10.Controls.Add(Me.Label104)
        Me.Panel10.Controls.Add(Me.Button34)
        Me.Panel10.Controls.Add(Me.Button35)
        Me.Panel10.Controls.Add(Me.TextBox41)
        Me.Panel10.Controls.Add(Me.Label106)
        Me.Panel10.Location = New System.Drawing.Point(63, 398)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(1067, 204)
        Me.Panel10.TabIndex = 22
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label103.Location = New System.Drawing.Point(389, 81)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(47, 22)
        Me.Label103.TabIndex = 19
        Me.Label103.Text = "الصفة"
        '
        'ComboBox25
        '
        Me.ComboBox25.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox25.FormattingEnabled = True
        Me.ComboBox25.Location = New System.Drawing.Point(194, 81)
        Me.ComboBox25.Name = "ComboBox25"
        Me.ComboBox25.Size = New System.Drawing.Size(179, 28)
        Me.ComboBox25.TabIndex = 18
        '
        'TextBox39
        '
        Me.TextBox39.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox39.Location = New System.Drawing.Point(546, 78)
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.Size = New System.Drawing.Size(349, 29)
        Me.TextBox39.TabIndex = 17
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label102.Location = New System.Drawing.Point(901, 81)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(50, 22)
        Me.Label102.TabIndex = 16
        Me.Label102.Text = "الايميل"
        '
        'TextBox40
        '
        Me.TextBox40.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox40.Location = New System.Drawing.Point(117, 24)
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(256, 29)
        Me.TextBox40.TabIndex = 15
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label104.Location = New System.Drawing.Point(379, 27)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(83, 22)
        Me.Label104.TabIndex = 14
        Me.Label104.Text = "كلمة المرور"
        '
        'Button34
        '
        Me.Button34.BackColor = System.Drawing.Color.White
        Me.Button34.Location = New System.Drawing.Point(416, 145)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(116, 36)
        Me.Button34.TabIndex = 9
        Me.Button34.Text = "الغاء"
        Me.Button34.UseVisualStyleBackColor = False
        '
        'Button35
        '
        Me.Button35.BackColor = System.Drawing.Color.White
        Me.Button35.Location = New System.Drawing.Point(550, 145)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(116, 36)
        Me.Button35.TabIndex = 9
        Me.Button35.Text = "حفظ"
        Me.Button35.UseVisualStyleBackColor = False
        '
        'TextBox41
        '
        Me.TextBox41.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox41.Location = New System.Drawing.Point(546, 29)
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.Size = New System.Drawing.Size(349, 29)
        Me.TextBox41.TabIndex = 1
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label106.Location = New System.Drawing.Point(901, 32)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(95, 22)
        Me.Label106.TabIndex = 0
        Me.Label106.Text = "اسم المستخدم"
        '
        'Button36
        '
        Me.Button36.Location = New System.Drawing.Point(629, 334)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(116, 36)
        Me.Button36.TabIndex = 21
        Me.Button36.Text = "تعديل"
        Me.Button36.UseVisualStyleBackColor = True
        '
        'Button37
        '
        Me.Button37.Location = New System.Drawing.Point(751, 334)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(116, 36)
        Me.Button37.TabIndex = 20
        Me.Button37.Text = "اضافة مستخدم"
        Me.Button37.UseVisualStyleBackColor = True
        '
        'Label98
        '
        Me.Label98.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label98.Location = New System.Drawing.Point(782, 7)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(76, 35)
        Me.Label98.TabIndex = 6
        Me.Label98.Text = "بحث :"
        Me.Label98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_U
        '
        Me.txt_U.Location = New System.Drawing.Point(385, 13)
        Me.txt_U.Name = "txt_U"
        Me.txt_U.Size = New System.Drawing.Size(395, 24)
        Me.txt_U.TabIndex = 7
        Me.txt_U.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'DataGridView8
        '
        Me.DataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView8.Location = New System.Drawing.Point(146, 60)
        Me.DataGridView8.Name = "DataGridView8"
        Me.DataGridView8.RowTemplate.Height = 26
        Me.DataGridView8.Size = New System.Drawing.Size(909, 219)
        Me.DataGridView8.TabIndex = 5
        '
        'TabPage16
        '
        Me.TabPage16.BackColor = System.Drawing.Color.Gainsboro
        Me.TabPage16.Controls.Add(Me.GroupBox11)
        Me.TabPage16.Controls.Add(Me.GroupBox10)
        Me.TabPage16.Controls.Add(Me.GroupBox9)
        Me.TabPage16.Controls.Add(Me.GroupBox8)
        Me.TabPage16.Controls.Add(Me.GroupBox7)
        Me.TabPage16.Controls.Add(Me.GroupBox6)
        Me.TabPage16.Controls.Add(Me.GroupBox5)
        Me.TabPage16.Location = New System.Drawing.Point(4, 26)
        Me.TabPage16.Name = "TabPage16"
        Me.TabPage16.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage16.Size = New System.Drawing.Size(1182, 701)
        Me.TabPage16.TabIndex = 1
        Me.TabPage16.Text = "معلومات"
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.DataGridView13)
        Me.GroupBox11.Controls.Add(Me.Button51)
        Me.GroupBox11.Controls.Add(Me.Button52)
        Me.GroupBox11.Location = New System.Drawing.Point(723, 366)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(222, 326)
        Me.GroupBox11.TabIndex = 14
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "التخصصات"
        '
        'DataGridView13
        '
        Me.DataGridView13.AllowUserToAddRows = False
        Me.DataGridView13.AllowUserToDeleteRows = False
        Me.DataGridView13.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView13.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12})
        Me.DataGridView13.Location = New System.Drawing.Point(6, 30)
        Me.DataGridView13.Margin = New System.Windows.Forms.Padding(10)
        Me.DataGridView13.Name = "DataGridView13"
        Me.DataGridView13.ReadOnly = True
        Me.DataGridView13.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.DataGridView13.RowHeadersVisible = False
        Me.DataGridView13.Size = New System.Drawing.Size(203, 238)
        Me.DataGridView13.TabIndex = 10
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "H_Id"
        Me.DataGridViewTextBoxColumn11.FillWeight = 150.0!
        Me.DataGridViewTextBoxColumn11.HeaderText = "رقم التخصص"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "H_type"
        Me.DataGridViewTextBoxColumn12.HeaderText = "التخصص"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        '
        'Button51
        '
        Me.Button51.BackColor = System.Drawing.Color.White
        Me.Button51.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button51.Location = New System.Drawing.Point(125, 284)
        Me.Button51.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button51.Name = "Button51"
        Me.Button51.Size = New System.Drawing.Size(78, 33)
        Me.Button51.TabIndex = 8
        Me.Button51.Text = "تعديل"
        Me.Button51.UseVisualStyleBackColor = False
        '
        'Button52
        '
        Me.Button52.BackColor = System.Drawing.Color.White
        Me.Button52.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button52.Location = New System.Drawing.Point(43, 284)
        Me.Button52.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button52.Name = "Button52"
        Me.Button52.Size = New System.Drawing.Size(72, 33)
        Me.Button52.TabIndex = 7
        Me.Button52.Text = "اضافة"
        Me.Button52.UseVisualStyleBackColor = False
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.DataGridView12)
        Me.GroupBox10.Controls.Add(Me.Button49)
        Me.GroupBox10.Controls.Add(Me.Button50)
        Me.GroupBox10.Location = New System.Drawing.Point(957, 369)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(222, 323)
        Me.GroupBox10.TabIndex = 14
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "الدرجات"
        '
        'DataGridView12
        '
        Me.DataGridView12.AllowUserToAddRows = False
        Me.DataGridView12.AllowUserToDeleteRows = False
        Me.DataGridView12.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView12.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10})
        Me.DataGridView12.Location = New System.Drawing.Point(5, 24)
        Me.DataGridView12.Margin = New System.Windows.Forms.Padding(10)
        Me.DataGridView12.Name = "DataGridView12"
        Me.DataGridView12.ReadOnly = True
        Me.DataGridView12.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.DataGridView12.RowHeadersVisible = False
        Me.DataGridView12.Size = New System.Drawing.Size(203, 241)
        Me.DataGridView12.TabIndex = 10
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "H_Id"
        Me.DataGridViewTextBoxColumn9.FillWeight = 150.0!
        Me.DataGridViewTextBoxColumn9.HeaderText = "رقم الدرجة"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "H_type"
        Me.DataGridViewTextBoxColumn10.HeaderText = "الدرجة"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        '
        'Button49
        '
        Me.Button49.BackColor = System.Drawing.Color.White
        Me.Button49.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button49.Location = New System.Drawing.Point(130, 281)
        Me.Button49.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button49.Name = "Button49"
        Me.Button49.Size = New System.Drawing.Size(78, 33)
        Me.Button49.TabIndex = 8
        Me.Button49.Text = "تعديل"
        Me.Button49.UseVisualStyleBackColor = False
        '
        'Button50
        '
        Me.Button50.BackColor = System.Drawing.Color.White
        Me.Button50.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button50.Location = New System.Drawing.Point(30, 281)
        Me.Button50.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button50.Name = "Button50"
        Me.Button50.Size = New System.Drawing.Size(72, 33)
        Me.Button50.TabIndex = 7
        Me.Button50.Text = "اضافة"
        Me.Button50.UseVisualStyleBackColor = False
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.DataGridView11)
        Me.GroupBox9.Controls.Add(Me.Button47)
        Me.GroupBox9.Controls.Add(Me.Button48)
        Me.GroupBox9.Location = New System.Drawing.Point(18, 6)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(222, 357)
        Me.GroupBox9.TabIndex = 13
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "المستوي الوظيفي"
        '
        'DataGridView11
        '
        Me.DataGridView11.AllowUserToAddRows = False
        Me.DataGridView11.AllowUserToDeleteRows = False
        Me.DataGridView11.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView11.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8})
        Me.DataGridView11.Location = New System.Drawing.Point(6, 30)
        Me.DataGridView11.Margin = New System.Windows.Forms.Padding(10)
        Me.DataGridView11.Name = "DataGridView11"
        Me.DataGridView11.ReadOnly = True
        Me.DataGridView11.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.DataGridView11.RowHeadersVisible = False
        Me.DataGridView11.Size = New System.Drawing.Size(203, 276)
        Me.DataGridView11.TabIndex = 10
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "H_Id"
        Me.DataGridViewTextBoxColumn7.FillWeight = 150.0!
        Me.DataGridViewTextBoxColumn7.HeaderText = "رقم المستوي الوظيفي"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "H_type"
        Me.DataGridViewTextBoxColumn8.HeaderText = "المستوي الوظيفي"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        '
        'Button47
        '
        Me.Button47.BackColor = System.Drawing.Color.White
        Me.Button47.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button47.Location = New System.Drawing.Point(108, 322)
        Me.Button47.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button47.Name = "Button47"
        Me.Button47.Size = New System.Drawing.Size(78, 33)
        Me.Button47.TabIndex = 8
        Me.Button47.Text = "تعديل"
        Me.Button47.UseVisualStyleBackColor = False
        '
        'Button48
        '
        Me.Button48.BackColor = System.Drawing.Color.White
        Me.Button48.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button48.Location = New System.Drawing.Point(26, 322)
        Me.Button48.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button48.Name = "Button48"
        Me.Button48.Size = New System.Drawing.Size(72, 33)
        Me.Button48.TabIndex = 7
        Me.Button48.Text = "اضافة"
        Me.Button48.UseVisualStyleBackColor = False
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.DataGridView10)
        Me.GroupBox8.Controls.Add(Me.Button45)
        Me.GroupBox8.Controls.Add(Me.Button46)
        Me.GroupBox8.Location = New System.Drawing.Point(247, 6)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(222, 380)
        Me.GroupBox8.TabIndex = 12
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "الوظائف"
        '
        'DataGridView10
        '
        Me.DataGridView10.AllowUserToAddRows = False
        Me.DataGridView10.AllowUserToDeleteRows = False
        Me.DataGridView10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView10.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6})
        Me.DataGridView10.Location = New System.Drawing.Point(6, 30)
        Me.DataGridView10.Margin = New System.Windows.Forms.Padding(10)
        Me.DataGridView10.Name = "DataGridView10"
        Me.DataGridView10.ReadOnly = True
        Me.DataGridView10.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.DataGridView10.RowHeadersVisible = False
        Me.DataGridView10.Size = New System.Drawing.Size(203, 278)
        Me.DataGridView10.TabIndex = 10
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "H_Id"
        Me.DataGridViewTextBoxColumn5.FillWeight = 150.0!
        Me.DataGridViewTextBoxColumn5.HeaderText = "رقم الوظيفة"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "H_type"
        Me.DataGridViewTextBoxColumn6.HeaderText = "اسم الوظيفة"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        '
        'Button45
        '
        Me.Button45.BackColor = System.Drawing.Color.White
        Me.Button45.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button45.Location = New System.Drawing.Point(133, 324)
        Me.Button45.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(78, 33)
        Me.Button45.TabIndex = 8
        Me.Button45.Text = "تعديل"
        Me.Button45.UseVisualStyleBackColor = False
        '
        'Button46
        '
        Me.Button46.BackColor = System.Drawing.Color.White
        Me.Button46.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button46.Location = New System.Drawing.Point(33, 324)
        Me.Button46.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(72, 33)
        Me.Button46.TabIndex = 7
        Me.Button46.Text = "اضافة"
        Me.Button46.UseVisualStyleBackColor = False
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.DataGridView9)
        Me.GroupBox7.Controls.Add(Me.Button43)
        Me.GroupBox7.Controls.Add(Me.Button44)
        Me.GroupBox7.Location = New System.Drawing.Point(476, 6)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(222, 380)
        Me.GroupBox7.TabIndex = 11
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "الاجازات"
        '
        'DataGridView9
        '
        Me.DataGridView9.AllowUserToAddRows = False
        Me.DataGridView9.AllowUserToDeleteRows = False
        Me.DataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView9.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4})
        Me.DataGridView9.Location = New System.Drawing.Point(6, 30)
        Me.DataGridView9.Margin = New System.Windows.Forms.Padding(10)
        Me.DataGridView9.Name = "DataGridView9"
        Me.DataGridView9.ReadOnly = True
        Me.DataGridView9.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.DataGridView9.RowHeadersVisible = False
        Me.DataGridView9.Size = New System.Drawing.Size(203, 278)
        Me.DataGridView9.TabIndex = 10
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "H_Id"
        Me.DataGridViewTextBoxColumn3.FillWeight = 150.0!
        Me.DataGridViewTextBoxColumn3.HeaderText = "رقم الاجازة"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "H_type"
        Me.DataGridViewTextBoxColumn4.HeaderText = "نوع الاجازة"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        '
        'Button43
        '
        Me.Button43.BackColor = System.Drawing.Color.White
        Me.Button43.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button43.Location = New System.Drawing.Point(133, 324)
        Me.Button43.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(78, 33)
        Me.Button43.TabIndex = 8
        Me.Button43.Text = "تعديل"
        Me.Button43.UseVisualStyleBackColor = False
        '
        'Button44
        '
        Me.Button44.BackColor = System.Drawing.Color.White
        Me.Button44.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button44.Location = New System.Drawing.Point(33, 324)
        Me.Button44.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(72, 33)
        Me.Button44.TabIndex = 7
        Me.Button44.Text = "اضافة"
        Me.Button44.UseVisualStyleBackColor = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.dgvQl)
        Me.GroupBox6.Controls.Add(Me.Button41)
        Me.GroupBox6.Controls.Add(Me.Button42)
        Me.GroupBox6.Location = New System.Drawing.Point(715, 6)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(222, 380)
        Me.GroupBox6.TabIndex = 9
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "المؤهلات"
        '
        'dgvQl
        '
        Me.dgvQl.AllowUserToAddRows = False
        Me.dgvQl.AllowUserToDeleteRows = False
        Me.dgvQl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvQl.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2})
        Me.dgvQl.Location = New System.Drawing.Point(10, 30)
        Me.dgvQl.Margin = New System.Windows.Forms.Padding(7, 8, 7, 8)
        Me.dgvQl.Name = "dgvQl"
        Me.dgvQl.ReadOnly = True
        Me.dgvQl.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.dgvQl.RowHeadersVisible = False
        Me.dgvQl.Size = New System.Drawing.Size(204, 280)
        Me.dgvQl.TabIndex = 10
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "Qual_Id"
        Me.DataGridViewTextBoxColumn1.FillWeight = 150.0!
        Me.DataGridViewTextBoxColumn1.HeaderText = "رقم المؤهل"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Qual_name"
        Me.DataGridViewTextBoxColumn2.HeaderText = "اسم المؤهل"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        '
        'Button41
        '
        Me.Button41.BackColor = System.Drawing.Color.White
        Me.Button41.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button41.Location = New System.Drawing.Point(133, 324)
        Me.Button41.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(78, 33)
        Me.Button41.TabIndex = 8
        Me.Button41.Text = "تعديل"
        Me.Button41.UseVisualStyleBackColor = False
        '
        'Button42
        '
        Me.Button42.BackColor = System.Drawing.Color.White
        Me.Button42.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button42.Location = New System.Drawing.Point(33, 324)
        Me.Button42.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(72, 33)
        Me.Button42.TabIndex = 7
        Me.Button42.Text = "اضافة"
        Me.Button42.UseVisualStyleBackColor = False
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Button39)
        Me.GroupBox5.Controls.Add(Me.Button40)
        Me.GroupBox5.Controls.Add(Me.dgvPl)
        Me.GroupBox5.Location = New System.Drawing.Point(954, 6)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(222, 380)
        Me.GroupBox5.TabIndex = 0
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "الاماكن"
        '
        'Button39
        '
        Me.Button39.BackColor = System.Drawing.Color.White
        Me.Button39.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button39.Location = New System.Drawing.Point(133, 324)
        Me.Button39.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(78, 33)
        Me.Button39.TabIndex = 8
        Me.Button39.Text = "تعديل"
        Me.Button39.UseVisualStyleBackColor = False
        '
        'Button40
        '
        Me.Button40.BackColor = System.Drawing.Color.White
        Me.Button40.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button40.Location = New System.Drawing.Point(33, 324)
        Me.Button40.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(72, 33)
        Me.Button40.TabIndex = 7
        Me.Button40.Text = "اضافة"
        Me.Button40.UseVisualStyleBackColor = False
        '
        'dgvPl
        '
        Me.dgvPl.AllowUserToAddRows = False
        Me.dgvPl.AllowUserToDeleteRows = False
        Me.dgvPl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvPl.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2})
        Me.dgvPl.Location = New System.Drawing.Point(8, 30)
        Me.dgvPl.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.dgvPl.Name = "dgvPl"
        Me.dgvPl.ReadOnly = True
        Me.dgvPl.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.dgvPl.RowHeadersVisible = False
        Me.dgvPl.Size = New System.Drawing.Size(203, 282)
        Me.dgvPl.TabIndex = 6
        '
        'Column1
        '
        Me.Column1.DataPropertyName = "Place_Id"
        Me.Column1.FillWeight = 150.0!
        Me.Column1.HeaderText = "رقم المكان"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'Column2
        '
        Me.Column2.DataPropertyName = "Place_N"
        Me.Column2.HeaderText = "اسم المكان"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.TabControl5)
        Me.TabPage5.Location = New System.Drawing.Point(4, 26)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1199, 740)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "الدورات"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'TabControl5
        '
        Me.TabControl5.Controls.Add(Me.TabPage13)
        Me.TabControl5.Controls.Add(Me.TabPage14)
        Me.TabControl5.Location = New System.Drawing.Point(6, 6)
        Me.TabControl5.Name = "TabControl5"
        Me.TabControl5.RightToLeftLayout = True
        Me.TabControl5.SelectedIndex = 0
        Me.TabControl5.Size = New System.Drawing.Size(1190, 722)
        Me.TabControl5.TabIndex = 0
        '
        'TabPage13
        '
        Me.TabPage13.Controls.Add(Me.Button23)
        Me.TabPage13.Controls.Add(Me.Panel8)
        Me.TabPage13.Controls.Add(Me.Button26)
        Me.TabPage13.Controls.Add(Me.Button27)
        Me.TabPage13.Controls.Add(Me.Label91)
        Me.TabPage13.Controls.Add(Me.txt_C)
        Me.TabPage13.Controls.Add(Me.DataGridView6)
        Me.TabPage13.Location = New System.Drawing.Point(4, 26)
        Me.TabPage13.Name = "TabPage13"
        Me.TabPage13.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage13.Size = New System.Drawing.Size(1182, 692)
        Me.TabPage13.TabIndex = 0
        Me.TabPage13.Text = "الدورات"
        Me.TabPage13.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(426, 370)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(116, 36)
        Me.Button23.TabIndex = 19
        Me.Button23.Text = "الغاء"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel8.Controls.Add(Me.TextBox34)
        Me.Panel8.Controls.Add(Me.Label96)
        Me.Panel8.Controls.Add(Me.Label93)
        Me.Panel8.Controls.Add(Me.DateTimePicker14)
        Me.Panel8.Controls.Add(Me.TextBox33)
        Me.Panel8.Controls.Add(Me.Label95)
        Me.Panel8.Controls.Add(Me.Label92)
        Me.Panel8.Controls.Add(Me.DateTimePicker13)
        Me.Panel8.Controls.Add(Me.Button24)
        Me.Panel8.Controls.Add(Me.Button25)
        Me.Panel8.Controls.Add(Me.TextBox32)
        Me.Panel8.Controls.Add(Me.Label94)
        Me.Panel8.Location = New System.Drawing.Point(12, 429)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(1155, 183)
        Me.Panel8.TabIndex = 18
        '
        'TextBox34
        '
        Me.TextBox34.BackColor = System.Drawing.Color.White
        Me.TextBox34.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox34.Location = New System.Drawing.Point(157, 71)
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.ReadOnly = True
        Me.TextBox34.Size = New System.Drawing.Size(167, 29)
        Me.TextBox34.TabIndex = 19
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label96.Location = New System.Drawing.Point(330, 74)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(76, 22)
        Me.Label96.TabIndex = 18
        Me.Label96.Text = "مدة الدورة"
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label93.Location = New System.Drawing.Point(658, 74)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(93, 22)
        Me.Label93.TabIndex = 17
        Me.Label93.Text = "تاريخ الانتهاء"
        '
        'DateTimePicker14
        '
        Me.DateTimePicker14.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker14.Location = New System.Drawing.Point(452, 67)
        Me.DateTimePicker14.Name = "DateTimePicker14"
        Me.DateTimePicker14.Size = New System.Drawing.Size(200, 29)
        Me.DateTimePicker14.TabIndex = 16
        '
        'TextBox33
        '
        Me.TextBox33.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox33.Location = New System.Drawing.Point(157, 9)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(349, 29)
        Me.TextBox33.TabIndex = 15
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label95.Location = New System.Drawing.Point(512, 12)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(81, 22)
        Me.Label95.TabIndex = 14
        Me.Label95.Text = "اسم المدرب"
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label92.Location = New System.Drawing.Point(1014, 74)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(90, 22)
        Me.Label92.TabIndex = 13
        Me.Label92.Text = "تاريخ الانعقاد"
        '
        'DateTimePicker13
        '
        Me.DateTimePicker13.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker13.Location = New System.Drawing.Point(806, 67)
        Me.DateTimePicker13.Name = "DateTimePicker13"
        Me.DateTimePicker13.Size = New System.Drawing.Size(200, 29)
        Me.DateTimePicker13.TabIndex = 12
        '
        'Button24
        '
        Me.Button24.BackColor = System.Drawing.Color.White
        Me.Button24.Location = New System.Drawing.Point(481, 129)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(116, 36)
        Me.Button24.TabIndex = 9
        Me.Button24.Text = "الغاء"
        Me.Button24.UseVisualStyleBackColor = False
        '
        'Button25
        '
        Me.Button25.BackColor = System.Drawing.Color.White
        Me.Button25.Location = New System.Drawing.Point(615, 129)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(116, 36)
        Me.Button25.TabIndex = 9
        Me.Button25.Text = "حفظ"
        Me.Button25.UseVisualStyleBackColor = False
        '
        'TextBox32
        '
        Me.TextBox32.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox32.Location = New System.Drawing.Point(679, 14)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(349, 29)
        Me.TextBox32.TabIndex = 1
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label94.Location = New System.Drawing.Point(1034, 17)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(77, 22)
        Me.Label94.TabIndex = 0
        Me.Label94.Text = "اسم الدورة"
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(548, 370)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(116, 36)
        Me.Button26.TabIndex = 17
        Me.Button26.Text = "تعديل"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(670, 370)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(116, 36)
        Me.Button27.TabIndex = 16
        Me.Button27.Text = "انشاء دورة"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Label91
        '
        Me.Label91.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label91.Location = New System.Drawing.Point(750, 0)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(76, 35)
        Me.Label91.TabIndex = 6
        Me.Label91.Text = "بحث :"
        Me.Label91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_C
        '
        Me.txt_C.Location = New System.Drawing.Point(353, 6)
        Me.txt_C.Name = "txt_C"
        Me.txt_C.Size = New System.Drawing.Size(395, 24)
        Me.txt_C.TabIndex = 7
        Me.txt_C.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'DataGridView6
        '
        Me.DataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView6.Location = New System.Drawing.Point(12, 39)
        Me.DataGridView6.Name = "DataGridView6"
        Me.DataGridView6.RowTemplate.Height = 26
        Me.DataGridView6.Size = New System.Drawing.Size(1161, 299)
        Me.DataGridView6.TabIndex = 5
        '
        'TabPage14
        '
        Me.TabPage14.Controls.Add(Me.Button28)
        Me.TabPage14.Controls.Add(Me.Panel9)
        Me.TabPage14.Controls.Add(Me.Button31)
        Me.TabPage14.Controls.Add(Me.Button32)
        Me.TabPage14.Controls.Add(Me.Label97)
        Me.TabPage14.Controls.Add(Me.txt_T)
        Me.TabPage14.Controls.Add(Me.DataGridView7)
        Me.TabPage14.Location = New System.Drawing.Point(4, 26)
        Me.TabPage14.Name = "TabPage14"
        Me.TabPage14.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage14.Size = New System.Drawing.Size(1182, 692)
        Me.TabPage14.TabIndex = 1
        Me.TabPage14.Text = "المتدربون"
        Me.TabPage14.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Location = New System.Drawing.Point(462, 449)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(116, 36)
        Me.Button28.TabIndex = 19
        Me.Button28.Text = "الغاء"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel9.Controls.Add(Me.TextBox37)
        Me.Panel9.Controls.Add(Me.Label101)
        Me.Panel9.Controls.Add(Me.Label99)
        Me.Panel9.Controls.Add(Me.ComboBox24)
        Me.Panel9.Controls.Add(Me.Button29)
        Me.Panel9.Controls.Add(Me.Button30)
        Me.Panel9.Controls.Add(Me.TextBox36)
        Me.Panel9.Controls.Add(Me.Label100)
        Me.Panel9.Location = New System.Drawing.Point(15, 500)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(1161, 183)
        Me.Panel9.TabIndex = 18
        '
        'TextBox37
        '
        Me.TextBox37.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox37.Location = New System.Drawing.Point(102, 22)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(389, 29)
        Me.TextBox37.TabIndex = 15
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label101.Location = New System.Drawing.Point(497, 25)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(87, 22)
        Me.Label101.TabIndex = 14
        Me.Label101.Text = "اسم الموظف"
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label99.Location = New System.Drawing.Point(646, 84)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(77, 22)
        Me.Label99.TabIndex = 11
        Me.Label99.Text = "اسم الدورة"
        '
        'ComboBox24
        '
        Me.ComboBox24.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox24.FormattingEnabled = True
        Me.ComboBox24.Location = New System.Drawing.Point(461, 81)
        Me.ComboBox24.Name = "ComboBox24"
        Me.ComboBox24.Size = New System.Drawing.Size(179, 28)
        Me.ComboBox24.TabIndex = 10
        '
        'Button29
        '
        Me.Button29.BackColor = System.Drawing.Color.White
        Me.Button29.Location = New System.Drawing.Point(481, 129)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(116, 36)
        Me.Button29.TabIndex = 9
        Me.Button29.Text = "الغاء"
        Me.Button29.UseVisualStyleBackColor = False
        '
        'Button30
        '
        Me.Button30.BackColor = System.Drawing.Color.White
        Me.Button30.Location = New System.Drawing.Point(615, 129)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(116, 36)
        Me.Button30.TabIndex = 9
        Me.Button30.Text = "حفظ"
        Me.Button30.UseVisualStyleBackColor = False
        '
        'TextBox36
        '
        Me.TextBox36.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox36.Location = New System.Drawing.Point(642, 22)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(215, 29)
        Me.TextBox36.TabIndex = 1
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label100.Location = New System.Drawing.Point(863, 25)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(85, 22)
        Me.Label100.TabIndex = 0
        Me.Label100.Text = "رقم الموظف"
        '
        'Button31
        '
        Me.Button31.Location = New System.Drawing.Point(584, 449)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(116, 36)
        Me.Button31.TabIndex = 17
        Me.Button31.Text = "تعديل"
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.Location = New System.Drawing.Point(706, 449)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(116, 36)
        Me.Button32.TabIndex = 16
        Me.Button32.Text = "اضافة متدرب"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Label97
        '
        Me.Label97.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label97.Location = New System.Drawing.Point(753, 12)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(76, 35)
        Me.Label97.TabIndex = 9
        Me.Label97.Text = "بحث :"
        Me.Label97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_T
        '
        Me.txt_T.Location = New System.Drawing.Point(356, 18)
        Me.txt_T.Name = "txt_T"
        Me.txt_T.Size = New System.Drawing.Size(395, 24)
        Me.txt_T.TabIndex = 10
        Me.txt_T.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'DataGridView7
        '
        Me.DataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView7.Location = New System.Drawing.Point(15, 51)
        Me.DataGridView7.Name = "DataGridView7"
        Me.DataGridView7.RowTemplate.Height = 26
        Me.DataGridView7.Size = New System.Drawing.Size(1161, 376)
        Me.DataGridView7.TabIndex = 8
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.TabControl4)
        Me.TabPage3.Location = New System.Drawing.Point(4, 26)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1199, 740)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "الادارات والاقسام"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TabControl4
        '
        Me.TabControl4.Controls.Add(Me.TabPage1)
        Me.TabControl4.Controls.Add(Me.TabPage4)
        Me.TabControl4.Location = New System.Drawing.Point(6, 6)
        Me.TabControl4.Name = "TabControl4"
        Me.TabControl4.RightToLeftLayout = True
        Me.TabControl4.SelectedIndex = 0
        Me.TabControl4.Size = New System.Drawing.Size(1187, 728)
        Me.TabControl4.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Button15)
        Me.TabPage1.Controls.Add(Me.Panel2)
        Me.TabPage1.Controls.Add(Me.Button14)
        Me.TabPage1.Controls.Add(Me.Button13)
        Me.TabPage1.Controls.Add(Me.Label85)
        Me.TabPage1.Controls.Add(Me.txt_mang)
        Me.TabPage1.Controls.Add(Me.DataGridView4)
        Me.TabPage1.Location = New System.Drawing.Point(4, 26)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1179, 698)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "الادارات"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(456, 419)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(116, 36)
        Me.Button15.TabIndex = 8
        Me.Button15.Text = "الغاء"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel2.Controls.Add(Me.Button17)
        Me.Panel2.Controls.Add(Me.Button16)
        Me.Panel2.Controls.Add(Me.TextBox28)
        Me.Panel2.Controls.Add(Me.Label86)
        Me.Panel2.Location = New System.Drawing.Point(147, 470)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(918, 183)
        Me.Panel2.TabIndex = 7
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(329, 120)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(116, 36)
        Me.Button17.TabIndex = 9
        Me.Button17.Text = "الغاء"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(463, 120)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(116, 36)
        Me.Button16.TabIndex = 9
        Me.Button16.Text = "حفظ"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'TextBox28
        '
        Me.TextBox28.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox28.Location = New System.Drawing.Point(260, 60)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(349, 32)
        Me.TextBox28.TabIndex = 1
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label86.Location = New System.Drawing.Point(615, 63)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(91, 25)
        Me.Label86.TabIndex = 0
        Me.Label86.Text = "اسم الادارة"
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(578, 419)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(116, 36)
        Me.Button14.TabIndex = 6
        Me.Button14.Text = "تعديل"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(700, 419)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(116, 36)
        Me.Button13.TabIndex = 5
        Me.Button13.Text = "اضافة ادارة "
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Label85
        '
        Me.Label85.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.Location = New System.Drawing.Point(770, -1)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(76, 35)
        Me.Label85.TabIndex = 3
        Me.Label85.Text = "بحث :"
        Me.Label85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_mang
        '
        Me.txt_mang.Location = New System.Drawing.Point(373, 6)
        Me.txt_mang.Name = "txt_mang"
        Me.txt_mang.Size = New System.Drawing.Size(395, 24)
        Me.txt_mang.TabIndex = 4
        Me.txt_mang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'DataGridView4
        '
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.Location = New System.Drawing.Point(7, 40)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.RowTemplate.Height = 26
        Me.DataGridView4.Size = New System.Drawing.Size(1167, 373)
        Me.DataGridView4.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Button18)
        Me.TabPage4.Controls.Add(Me.Panel7)
        Me.TabPage4.Controls.Add(Me.Button21)
        Me.TabPage4.Controls.Add(Me.Button22)
        Me.TabPage4.Controls.Add(Me.Label88)
        Me.TabPage4.Controls.Add(Me.txt_dep)
        Me.TabPage4.Controls.Add(Me.DataGridView5)
        Me.TabPage4.Location = New System.Drawing.Point(4, 26)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1179, 698)
        Me.TabPage4.TabIndex = 1
        Me.TabPage4.Text = "الاقسام"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(465, 428)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(116, 36)
        Me.Button18.TabIndex = 15
        Me.Button18.Text = "الغاء"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel7.Controls.Add(Me.Label90)
        Me.Panel7.Controls.Add(Me.DateTimePicker12)
        Me.Panel7.Controls.Add(Me.Label89)
        Me.Panel7.Controls.Add(Me.ComboBox23)
        Me.Panel7.Controls.Add(Me.Button19)
        Me.Panel7.Controls.Add(Me.Button20)
        Me.Panel7.Controls.Add(Me.TextBox29)
        Me.Panel7.Controls.Add(Me.Label87)
        Me.Panel7.Location = New System.Drawing.Point(18, 479)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(1155, 183)
        Me.Panel7.TabIndex = 14
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label90.Location = New System.Drawing.Point(354, 17)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(120, 22)
        Me.Label90.TabIndex = 13
        Me.Label90.Text = "تاريخ انشاء القسم"
        '
        'DateTimePicker12
        '
        Me.DateTimePicker12.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker12.Location = New System.Drawing.Point(148, 10)
        Me.DateTimePicker12.Name = "DateTimePicker12"
        Me.DateTimePicker12.Size = New System.Drawing.Size(200, 29)
        Me.DateTimePicker12.TabIndex = 12
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label89.Location = New System.Drawing.Point(643, 82)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(107, 22)
        Me.Label89.TabIndex = 11
        Me.Label89.Text = "الادارة التابع لها"
        '
        'ComboBox23
        '
        Me.ComboBox23.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox23.FormattingEnabled = True
        Me.ComboBox23.Location = New System.Drawing.Point(458, 79)
        Me.ComboBox23.Name = "ComboBox23"
        Me.ComboBox23.Size = New System.Drawing.Size(179, 28)
        Me.ComboBox23.TabIndex = 10
        '
        'Button19
        '
        Me.Button19.BackColor = System.Drawing.Color.White
        Me.Button19.Location = New System.Drawing.Point(481, 129)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(116, 36)
        Me.Button19.TabIndex = 9
        Me.Button19.Text = "الغاء"
        Me.Button19.UseVisualStyleBackColor = False
        '
        'Button20
        '
        Me.Button20.BackColor = System.Drawing.Color.White
        Me.Button20.Location = New System.Drawing.Point(615, 129)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(116, 36)
        Me.Button20.TabIndex = 9
        Me.Button20.Text = "حفظ"
        Me.Button20.UseVisualStyleBackColor = False
        '
        'TextBox29
        '
        Me.TextBox29.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox29.Location = New System.Drawing.Point(679, 14)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(349, 29)
        Me.TextBox29.TabIndex = 1
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label87.Location = New System.Drawing.Point(1034, 17)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(71, 22)
        Me.Label87.TabIndex = 0
        Me.Label87.Text = "اسم القسم"
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(587, 428)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(116, 36)
        Me.Button21.TabIndex = 13
        Me.Button21.Text = "تعديل"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(709, 428)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(116, 36)
        Me.Button22.TabIndex = 12
        Me.Button22.Text = "اضافة قسم"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Label88
        '
        Me.Label88.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label88.Location = New System.Drawing.Point(773, 9)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(76, 35)
        Me.Label88.TabIndex = 10
        Me.Label88.Text = "بحث :"
        Me.Label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_dep
        '
        Me.txt_dep.Location = New System.Drawing.Point(372, 15)
        Me.txt_dep.Name = "txt_dep"
        Me.txt_dep.Size = New System.Drawing.Size(395, 24)
        Me.txt_dep.TabIndex = 11
        Me.txt_dep.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'DataGridView5
        '
        Me.DataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView5.Location = New System.Drawing.Point(6, 49)
        Me.DataGridView5.Name = "DataGridView5"
        Me.DataGridView5.RowTemplate.Height = 26
        Me.DataGridView5.Size = New System.Drawing.Size(1167, 373)
        Me.DataGridView5.TabIndex = 9
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.TabControl3)
        Me.TabPage2.Location = New System.Drawing.Point(4, 26)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1199, 740)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "الاجازات"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'TabControl3
        '
        Me.TabControl3.Controls.Add(Me.TabPage10)
        Me.TabControl3.Controls.Add(Me.TabPage11)
        Me.TabControl3.Controls.Add(Me.TabPage12)
        Me.TabControl3.Location = New System.Drawing.Point(7, 6)
        Me.TabControl3.Name = "TabControl3"
        Me.TabControl3.RightToLeftLayout = True
        Me.TabControl3.SelectedIndex = 0
        Me.TabControl3.Size = New System.Drawing.Size(1190, 728)
        Me.TabControl3.TabIndex = 17
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.GroupBox1)
        Me.TabPage10.Controls.Add(Me.GroupBox2)
        Me.TabPage10.Location = New System.Drawing.Point(4, 26)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage10.Size = New System.Drawing.Size(1182, 698)
        Me.TabPage10.TabIndex = 0
        Me.TabPage10.Text = "طلب اجازة لموظف"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox1.Controls.Add(Me.Emp_name_A)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Emp_id_A)
        Me.GroupBox1.Controls.Add(Me.Day_Emergency_A)
        Me.GroupBox1.Controls.Add(Me.Day_Annual_A)
        Me.GroupBox1.Location = New System.Drawing.Point(40, 8)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GroupBox1.Size = New System.Drawing.Size(1127, 173)
        Me.GroupBox1.TabIndex = 15
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "بيانات الموظف :"
        '
        'Emp_name_A
        '
        Me.Emp_name_A.BackColor = System.Drawing.Color.White
        Me.Emp_name_A.Location = New System.Drawing.Point(234, 46)
        Me.Emp_name_A.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Emp_name_A.Name = "Emp_name_A"
        Me.Emp_name_A.ReadOnly = True
        Me.Emp_name_A.Size = New System.Drawing.Size(346, 24)
        Me.Emp_name_A.TabIndex = 30
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(588, 48)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(79, 17)
        Me.Label11.TabIndex = 29
        Me.Label11.Text = "اسم الموظف :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(868, 48)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(77, 17)
        Me.Label10.TabIndex = 7
        Me.Label10.Text = "رقم الموظف :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(828, 96)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(114, 17)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "ايام الاجازة السنوية :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(553, 96)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(112, 17)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "ايام الاجازة الطارئة :"
        '
        'Emp_id_A
        '
        Me.Emp_id_A.Location = New System.Drawing.Point(688, 46)
        Me.Emp_id_A.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Emp_id_A.Name = "Emp_id_A"
        Me.Emp_id_A.Size = New System.Drawing.Size(134, 24)
        Me.Emp_id_A.TabIndex = 14
        '
        'Day_Emergency_A
        '
        Me.Day_Emergency_A.BackColor = System.Drawing.Color.White
        Me.Day_Emergency_A.Location = New System.Drawing.Point(421, 92)
        Me.Day_Emergency_A.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Day_Emergency_A.Name = "Day_Emergency_A"
        Me.Day_Emergency_A.ReadOnly = True
        Me.Day_Emergency_A.Size = New System.Drawing.Size(134, 24)
        Me.Day_Emergency_A.TabIndex = 15
        '
        'Day_Annual_A
        '
        Me.Day_Annual_A.BackColor = System.Drawing.Color.White
        Me.Day_Annual_A.Location = New System.Drawing.Point(688, 92)
        Me.Day_Annual_A.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Day_Annual_A.Name = "Day_Annual_A"
        Me.Day_Annual_A.ReadOnly = True
        Me.Day_Annual_A.Size = New System.Drawing.Size(134, 24)
        Me.Day_Annual_A.TabIndex = 15
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.H_type_A)
        Me.GroupBox2.Controls.Add(Me.Button1)
        Me.GroupBox2.Controls.Add(Me.H_end_A)
        Me.GroupBox2.Controls.Add(Me.Button4)
        Me.GroupBox2.Controls.Add(Me.H_start_A)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Location = New System.Drawing.Point(40, 202)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GroupBox2.Size = New System.Drawing.Size(1127, 237)
        Me.GroupBox2.TabIndex = 16
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "معلومات الاجازة :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(578, 139)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 17)
        Me.Label8.TabIndex = 29
        '
        'H_type_A
        '
        Me.H_type_A.FormattingEnabled = True
        Me.H_type_A.Location = New System.Drawing.Point(424, 28)
        Me.H_type_A.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.H_type_A.Name = "H_type_A"
        Me.H_type_A.Size = New System.Drawing.Size(170, 25)
        Me.H_type_A.TabIndex = 28
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(382, 182)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(112, 37)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "حفظ"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'H_end_A
        '
        Me.H_end_A.Location = New System.Drawing.Point(257, 80)
        Me.H_end_A.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.H_end_A.Name = "H_end_A"
        Me.H_end_A.Size = New System.Drawing.Size(172, 24)
        Me.H_end_A.TabIndex = 27
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(532, 182)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(112, 37)
        Me.Button4.TabIndex = 14
        Me.Button4.Text = "الغاء الامر"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'H_start_A
        '
        Me.H_start_A.Location = New System.Drawing.Point(588, 80)
        Me.H_start_A.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.H_start_A.Name = "H_start_A"
        Me.H_start_A.Size = New System.Drawing.Size(188, 24)
        Me.H_start_A.TabIndex = 26
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(605, 31)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 17)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "نوع الاجازة :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(436, 85)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(99, 17)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "ت/انتهاء الاجازة :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(783, 85)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 17)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "ت/بداية الاجازة :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(607, 139)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 17)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "المدة بالايام :"
        '
        'TabPage11
        '
        Me.TabPage11.Controls.Add(Me.GroupBox3)
        Me.TabPage11.Controls.Add(Me.GroupBox4)
        Me.TabPage11.Location = New System.Drawing.Point(4, 26)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage11.Size = New System.Drawing.Size(1182, 698)
        Me.TabPage11.TabIndex = 1
        Me.TabPage11.Text = "تعديل اجازة موظف"
        Me.TabPage11.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox3.Controls.Add(Me.Emp_name_E)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.Emp_id_E)
        Me.GroupBox3.Controls.Add(Me.Day_Emergency_E)
        Me.GroupBox3.Controls.Add(Me.Day_Annual_E)
        Me.GroupBox3.Location = New System.Drawing.Point(38, 20)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GroupBox3.Size = New System.Drawing.Size(1127, 173)
        Me.GroupBox3.TabIndex = 17
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "بيانات الموظف :"
        '
        'Emp_name_E
        '
        Me.Emp_name_E.BackColor = System.Drawing.Color.White
        Me.Emp_name_E.Location = New System.Drawing.Point(234, 46)
        Me.Emp_name_E.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Emp_name_E.Name = "Emp_name_E"
        Me.Emp_name_E.ReadOnly = True
        Me.Emp_name_E.Size = New System.Drawing.Size(346, 24)
        Me.Emp_name_E.TabIndex = 30
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(588, 48)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(79, 17)
        Me.Label12.TabIndex = 29
        Me.Label12.Text = "اسم الموظف :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(868, 48)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(77, 17)
        Me.Label13.TabIndex = 7
        Me.Label13.Text = "رقم الموظف :"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(828, 96)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(114, 17)
        Me.Label14.TabIndex = 8
        Me.Label14.Text = "ايام الاجازة السنوية :"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(553, 96)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(112, 17)
        Me.Label15.TabIndex = 9
        Me.Label15.Text = "ايام الاجازة الطارئة :"
        '
        'Emp_id_E
        '
        Me.Emp_id_E.Location = New System.Drawing.Point(688, 46)
        Me.Emp_id_E.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Emp_id_E.Name = "Emp_id_E"
        Me.Emp_id_E.Size = New System.Drawing.Size(134, 24)
        Me.Emp_id_E.TabIndex = 14
        '
        'Day_Emergency_E
        '
        Me.Day_Emergency_E.BackColor = System.Drawing.Color.White
        Me.Day_Emergency_E.Location = New System.Drawing.Point(421, 92)
        Me.Day_Emergency_E.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Day_Emergency_E.Name = "Day_Emergency_E"
        Me.Day_Emergency_E.ReadOnly = True
        Me.Day_Emergency_E.Size = New System.Drawing.Size(134, 24)
        Me.Day_Emergency_E.TabIndex = 15
        '
        'Day_Annual_E
        '
        Me.Day_Annual_E.BackColor = System.Drawing.Color.White
        Me.Day_Annual_E.Location = New System.Drawing.Point(688, 92)
        Me.Day_Annual_E.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Day_Annual_E.Name = "Day_Annual_E"
        Me.Day_Annual_E.ReadOnly = True
        Me.Day_Annual_E.Size = New System.Drawing.Size(134, 24)
        Me.Day_Annual_E.TabIndex = 15
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox4.Controls.Add(Me.Button12)
        Me.GroupBox4.Controls.Add(Me.Label16)
        Me.GroupBox4.Controls.Add(Me.H_type_E)
        Me.GroupBox4.Controls.Add(Me.Button2)
        Me.GroupBox4.Controls.Add(Me.H_end_E)
        Me.GroupBox4.Controls.Add(Me.Button5)
        Me.GroupBox4.Controls.Add(Me.H_start_E)
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Controls.Add(Me.Label19)
        Me.GroupBox4.Controls.Add(Me.Label20)
        Me.GroupBox4.Location = New System.Drawing.Point(38, 215)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GroupBox4.Size = New System.Drawing.Size(1127, 237)
        Me.GroupBox4.TabIndex = 18
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "معلومات الاجازة :"
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.Color.White
        Me.Button12.Location = New System.Drawing.Point(646, 182)
        Me.Button12.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(112, 37)
        Me.Button12.TabIndex = 30
        Me.Button12.Text = "بحث"
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(578, 139)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(0, 17)
        Me.Label16.TabIndex = 29
        '
        'H_type_E
        '
        Me.H_type_E.FormattingEnabled = True
        Me.H_type_E.Location = New System.Drawing.Point(424, 28)
        Me.H_type_E.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.H_type_E.Name = "H_type_E"
        Me.H_type_E.Size = New System.Drawing.Size(170, 25)
        Me.H_type_E.TabIndex = 28
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(382, 182)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(112, 37)
        Me.Button2.TabIndex = 12
        Me.Button2.Text = "حفظ"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'H_end_E
        '
        Me.H_end_E.Location = New System.Drawing.Point(257, 80)
        Me.H_end_E.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.H_end_E.Name = "H_end_E"
        Me.H_end_E.Size = New System.Drawing.Size(172, 24)
        Me.H_end_E.TabIndex = 27
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.White
        Me.Button5.Location = New System.Drawing.Point(514, 182)
        Me.Button5.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(112, 37)
        Me.Button5.TabIndex = 14
        Me.Button5.Text = "الغاء الامر"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'H_start_E
        '
        Me.H_start_E.Location = New System.Drawing.Point(588, 80)
        Me.H_start_E.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.H_start_E.Name = "H_start_E"
        Me.H_start_E.Size = New System.Drawing.Size(188, 24)
        Me.H_start_E.TabIndex = 26
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(605, 31)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(74, 17)
        Me.Label17.TabIndex = 25
        Me.Label17.Text = "نوع الاجازة :"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(436, 85)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(99, 17)
        Me.Label18.TabIndex = 21
        Me.Label18.Text = "ت/انتهاء الاجازة :"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(783, 85)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(92, 17)
        Me.Label19.TabIndex = 20
        Me.Label19.Text = "ت/بداية الاجازة :"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(607, 139)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(73, 17)
        Me.Label20.TabIndex = 12
        Me.Label20.Text = "المدة بالايام :"
        '
        'TabPage12
        '
        Me.TabPage12.Controls.Add(Me.Label21)
        Me.TabPage12.Controls.Add(Me.txt_H)
        Me.TabPage12.Controls.Add(Me.DataGridView2)
        Me.TabPage12.Location = New System.Drawing.Point(4, 26)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage12.Size = New System.Drawing.Size(1182, 698)
        Me.TabPage12.TabIndex = 2
        Me.TabPage12.Text = "الموظفون في اجازة"
        Me.TabPage12.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(792, 13)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(76, 35)
        Me.Label21.TabIndex = 3
        Me.Label21.Text = "بحث :"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_H
        '
        Me.txt_H.Location = New System.Drawing.Point(395, 19)
        Me.txt_H.Name = "txt_H"
        Me.txt_H.Size = New System.Drawing.Size(395, 24)
        Me.txt_H.TabIndex = 4
        Me.txt_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'DataGridView2
        '
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Location = New System.Drawing.Point(16, 64)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.RowTemplate.Height = 26
        Me.DataGridView2.Size = New System.Drawing.Size(1161, 584)
        Me.DataGridView2.TabIndex = 0
        '
        'Emp_P
        '
        Me.Emp_P.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Emp_P.Controls.Add(Me.Panel1)
        Me.Emp_P.Location = New System.Drawing.Point(4, 26)
        Me.Emp_P.Name = "Emp_P"
        Me.Emp_P.Padding = New System.Windows.Forms.Padding(3)
        Me.Emp_P.Size = New System.Drawing.Size(1199, 740)
        Me.Emp_P.TabIndex = 0
        Me.Emp_P.Text = "الموظفون"
        Me.Emp_P.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel1.Controls.Add(Me.TabControl2)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.txt_Emp)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.DataGridView1)
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1194, 735)
        Me.Panel1.TabIndex = 1
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage7)
        Me.TabControl2.Controls.Add(Me.TabPage8)
        Me.TabControl2.Controls.Add(Me.TabPage9)
        Me.TabControl2.Controls.Add(Me.TabPage17)
        Me.TabControl2.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl2.Location = New System.Drawing.Point(7, 329)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.RightToLeftLayout = True
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(1183, 397)
        Me.TabControl2.TabIndex = 3
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.Label24)
        Me.TabPage7.Controls.Add(Me.Panel3)
        Me.TabPage7.Controls.Add(Me.Label37)
        Me.TabPage7.Controls.Add(Me.Panel4)
        Me.TabPage7.Location = New System.Drawing.Point(4, 29)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(1175, 364)
        Me.TabPage7.TabIndex = 0
        Me.TabPage7.Text = "اضافة موظف"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(606, -48)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(109, 22)
        Me.Label24.TabIndex = 39
        Me.Label24.Text = "البيانات الوظيفية"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Label52)
        Me.Panel3.Controls.Add(Me.Dep_A)
        Me.Panel3.Controls.Add(Me.Country_A)
        Me.Panel3.Controls.Add(Me.Label30)
        Me.Panel3.Controls.Add(Me.Getting_date_A)
        Me.Panel3.Controls.Add(Me.Button3)
        Me.Panel3.Controls.Add(Me.Label29)
        Me.Panel3.Controls.Add(Me.Costing_A)
        Me.Panel3.Controls.Add(Me.Button6)
        Me.Panel3.Controls.Add(Me.Label28)
        Me.Panel3.Controls.Add(Me.Qual_A)
        Me.Panel3.Controls.Add(Me.Label27)
        Me.Panel3.Controls.Add(Me.Spec_A)
        Me.Panel3.Controls.Add(Me.Label26)
        Me.Panel3.Controls.Add(Me.Label25)
        Me.Panel3.Controls.Add(Me.Cer_id_A)
        Me.Panel3.Controls.Add(Me.Fun_Level_A)
        Me.Panel3.Controls.Add(Me.Job_n_A)
        Me.Panel3.Controls.Add(Me.Annual_A)
        Me.Panel3.Controls.Add(Me.Label22)
        Me.Panel3.Controls.Add(Me.Data_direct_A)
        Me.Panel3.Controls.Add(Me.Label23)
        Me.Panel3.Controls.Add(Me.Label31)
        Me.Panel3.Controls.Add(Me.Fun_Deg_A)
        Me.Panel3.Controls.Add(Me.Label32)
        Me.Panel3.Controls.Add(Me.Label33)
        Me.Panel3.Controls.Add(Me.Label34)
        Me.Panel3.Controls.Add(Me.Emergency_A)
        Me.Panel3.Controls.Add(Me.Label35)
        Me.Panel3.Controls.Add(Me.Data_original_A)
        Me.Panel3.Controls.Add(Me.Label36)
        Me.Panel3.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel3.Location = New System.Drawing.Point(4, 6)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(559, 340)
        Me.Panel3.TabIndex = 38
        '
        'Label52
        '
        Me.Label52.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label52.BackColor = System.Drawing.Color.Gainsboro
        Me.Label52.Location = New System.Drawing.Point(407, 1)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(151, 29)
        Me.Label52.TabIndex = 58
        Me.Label52.Text = "بيانات المؤهل"
        Me.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Dep_A
        '
        Me.Dep_A.FormattingEnabled = True
        Me.Dep_A.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Dep_A.Location = New System.Drawing.Point(13, 208)
        Me.Dep_A.Name = "Dep_A"
        Me.Dep_A.Size = New System.Drawing.Size(129, 24)
        Me.Dep_A.TabIndex = 57
        Me.Dep_A.UseWaitCursor = True
        '
        'Country_A
        '
        Me.Country_A.FormattingEnabled = True
        Me.Country_A.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Country_A.Location = New System.Drawing.Point(13, 178)
        Me.Country_A.Name = "Country_A"
        Me.Country_A.Size = New System.Drawing.Size(129, 24)
        Me.Country_A.TabIndex = 56
        Me.Country_A.UseWaitCursor = True
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(151, 182)
        Me.Label30.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(74, 17)
        Me.Label30.TabIndex = 55
        Me.Label30.Text = "مكان الاصدار"
        Me.Label30.UseWaitCursor = True
        '
        'Getting_date_A
        '
        Me.Getting_date_A.Location = New System.Drawing.Point(13, 143)
        Me.Getting_date_A.Name = "Getting_date_A"
        Me.Getting_date_A.Size = New System.Drawing.Size(127, 24)
        Me.Getting_date_A.TabIndex = 53
        Me.Getting_date_A.UseWaitCursor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(125, 292)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(83, 33)
        Me.Button3.TabIndex = 35
        Me.Button3.Text = "الغاء"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(151, 151)
        Me.Label29.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(77, 17)
        Me.Label29.TabIndex = 54
        Me.Label29.Text = "تاريخ الاصدار"
        Me.Label29.UseWaitCursor = True
        '
        'Costing_A
        '
        Me.Costing_A.FormattingEnabled = True
        Me.Costing_A.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Costing_A.Location = New System.Drawing.Point(11, 109)
        Me.Costing_A.Name = "Costing_A"
        Me.Costing_A.Size = New System.Drawing.Size(129, 24)
        Me.Costing_A.TabIndex = 52
        Me.Costing_A.UseWaitCursor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(21, 292)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(91, 33)
        Me.Button6.TabIndex = 34
        Me.Button6.Text = "اضافة"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(176, 119)
        Me.Label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(38, 17)
        Me.Label28.TabIndex = 51
        Me.Label28.Text = "التقدير"
        Me.Label28.UseWaitCursor = True
        '
        'Qual_A
        '
        Me.Qual_A.FormattingEnabled = True
        Me.Qual_A.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Qual_A.Location = New System.Drawing.Point(11, 77)
        Me.Qual_A.Name = "Qual_A"
        Me.Qual_A.Size = New System.Drawing.Size(129, 24)
        Me.Qual_A.TabIndex = 50
        Me.Qual_A.UseWaitCursor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(177, 84)
        Me.Label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(41, 17)
        Me.Label27.TabIndex = 49
        Me.Label27.Text = "المؤهل"
        Me.Label27.UseWaitCursor = True
        '
        'Spec_A
        '
        Me.Spec_A.FormattingEnabled = True
        Me.Spec_A.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Spec_A.Location = New System.Drawing.Point(11, 41)
        Me.Spec_A.Name = "Spec_A"
        Me.Spec_A.Size = New System.Drawing.Size(129, 24)
        Me.Spec_A.TabIndex = 48
        Me.Spec_A.UseWaitCursor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(162, 47)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(55, 17)
        Me.Label26.TabIndex = 47
        Me.Label26.Text = "التخصص"
        Me.Label26.UseWaitCursor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(423, 271)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(89, 17)
        Me.Label25.TabIndex = 46
        Me.Label25.Text = "رقم وثيقة التخرج"
        Me.Label25.UseWaitCursor = True
        '
        'Cer_id_A
        '
        Me.Cer_id_A.Location = New System.Drawing.Point(246, 268)
        Me.Cer_id_A.Margin = New System.Windows.Forms.Padding(4)
        Me.Cer_id_A.Name = "Cer_id_A"
        Me.Cer_id_A.Size = New System.Drawing.Size(132, 24)
        Me.Cer_id_A.TabIndex = 45
        Me.Cer_id_A.UseWaitCursor = True
        '
        'Fun_Level_A
        '
        Me.Fun_Level_A.FormattingEnabled = True
        Me.Fun_Level_A.Items.AddRange(New Object() {"أعزب", "متزوج"})
        Me.Fun_Level_A.Location = New System.Drawing.Point(246, 201)
        Me.Fun_Level_A.Name = "Fun_Level_A"
        Me.Fun_Level_A.Size = New System.Drawing.Size(131, 24)
        Me.Fun_Level_A.TabIndex = 44
        Me.Fun_Level_A.UseWaitCursor = True
        '
        'Job_n_A
        '
        Me.Job_n_A.FormattingEnabled = True
        Me.Job_n_A.Items.AddRange(New Object() {"أعزب", "متزوج"})
        Me.Job_n_A.Location = New System.Drawing.Point(245, 169)
        Me.Job_n_A.Name = "Job_n_A"
        Me.Job_n_A.Size = New System.Drawing.Size(132, 24)
        Me.Job_n_A.TabIndex = 29
        Me.Job_n_A.UseWaitCursor = True
        '
        'Annual_A
        '
        Me.Annual_A.Location = New System.Drawing.Point(246, 104)
        Me.Annual_A.Margin = New System.Windows.Forms.Padding(4)
        Me.Annual_A.Name = "Annual_A"
        Me.Annual_A.Size = New System.Drawing.Size(132, 24)
        Me.Annual_A.TabIndex = 42
        Me.Annual_A.UseWaitCursor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(397, 107)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(122, 17)
        Me.Label22.TabIndex = 43
        Me.Label22.Text = "رصيد الاجازات السنوية"
        Me.Label22.UseWaitCursor = True
        '
        'Data_direct_A
        '
        Me.Data_direct_A.Location = New System.Drawing.Point(246, 42)
        Me.Data_direct_A.Name = "Data_direct_A"
        Me.Data_direct_A.Size = New System.Drawing.Size(132, 24)
        Me.Data_direct_A.TabIndex = 40
        Me.Data_direct_A.UseWaitCursor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(423, 44)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(100, 17)
        Me.Label23.TabIndex = 41
        Me.Label23.Text = "تاريخ مباشرة العمل"
        Me.Label23.UseWaitCursor = True
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(177, 216)
        Me.Label31.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(51, 17)
        Me.Label31.TabIndex = 39
        Me.Label31.Text = "رقم القسم"
        Me.Label31.UseWaitCursor = True
        '
        'Fun_Deg_A
        '
        Me.Fun_Deg_A.FormattingEnabled = True
        Me.Fun_Deg_A.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Fun_Deg_A.Location = New System.Drawing.Point(246, 235)
        Me.Fun_Deg_A.Name = "Fun_Deg_A"
        Me.Fun_Deg_A.Size = New System.Drawing.Size(132, 24)
        Me.Fun_Deg_A.TabIndex = 38
        Me.Fun_Deg_A.UseWaitCursor = True
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(457, 237)
        Me.Label32.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(40, 17)
        Me.Label32.TabIndex = 37
        Me.Label32.Text = "الدرجة"
        Me.Label32.UseWaitCursor = True
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(423, 204)
        Me.Label33.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(90, 17)
        Me.Label33.TabIndex = 35
        Me.Label33.Text = "المستوي الوظيفي"
        Me.Label33.UseWaitCursor = True
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(449, 172)
        Me.Label34.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(63, 17)
        Me.Label34.TabIndex = 33
        Me.Label34.Text = "اسم الوظيفة"
        Me.Label34.UseWaitCursor = True
        '
        'Emergency_A
        '
        Me.Emergency_A.Location = New System.Drawing.Point(246, 136)
        Me.Emergency_A.Margin = New System.Windows.Forms.Padding(4)
        Me.Emergency_A.Name = "Emergency_A"
        Me.Emergency_A.Size = New System.Drawing.Size(132, 24)
        Me.Emergency_A.TabIndex = 30
        Me.Emergency_A.UseWaitCursor = True
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(396, 139)
        Me.Label35.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(123, 17)
        Me.Label35.TabIndex = 31
        Me.Label35.Text = "رصيد الاجازات الطارئة"
        Me.Label35.UseWaitCursor = True
        '
        'Data_original_A
        '
        Me.Data_original_A.Location = New System.Drawing.Point(246, 72)
        Me.Data_original_A.Name = "Data_original_A"
        Me.Data_original_A.Size = New System.Drawing.Size(132, 24)
        Me.Data_original_A.TabIndex = 28
        Me.Data_original_A.UseWaitCursor = True
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(383, 78)
        Me.Label36.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(140, 17)
        Me.Label36.TabIndex = 29
        Me.Label36.Text = "تاريخ مباشرة العمل الاصلي"
        Me.Label36.UseWaitCursor = True
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(53, -48)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(116, 22)
        Me.Label37.TabIndex = 37
        Me.Label37.Text = "البيانات الشخصية"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Label53)
        Me.Panel4.Controls.Add(Me.Birth_Place_A)
        Me.Panel4.Controls.Add(Me.Conf_Id_A)
        Me.Panel4.Controls.Add(Me.Emp_Id)
        Me.Panel4.Controls.Add(Me.Label38)
        Me.Panel4.Controls.Add(Me.Email_A)
        Me.Panel4.Controls.Add(Me.Emp_Name)
        Me.Panel4.Controls.Add(Me.Label39)
        Me.Panel4.Controls.Add(Me.Label40)
        Me.Panel4.Controls.Add(Me.Phone_A)
        Me.Panel4.Controls.Add(Me.Emp_M_A)
        Me.Panel4.Controls.Add(Me.Label41)
        Me.Panel4.Controls.Add(Me.Label42)
        Me.Panel4.Controls.Add(Me.Address_A)
        Me.Panel4.Controls.Add(Me.Label43)
        Me.Panel4.Controls.Add(Me.Label44)
        Me.Panel4.Controls.Add(Me.Emp_NW_A)
        Me.Panel4.Controls.Add(Me.Nationa_A)
        Me.Panel4.Controls.Add(Me.Label45)
        Me.Panel4.Controls.Add(Me.Label46)
        Me.Panel4.Controls.Add(Me.Conf_Type_A)
        Me.Panel4.Controls.Add(Me.Gender_A)
        Me.Panel4.Controls.Add(Me.Label47)
        Me.Panel4.Controls.Add(Me.Label48)
        Me.Panel4.Controls.Add(Me.Birth_Data_A)
        Me.Panel4.Controls.Add(Me.Social_Case_A)
        Me.Panel4.Controls.Add(Me.Label49)
        Me.Panel4.Controls.Add(Me.Label50)
        Me.Panel4.Controls.Add(Me.Label51)
        Me.Panel4.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel4.Location = New System.Drawing.Point(569, 7)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(603, 339)
        Me.Panel4.TabIndex = 36
        Me.Panel4.UseWaitCursor = True
        '
        'Label53
        '
        Me.Label53.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label53.BackColor = System.Drawing.Color.Gainsboro
        Me.Label53.Location = New System.Drawing.Point(481, 1)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(122, 28)
        Me.Label53.TabIndex = 59
        Me.Label53.Text = "البيانات الشخصية"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label53.UseWaitCursor = True
        '
        'Birth_Place_A
        '
        Me.Birth_Place_A.FormattingEnabled = True
        Me.Birth_Place_A.Items.AddRange(New Object() {"جواز سفر", "بطاقة شخصية"})
        Me.Birth_Place_A.Location = New System.Drawing.Point(347, 210)
        Me.Birth_Place_A.Name = "Birth_Place_A"
        Me.Birth_Place_A.Size = New System.Drawing.Size(129, 24)
        Me.Birth_Place_A.TabIndex = 28
        Me.Birth_Place_A.UseWaitCursor = True
        '
        'Conf_Id_A
        '
        Me.Conf_Id_A.Location = New System.Drawing.Point(347, 107)
        Me.Conf_Id_A.Margin = New System.Windows.Forms.Padding(4)
        Me.Conf_Id_A.Name = "Conf_Id_A"
        Me.Conf_Id_A.Size = New System.Drawing.Size(129, 24)
        Me.Conf_Id_A.TabIndex = 6
        Me.Conf_Id_A.UseWaitCursor = True
        '
        'Emp_Id
        '
        Me.Emp_Id.BackColor = System.Drawing.Color.White
        Me.Emp_Id.Location = New System.Drawing.Point(347, 35)
        Me.Emp_Id.Margin = New System.Windows.Forms.Padding(4)
        Me.Emp_Id.Name = "Emp_Id"
        Me.Emp_Id.ReadOnly = True
        Me.Emp_Id.Size = New System.Drawing.Size(126, 24)
        Me.Emp_Id.TabIndex = 0
        Me.Emp_Id.UseWaitCursor = True
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(491, 38)
        Me.Label38.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(67, 17)
        Me.Label38.TabIndex = 1
        Me.Label38.Text = "رقم الموظف"
        Me.Label38.UseWaitCursor = True
        '
        'Email_A
        '
        Me.Email_A.Location = New System.Drawing.Point(10, 271)
        Me.Email_A.Margin = New System.Windows.Forms.Padding(4)
        Me.Email_A.Name = "Email_A"
        Me.Email_A.Size = New System.Drawing.Size(210, 24)
        Me.Email_A.TabIndex = 27
        Me.Email_A.UseWaitCursor = True
        '
        'Emp_Name
        '
        Me.Emp_Name.Location = New System.Drawing.Point(10, 32)
        Me.Emp_Name.Margin = New System.Windows.Forms.Padding(4)
        Me.Emp_Name.Name = "Emp_Name"
        Me.Emp_Name.Size = New System.Drawing.Size(210, 24)
        Me.Emp_Name.TabIndex = 2
        Me.Emp_Name.UseWaitCursor = True
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(237, 274)
        Me.Label39.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(41, 17)
        Me.Label39.TabIndex = 26
        Me.Label39.Text = "الايميل"
        Me.Label39.UseWaitCursor = True
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(237, 38)
        Me.Label40.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(67, 17)
        Me.Label40.TabIndex = 3
        Me.Label40.Text = "اسم الموظف"
        Me.Label40.UseWaitCursor = True
        '
        'Phone_A
        '
        Me.Phone_A.Location = New System.Drawing.Point(10, 234)
        Me.Phone_A.Margin = New System.Windows.Forms.Padding(4)
        Me.Phone_A.Name = "Phone_A"
        Me.Phone_A.Size = New System.Drawing.Size(210, 24)
        Me.Phone_A.TabIndex = 25
        Me.Phone_A.UseWaitCursor = True
        '
        'Emp_M_A
        '
        Me.Emp_M_A.Location = New System.Drawing.Point(10, 66)
        Me.Emp_M_A.Margin = New System.Windows.Forms.Padding(4)
        Me.Emp_M_A.Name = "Emp_M_A"
        Me.Emp_M_A.Size = New System.Drawing.Size(210, 24)
        Me.Emp_M_A.TabIndex = 4
        Me.Emp_M_A.UseWaitCursor = True
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(237, 239)
        Me.Label41.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(39, 17)
        Me.Label41.TabIndex = 24
        Me.Label41.Text = "الهاتف"
        Me.Label41.UseWaitCursor = True
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(237, 71)
        Me.Label42.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(44, 17)
        Me.Label42.TabIndex = 5
        Me.Label42.Text = "اسم الام"
        Me.Label42.UseWaitCursor = True
        '
        'Address_A
        '
        Me.Address_A.Location = New System.Drawing.Point(10, 200)
        Me.Address_A.Margin = New System.Windows.Forms.Padding(4)
        Me.Address_A.Name = "Address_A"
        Me.Address_A.Size = New System.Drawing.Size(210, 24)
        Me.Address_A.TabIndex = 23
        Me.Address_A.UseWaitCursor = True
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(491, 71)
        Me.Label43.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(91, 17)
        Me.Label43.TabIndex = 7
        Me.Label43.Text = "نوع وثيقة الاثبات"
        Me.Label43.UseWaitCursor = True
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(239, 206)
        Me.Label44.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(41, 17)
        Me.Label44.TabIndex = 22
        Me.Label44.Text = "العنوان"
        Me.Label44.UseWaitCursor = True
        '
        'Emp_NW_A
        '
        Me.Emp_NW_A.Location = New System.Drawing.Point(347, 142)
        Me.Emp_NW_A.Margin = New System.Windows.Forms.Padding(4)
        Me.Emp_NW_A.Name = "Emp_NW_A"
        Me.Emp_NW_A.Size = New System.Drawing.Size(129, 24)
        Me.Emp_NW_A.TabIndex = 8
        Me.Emp_NW_A.UseWaitCursor = True
        '
        'Nationa_A
        '
        Me.Nationa_A.Location = New System.Drawing.Point(10, 167)
        Me.Nationa_A.Margin = New System.Windows.Forms.Padding(4)
        Me.Nationa_A.Name = "Nationa_A"
        Me.Nationa_A.Size = New System.Drawing.Size(210, 24)
        Me.Nationa_A.TabIndex = 21
        Me.Nationa_A.UseWaitCursor = True
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(491, 110)
        Me.Label45.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(58, 17)
        Me.Label45.TabIndex = 9
        Me.Label45.Text = "رقم الوثيقة"
        Me.Label45.UseWaitCursor = True
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(237, 173)
        Me.Label46.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(44, 17)
        Me.Label46.TabIndex = 20
        Me.Label46.Text = "الجنسية"
        Me.Label46.UseWaitCursor = True
        '
        'Conf_Type_A
        '
        Me.Conf_Type_A.FormattingEnabled = True
        Me.Conf_Type_A.Items.AddRange(New Object() {"جواز سفر", "بطاقة شخصية"})
        Me.Conf_Type_A.Location = New System.Drawing.Point(347, 68)
        Me.Conf_Type_A.Name = "Conf_Type_A"
        Me.Conf_Type_A.Size = New System.Drawing.Size(129, 24)
        Me.Conf_Type_A.TabIndex = 10
        Me.Conf_Type_A.UseWaitCursor = True
        '
        'Gender_A
        '
        Me.Gender_A.FormattingEnabled = True
        Me.Gender_A.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Gender_A.Location = New System.Drawing.Point(86, 135)
        Me.Gender_A.Name = "Gender_A"
        Me.Gender_A.Size = New System.Drawing.Size(134, 24)
        Me.Gender_A.TabIndex = 19
        Me.Gender_A.UseWaitCursor = True
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(491, 145)
        Me.Label47.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(68, 17)
        Me.Label47.TabIndex = 11
        Me.Label47.Text = "الرقم الوطني"
        Me.Label47.UseWaitCursor = True
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(237, 142)
        Me.Label48.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(38, 17)
        Me.Label48.TabIndex = 18
        Me.Label48.Text = "الجنس"
        Me.Label48.UseWaitCursor = True
        '
        'Birth_Data_A
        '
        Me.Birth_Data_A.Location = New System.Drawing.Point(347, 175)
        Me.Birth_Data_A.Name = "Birth_Data_A"
        Me.Birth_Data_A.Size = New System.Drawing.Size(129, 24)
        Me.Birth_Data_A.TabIndex = 12
        Me.Birth_Data_A.UseWaitCursor = True
        '
        'Social_Case_A
        '
        Me.Social_Case_A.FormattingEnabled = True
        Me.Social_Case_A.Items.AddRange(New Object() {"أعزب", "متزوج"})
        Me.Social_Case_A.Location = New System.Drawing.Point(86, 104)
        Me.Social_Case_A.Name = "Social_Case_A"
        Me.Social_Case_A.Size = New System.Drawing.Size(134, 24)
        Me.Social_Case_A.TabIndex = 17
        Me.Social_Case_A.UseWaitCursor = True
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(491, 180)
        Me.Label49.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(68, 17)
        Me.Label49.TabIndex = 13
        Me.Label49.Text = "تاريخ الميلاد"
        Me.Label49.UseWaitCursor = True
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(237, 110)
        Me.Label50.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(88, 17)
        Me.Label50.TabIndex = 16
        Me.Label50.Text = "الحالة الاجتماعية"
        Me.Label50.UseWaitCursor = True
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(491, 213)
        Me.Label51.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(65, 17)
        Me.Label51.TabIndex = 15
        Me.Label51.Text = "مكان الميلاد"
        Me.Label51.UseWaitCursor = True
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.Panel5)
        Me.TabPage8.Controls.Add(Me.Panel6)
        Me.TabPage8.Location = New System.Drawing.Point(4, 29)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(1175, 364)
        Me.TabPage8.TabIndex = 1
        Me.TabPage8.Text = "تعديل بيانات الموظف"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.Button10)
        Me.Panel5.Controls.Add(Me.Label54)
        Me.Panel5.Controls.Add(Me.Dep_id_E)
        Me.Panel5.Controls.Add(Me.Country_E)
        Me.Panel5.Controls.Add(Me.Label55)
        Me.Panel5.Controls.Add(Me.Getting_date_E)
        Me.Panel5.Controls.Add(Me.Button7)
        Me.Panel5.Controls.Add(Me.Label56)
        Me.Panel5.Controls.Add(Me.Costing_E)
        Me.Panel5.Controls.Add(Me.Button8)
        Me.Panel5.Controls.Add(Me.Label57)
        Me.Panel5.Controls.Add(Me.Qual_E)
        Me.Panel5.Controls.Add(Me.Label58)
        Me.Panel5.Controls.Add(Me.Spec_E)
        Me.Panel5.Controls.Add(Me.Label59)
        Me.Panel5.Controls.Add(Me.Label60)
        Me.Panel5.Controls.Add(Me.Cer_id_E)
        Me.Panel5.Controls.Add(Me.Fun_Level_E)
        Me.Panel5.Controls.Add(Me.Job_E)
        Me.Panel5.Controls.Add(Me.Annual_E)
        Me.Panel5.Controls.Add(Me.Label61)
        Me.Panel5.Controls.Add(Me.Data_direct_E)
        Me.Panel5.Controls.Add(Me.Label62)
        Me.Panel5.Controls.Add(Me.Label63)
        Me.Panel5.Controls.Add(Me.Fun_Deg_E)
        Me.Panel5.Controls.Add(Me.Label64)
        Me.Panel5.Controls.Add(Me.Label65)
        Me.Panel5.Controls.Add(Me.Label66)
        Me.Panel5.Controls.Add(Me.Emergency_E)
        Me.Panel5.Controls.Add(Me.Label67)
        Me.Panel5.Controls.Add(Me.Data_original_E)
        Me.Panel5.Controls.Add(Me.Label68)
        Me.Panel5.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel5.Location = New System.Drawing.Point(5, 6)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(577, 329)
        Me.Panel5.TabIndex = 40
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(214, 292)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(83, 33)
        Me.Button10.TabIndex = 59
        Me.Button10.Text = "بحث"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Label54
        '
        Me.Label54.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label54.BackColor = System.Drawing.Color.Gainsboro
        Me.Label54.Location = New System.Drawing.Point(407, 1)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(169, 18)
        Me.Label54.TabIndex = 58
        Me.Label54.Text = "البيانات الشخصية"
        Me.Label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Dep_id_E
        '
        Me.Dep_id_E.FormattingEnabled = True
        Me.Dep_id_E.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Dep_id_E.Location = New System.Drawing.Point(13, 208)
        Me.Dep_id_E.Name = "Dep_id_E"
        Me.Dep_id_E.Size = New System.Drawing.Size(129, 24)
        Me.Dep_id_E.TabIndex = 57
        Me.Dep_id_E.UseWaitCursor = True
        '
        'Country_E
        '
        Me.Country_E.FormattingEnabled = True
        Me.Country_E.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Country_E.Location = New System.Drawing.Point(13, 178)
        Me.Country_E.Name = "Country_E"
        Me.Country_E.Size = New System.Drawing.Size(129, 24)
        Me.Country_E.TabIndex = 56
        Me.Country_E.UseWaitCursor = True
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(151, 182)
        Me.Label55.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(74, 17)
        Me.Label55.TabIndex = 55
        Me.Label55.Text = "مكان الاصدار"
        Me.Label55.UseWaitCursor = True
        '
        'Getting_date_E
        '
        Me.Getting_date_E.Location = New System.Drawing.Point(13, 143)
        Me.Getting_date_E.Name = "Getting_date_E"
        Me.Getting_date_E.Size = New System.Drawing.Size(127, 24)
        Me.Getting_date_E.TabIndex = 53
        Me.Getting_date_E.UseWaitCursor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(125, 292)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(83, 33)
        Me.Button7.TabIndex = 35
        Me.Button7.Text = "الغاء"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(151, 151)
        Me.Label56.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(77, 17)
        Me.Label56.TabIndex = 54
        Me.Label56.Text = "تاريخ الاصدار"
        Me.Label56.UseWaitCursor = True
        '
        'Costing_E
        '
        Me.Costing_E.FormattingEnabled = True
        Me.Costing_E.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Costing_E.Location = New System.Drawing.Point(11, 109)
        Me.Costing_E.Name = "Costing_E"
        Me.Costing_E.Size = New System.Drawing.Size(129, 24)
        Me.Costing_E.TabIndex = 52
        Me.Costing_E.UseWaitCursor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(21, 292)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(91, 33)
        Me.Button8.TabIndex = 34
        Me.Button8.Text = "حفظ"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(176, 119)
        Me.Label57.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(38, 17)
        Me.Label57.TabIndex = 51
        Me.Label57.Text = "التقدير"
        Me.Label57.UseWaitCursor = True
        '
        'Qual_E
        '
        Me.Qual_E.FormattingEnabled = True
        Me.Qual_E.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Qual_E.Location = New System.Drawing.Point(11, 77)
        Me.Qual_E.Name = "Qual_E"
        Me.Qual_E.Size = New System.Drawing.Size(129, 24)
        Me.Qual_E.TabIndex = 50
        Me.Qual_E.UseWaitCursor = True
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(177, 84)
        Me.Label58.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(41, 17)
        Me.Label58.TabIndex = 49
        Me.Label58.Text = "المؤهل"
        Me.Label58.UseWaitCursor = True
        '
        'Spec_E
        '
        Me.Spec_E.FormattingEnabled = True
        Me.Spec_E.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Spec_E.Location = New System.Drawing.Point(11, 41)
        Me.Spec_E.Name = "Spec_E"
        Me.Spec_E.Size = New System.Drawing.Size(129, 24)
        Me.Spec_E.TabIndex = 48
        Me.Spec_E.UseWaitCursor = True
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(162, 47)
        Me.Label59.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(55, 17)
        Me.Label59.TabIndex = 47
        Me.Label59.Text = "التخصص"
        Me.Label59.UseWaitCursor = True
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(439, 245)
        Me.Label60.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(89, 17)
        Me.Label60.TabIndex = 46
        Me.Label60.Text = "رقم وثيقة التخرج"
        Me.Label60.UseWaitCursor = True
        '
        'Cer_id_E
        '
        Me.Cer_id_E.Location = New System.Drawing.Point(261, 242)
        Me.Cer_id_E.Margin = New System.Windows.Forms.Padding(4)
        Me.Cer_id_E.Name = "Cer_id_E"
        Me.Cer_id_E.Size = New System.Drawing.Size(132, 24)
        Me.Cer_id_E.TabIndex = 45
        Me.Cer_id_E.UseWaitCursor = True
        '
        'Fun_Level_E
        '
        Me.Fun_Level_E.FormattingEnabled = True
        Me.Fun_Level_E.Items.AddRange(New Object() {"أعزب", "متزوج"})
        Me.Fun_Level_E.Location = New System.Drawing.Point(262, 201)
        Me.Fun_Level_E.Name = "Fun_Level_E"
        Me.Fun_Level_E.Size = New System.Drawing.Size(131, 24)
        Me.Fun_Level_E.TabIndex = 44
        Me.Fun_Level_E.UseWaitCursor = True
        '
        'Job_E
        '
        Me.Job_E.FormattingEnabled = True
        Me.Job_E.Items.AddRange(New Object() {"أعزب", "متزوج"})
        Me.Job_E.Location = New System.Drawing.Point(261, 169)
        Me.Job_E.Name = "Job_E"
        Me.Job_E.Size = New System.Drawing.Size(132, 24)
        Me.Job_E.TabIndex = 29
        Me.Job_E.UseWaitCursor = True
        '
        'Annual_E
        '
        Me.Annual_E.Location = New System.Drawing.Point(262, 104)
        Me.Annual_E.Margin = New System.Windows.Forms.Padding(4)
        Me.Annual_E.Name = "Annual_E"
        Me.Annual_E.Size = New System.Drawing.Size(132, 24)
        Me.Annual_E.TabIndex = 42
        Me.Annual_E.UseWaitCursor = True
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(413, 107)
        Me.Label61.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(122, 17)
        Me.Label61.TabIndex = 43
        Me.Label61.Text = "رصيد الاجازات السنوية"
        Me.Label61.UseWaitCursor = True
        '
        'Data_direct_E
        '
        Me.Data_direct_E.Location = New System.Drawing.Point(262, 42)
        Me.Data_direct_E.Name = "Data_direct_E"
        Me.Data_direct_E.Size = New System.Drawing.Size(132, 24)
        Me.Data_direct_E.TabIndex = 40
        Me.Data_direct_E.UseWaitCursor = True
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(439, 44)
        Me.Label62.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(100, 17)
        Me.Label62.TabIndex = 41
        Me.Label62.Text = "تاريخ مباشرة العمل"
        Me.Label62.UseWaitCursor = True
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(177, 216)
        Me.Label63.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(51, 17)
        Me.Label63.TabIndex = 39
        Me.Label63.Text = "رقم القسم"
        Me.Label63.UseWaitCursor = True
        '
        'Fun_Deg_E
        '
        Me.Fun_Deg_E.FormattingEnabled = True
        Me.Fun_Deg_E.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Fun_Deg_E.Location = New System.Drawing.Point(11, 242)
        Me.Fun_Deg_E.Name = "Fun_Deg_E"
        Me.Fun_Deg_E.Size = New System.Drawing.Size(132, 24)
        Me.Fun_Deg_E.TabIndex = 38
        Me.Fun_Deg_E.UseWaitCursor = True
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(182, 245)
        Me.Label64.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(40, 17)
        Me.Label64.TabIndex = 37
        Me.Label64.Text = "الدرجة"
        Me.Label64.UseWaitCursor = True
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(439, 204)
        Me.Label65.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(90, 17)
        Me.Label65.TabIndex = 35
        Me.Label65.Text = "المستوي الوظيفي"
        Me.Label65.UseWaitCursor = True
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(465, 172)
        Me.Label66.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(63, 17)
        Me.Label66.TabIndex = 33
        Me.Label66.Text = "اسم الوظيفة"
        Me.Label66.UseWaitCursor = True
        '
        'Emergency_E
        '
        Me.Emergency_E.Location = New System.Drawing.Point(262, 136)
        Me.Emergency_E.Margin = New System.Windows.Forms.Padding(4)
        Me.Emergency_E.Name = "Emergency_E"
        Me.Emergency_E.Size = New System.Drawing.Size(132, 24)
        Me.Emergency_E.TabIndex = 30
        Me.Emergency_E.UseWaitCursor = True
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(412, 139)
        Me.Label67.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(123, 17)
        Me.Label67.TabIndex = 31
        Me.Label67.Text = "رصيد الاجازات الطارئة"
        Me.Label67.UseWaitCursor = True
        '
        'Data_original_E
        '
        Me.Data_original_E.Location = New System.Drawing.Point(262, 72)
        Me.Data_original_E.Name = "Data_original_E"
        Me.Data_original_E.Size = New System.Drawing.Size(132, 24)
        Me.Data_original_E.TabIndex = 28
        Me.Data_original_E.UseWaitCursor = True
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Location = New System.Drawing.Point(399, 78)
        Me.Label68.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(140, 17)
        Me.Label68.TabIndex = 29
        Me.Label68.Text = "تاريخ مباشرة العمل الاصلي"
        Me.Label68.UseWaitCursor = True
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.Label69)
        Me.Panel6.Controls.Add(Me.Birth_Place_E)
        Me.Panel6.Controls.Add(Me.Conf_id_E)
        Me.Panel6.Controls.Add(Me.emp_E)
        Me.Panel6.Controls.Add(Me.Label70)
        Me.Panel6.Controls.Add(Me.Email_E)
        Me.Panel6.Controls.Add(Me.e_name_E)
        Me.Panel6.Controls.Add(Me.Label71)
        Me.Panel6.Controls.Add(Me.Label72)
        Me.Panel6.Controls.Add(Me.Phon_E)
        Me.Panel6.Controls.Add(Me.emp_m_E)
        Me.Panel6.Controls.Add(Me.Label73)
        Me.Panel6.Controls.Add(Me.Label74)
        Me.Panel6.Controls.Add(Me.Address_E)
        Me.Panel6.Controls.Add(Me.Label75)
        Me.Panel6.Controls.Add(Me.Label76)
        Me.Panel6.Controls.Add(Me.emp_NW_E)
        Me.Panel6.Controls.Add(Me.Nationa_E)
        Me.Panel6.Controls.Add(Me.Label77)
        Me.Panel6.Controls.Add(Me.Label78)
        Me.Panel6.Controls.Add(Me.Conf_type_E)
        Me.Panel6.Controls.Add(Me.Gender_E)
        Me.Panel6.Controls.Add(Me.Label79)
        Me.Panel6.Controls.Add(Me.Label80)
        Me.Panel6.Controls.Add(Me.Birth_date_E)
        Me.Panel6.Controls.Add(Me.Social_case_E)
        Me.Panel6.Controls.Add(Me.Label81)
        Me.Panel6.Controls.Add(Me.Label82)
        Me.Panel6.Controls.Add(Me.Label83)
        Me.Panel6.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel6.Location = New System.Drawing.Point(588, 7)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(589, 328)
        Me.Panel6.TabIndex = 39
        Me.Panel6.UseWaitCursor = True
        '
        'Label69
        '
        Me.Label69.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label69.BackColor = System.Drawing.Color.Gainsboro
        Me.Label69.Location = New System.Drawing.Point(481, 1)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(108, 17)
        Me.Label69.TabIndex = 59
        Me.Label69.Text = "البيانات الشخصية"
        Me.Label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label69.UseWaitCursor = True
        '
        'Birth_Place_E
        '
        Me.Birth_Place_E.FormattingEnabled = True
        Me.Birth_Place_E.Items.AddRange(New Object() {"جواز سفر", "بطاقة شخصية"})
        Me.Birth_Place_E.Location = New System.Drawing.Point(326, 217)
        Me.Birth_Place_E.Name = "Birth_Place_E"
        Me.Birth_Place_E.Size = New System.Drawing.Size(129, 24)
        Me.Birth_Place_E.TabIndex = 28
        Me.Birth_Place_E.UseWaitCursor = True
        '
        'Conf_id_E
        '
        Me.Conf_id_E.Location = New System.Drawing.Point(326, 114)
        Me.Conf_id_E.Margin = New System.Windows.Forms.Padding(4)
        Me.Conf_id_E.Name = "Conf_id_E"
        Me.Conf_id_E.Size = New System.Drawing.Size(129, 24)
        Me.Conf_id_E.TabIndex = 6
        Me.Conf_id_E.UseWaitCursor = True
        '
        'emp_E
        '
        Me.emp_E.BackColor = System.Drawing.Color.White
        Me.emp_E.Location = New System.Drawing.Point(326, 42)
        Me.emp_E.Margin = New System.Windows.Forms.Padding(4)
        Me.emp_E.Name = "emp_E"
        Me.emp_E.ReadOnly = True
        Me.emp_E.Size = New System.Drawing.Size(126, 24)
        Me.emp_E.TabIndex = 0
        Me.emp_E.UseWaitCursor = True
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Location = New System.Drawing.Point(470, 45)
        Me.Label70.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(67, 17)
        Me.Label70.TabIndex = 1
        Me.Label70.Text = "رقم الموظف"
        Me.Label70.UseWaitCursor = True
        '
        'Email_E
        '
        Me.Email_E.Location = New System.Drawing.Point(4, 278)
        Me.Email_E.Margin = New System.Windows.Forms.Padding(4)
        Me.Email_E.Name = "Email_E"
        Me.Email_E.Size = New System.Drawing.Size(193, 24)
        Me.Email_E.TabIndex = 27
        Me.Email_E.UseWaitCursor = True
        '
        'e_name_E
        '
        Me.e_name_E.Location = New System.Drawing.Point(4, 39)
        Me.e_name_E.Margin = New System.Windows.Forms.Padding(4)
        Me.e_name_E.Name = "e_name_E"
        Me.e_name_E.Size = New System.Drawing.Size(193, 24)
        Me.e_name_E.TabIndex = 2
        Me.e_name_E.UseWaitCursor = True
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(214, 281)
        Me.Label71.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(41, 17)
        Me.Label71.TabIndex = 26
        Me.Label71.Text = "الايميل"
        Me.Label71.UseWaitCursor = True
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Location = New System.Drawing.Point(214, 45)
        Me.Label72.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(67, 17)
        Me.Label72.TabIndex = 3
        Me.Label72.Text = "اسم الموظف"
        Me.Label72.UseWaitCursor = True
        '
        'Phon_E
        '
        Me.Phon_E.Location = New System.Drawing.Point(4, 241)
        Me.Phon_E.Margin = New System.Windows.Forms.Padding(4)
        Me.Phon_E.Name = "Phon_E"
        Me.Phon_E.Size = New System.Drawing.Size(193, 24)
        Me.Phon_E.TabIndex = 25
        Me.Phon_E.UseWaitCursor = True
        '
        'emp_m_E
        '
        Me.emp_m_E.Location = New System.Drawing.Point(4, 73)
        Me.emp_m_E.Margin = New System.Windows.Forms.Padding(4)
        Me.emp_m_E.Name = "emp_m_E"
        Me.emp_m_E.Size = New System.Drawing.Size(193, 24)
        Me.emp_m_E.TabIndex = 4
        Me.emp_m_E.UseWaitCursor = True
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Location = New System.Drawing.Point(214, 246)
        Me.Label73.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(39, 17)
        Me.Label73.TabIndex = 24
        Me.Label73.Text = "الهاتف"
        Me.Label73.UseWaitCursor = True
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Location = New System.Drawing.Point(214, 78)
        Me.Label74.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(44, 17)
        Me.Label74.TabIndex = 5
        Me.Label74.Text = "اسم الام"
        Me.Label74.UseWaitCursor = True
        '
        'Address_E
        '
        Me.Address_E.Location = New System.Drawing.Point(4, 207)
        Me.Address_E.Margin = New System.Windows.Forms.Padding(4)
        Me.Address_E.Name = "Address_E"
        Me.Address_E.Size = New System.Drawing.Size(193, 24)
        Me.Address_E.TabIndex = 23
        Me.Address_E.UseWaitCursor = True
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Location = New System.Drawing.Point(470, 78)
        Me.Label75.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(91, 17)
        Me.Label75.TabIndex = 7
        Me.Label75.Text = "نوع وثيقة الاثبات"
        Me.Label75.UseWaitCursor = True
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Location = New System.Drawing.Point(216, 213)
        Me.Label76.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(41, 17)
        Me.Label76.TabIndex = 22
        Me.Label76.Text = "العنوان"
        Me.Label76.UseWaitCursor = True
        '
        'emp_NW_E
        '
        Me.emp_NW_E.Location = New System.Drawing.Point(326, 149)
        Me.emp_NW_E.Margin = New System.Windows.Forms.Padding(4)
        Me.emp_NW_E.Name = "emp_NW_E"
        Me.emp_NW_E.Size = New System.Drawing.Size(129, 24)
        Me.emp_NW_E.TabIndex = 8
        Me.emp_NW_E.UseWaitCursor = True
        '
        'Nationa_E
        '
        Me.Nationa_E.Location = New System.Drawing.Point(4, 174)
        Me.Nationa_E.Margin = New System.Windows.Forms.Padding(4)
        Me.Nationa_E.Name = "Nationa_E"
        Me.Nationa_E.Size = New System.Drawing.Size(193, 24)
        Me.Nationa_E.TabIndex = 21
        Me.Nationa_E.UseWaitCursor = True
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Location = New System.Drawing.Point(470, 117)
        Me.Label77.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(58, 17)
        Me.Label77.TabIndex = 9
        Me.Label77.Text = "رقم الوثيقة"
        Me.Label77.UseWaitCursor = True
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Location = New System.Drawing.Point(214, 180)
        Me.Label78.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(44, 17)
        Me.Label78.TabIndex = 20
        Me.Label78.Text = "الجنسية"
        Me.Label78.UseWaitCursor = True
        '
        'Conf_type_E
        '
        Me.Conf_type_E.FormattingEnabled = True
        Me.Conf_type_E.Items.AddRange(New Object() {"جواز سفر", "بطاقة شخصية"})
        Me.Conf_type_E.Location = New System.Drawing.Point(326, 75)
        Me.Conf_type_E.Name = "Conf_type_E"
        Me.Conf_type_E.Size = New System.Drawing.Size(129, 24)
        Me.Conf_type_E.TabIndex = 10
        Me.Conf_type_E.UseWaitCursor = True
        '
        'Gender_E
        '
        Me.Gender_E.FormattingEnabled = True
        Me.Gender_E.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Gender_E.Location = New System.Drawing.Point(63, 142)
        Me.Gender_E.Name = "Gender_E"
        Me.Gender_E.Size = New System.Drawing.Size(134, 24)
        Me.Gender_E.TabIndex = 19
        Me.Gender_E.UseWaitCursor = True
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Location = New System.Drawing.Point(470, 152)
        Me.Label79.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(68, 17)
        Me.Label79.TabIndex = 11
        Me.Label79.Text = "الرقم الوطني"
        Me.Label79.UseWaitCursor = True
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Location = New System.Drawing.Point(214, 149)
        Me.Label80.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(38, 17)
        Me.Label80.TabIndex = 18
        Me.Label80.Text = "الجنس"
        Me.Label80.UseWaitCursor = True
        '
        'Birth_date_E
        '
        Me.Birth_date_E.Location = New System.Drawing.Point(326, 182)
        Me.Birth_date_E.Name = "Birth_date_E"
        Me.Birth_date_E.Size = New System.Drawing.Size(129, 24)
        Me.Birth_date_E.TabIndex = 12
        Me.Birth_date_E.UseWaitCursor = True
        '
        'Social_case_E
        '
        Me.Social_case_E.FormattingEnabled = True
        Me.Social_case_E.Items.AddRange(New Object() {"أعزب", "متزوج"})
        Me.Social_case_E.Location = New System.Drawing.Point(63, 111)
        Me.Social_case_E.Name = "Social_case_E"
        Me.Social_case_E.Size = New System.Drawing.Size(134, 24)
        Me.Social_case_E.TabIndex = 17
        Me.Social_case_E.UseWaitCursor = True
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Location = New System.Drawing.Point(470, 187)
        Me.Label81.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(68, 17)
        Me.Label81.TabIndex = 13
        Me.Label81.Text = "تاريخ الميلاد"
        Me.Label81.UseWaitCursor = True
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Location = New System.Drawing.Point(214, 117)
        Me.Label82.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(88, 17)
        Me.Label82.TabIndex = 16
        Me.Label82.Text = "الحالة الاجتماعية"
        Me.Label82.UseWaitCursor = True
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Location = New System.Drawing.Point(470, 220)
        Me.Label83.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(65, 17)
        Me.Label83.TabIndex = 15
        Me.Label83.Text = "مكان الميلاد"
        Me.Label83.UseWaitCursor = True
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.Button11)
        Me.TabPage9.Controls.Add(Me.Button9)
        Me.TabPage9.Controls.Add(Me.Label84)
        Me.TabPage9.Controls.Add(Me.Family_Serah)
        Me.TabPage9.Controls.Add(Me.DataGridView3)
        Me.TabPage9.Location = New System.Drawing.Point(4, 29)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(1175, 364)
        Me.TabPage9.TabIndex = 2
        Me.TabPage9.Text = "عائلة الموظف"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(478, 312)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(169, 41)
        Me.Button11.TabIndex = 8
        Me.Button11.Text = "تعديل بيانات الفرد"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(653, 312)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(88, 41)
        Me.Button9.TabIndex = 7
        Me.Button9.Text = "اضافة فرد"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Label84
        '
        Me.Label84.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(785, -1)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(76, 35)
        Me.Label84.TabIndex = 5
        Me.Label84.Text = "بحث :"
        Me.Label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Family_Serah
        '
        Me.Family_Serah.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Family_Serah.Location = New System.Drawing.Point(388, 5)
        Me.Family_Serah.Name = "Family_Serah"
        Me.Family_Serah.Size = New System.Drawing.Size(395, 24)
        Me.Family_Serah.TabIndex = 6
        Me.Family_Serah.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'DataGridView3
        '
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Location = New System.Drawing.Point(13, 38)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.RowTemplate.Height = 26
        Me.DataGridView3.Size = New System.Drawing.Size(1154, 268)
        Me.DataGridView3.TabIndex = 4
        '
        'TabPage17
        '
        Me.TabPage17.Location = New System.Drawing.Point(4, 29)
        Me.TabPage17.Name = "TabPage17"
        Me.TabPage17.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage17.Size = New System.Drawing.Size(1175, 364)
        Me.TabPage17.TabIndex = 3
        Me.TabPage17.Text = "حالة الموظف"
        Me.TabPage17.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(796, 2)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 35)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "بحث :"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_Emp
        '
        Me.txt_Emp.Location = New System.Drawing.Point(399, 9)
        Me.txt_Emp.Name = "txt_Emp"
        Me.txt_Emp.Size = New System.Drawing.Size(395, 24)
        Me.txt_Emp.TabIndex = 2
        Me.txt_Emp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.BackColor = System.Drawing.Color.DarkGray
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(1051, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(145, 28)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "بيانات الموظفين"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(11, 41)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 26
        Me.DataGridView1.Size = New System.Drawing.Size(1175, 280)
        Me.DataGridView1.TabIndex = 0
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.Emp_P)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.HotTrack = True
        Me.TabControl1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.TabControl1.Location = New System.Drawing.Point(-2, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TabControl1.RightToLeftLayout = True
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.ShowToolTips = True
        Me.TabControl1.Size = New System.Drawing.Size(1207, 770)
        Me.TabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl1.TabIndex = 3
        '
        'Button53
        '
        Me.Button53.Location = New System.Drawing.Point(528, 292)
        Me.Button53.Name = "Button53"
        Me.Button53.Size = New System.Drawing.Size(217, 36)
        Me.Button53.TabIndex = 25
        Me.Button53.Text = "انشاء نسخة احتياطية لقاعدة البيانات"
        Me.Button53.UseVisualStyleBackColor = True
        '
        'Home
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1207, 749)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Home"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.RightToLeftLayout = True
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "الشاشة الرئسية"
        Me.TabPage6.ResumeLayout(False)
        Me.TabControl6.ResumeLayout(False)
        Me.TabPage15.ResumeLayout(False)
        Me.TabPage15.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        CType(Me.DataGridView8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage16.ResumeLayout(False)
        Me.GroupBox11.ResumeLayout(False)
        CType(Me.DataGridView13, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox10.ResumeLayout(False)
        CType(Me.DataGridView12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox9.ResumeLayout(False)
        CType(Me.DataGridView11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox8.ResumeLayout(False)
        CType(Me.DataGridView10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        CType(Me.DataGridView9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        CType(Me.dgvQl, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.dgvPl, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.TabControl5.ResumeLayout(False)
        Me.TabPage13.ResumeLayout(False)
        Me.TabPage13.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        CType(Me.DataGridView6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage14.ResumeLayout(False)
        Me.TabPage14.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        CType(Me.DataGridView7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabControl4.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabControl3.ResumeLayout(False)
        Me.TabPage10.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.TabPage11.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.TabPage12.ResumeLayout(False)
        Me.TabPage12.PerformLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Emp_P.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabControl3 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage10 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Emp_name_A As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Emp_id_A As System.Windows.Forms.TextBox
    Friend WithEvents Day_Emergency_A As System.Windows.Forms.TextBox
    Friend WithEvents Day_Annual_A As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents H_type_A As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents H_end_A As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents H_start_A As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TabPage11 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Emp_name_E As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Emp_id_E As System.Windows.Forms.TextBox
    Friend WithEvents Day_Emergency_E As System.Windows.Forms.TextBox
    Friend WithEvents Day_Annual_E As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents H_type_E As System.Windows.Forms.ComboBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents H_end_E As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents H_start_E As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents TabPage12 As System.Windows.Forms.TabPage
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txt_H As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents Emp_P As System.Windows.Forms.TabPage
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_Emp As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Dep_A As System.Windows.Forms.ComboBox
    Friend WithEvents Country_A As System.Windows.Forms.ComboBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Getting_date_A As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Costing_A As System.Windows.Forms.ComboBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Qual_A As System.Windows.Forms.ComboBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Spec_A As System.Windows.Forms.ComboBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Cer_id_A As System.Windows.Forms.TextBox
    Friend WithEvents Fun_Level_A As System.Windows.Forms.ComboBox
    Friend WithEvents Job_n_A As System.Windows.Forms.ComboBox
    Friend WithEvents Annual_A As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Data_direct_A As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Fun_Deg_A As System.Windows.Forms.ComboBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Emergency_A As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Data_original_A As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Birth_Place_A As System.Windows.Forms.ComboBox
    Friend WithEvents Conf_Id_A As System.Windows.Forms.TextBox
    Friend WithEvents Emp_Id As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Email_A As System.Windows.Forms.TextBox
    Friend WithEvents Emp_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Phone_A As System.Windows.Forms.TextBox
    Friend WithEvents Emp_M_A As System.Windows.Forms.TextBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Address_A As System.Windows.Forms.TextBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Emp_NW_A As System.Windows.Forms.TextBox
    Friend WithEvents Nationa_A As System.Windows.Forms.TextBox
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Conf_Type_A As System.Windows.Forms.ComboBox
    Friend WithEvents Gender_A As System.Windows.Forms.ComboBox
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Birth_Data_A As System.Windows.Forms.DateTimePicker
    Friend WithEvents Social_Case_A As System.Windows.Forms.ComboBox
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Dep_id_E As System.Windows.Forms.ComboBox
    Friend WithEvents Country_E As System.Windows.Forms.ComboBox
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Getting_date_E As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Costing_E As System.Windows.Forms.ComboBox
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Qual_E As System.Windows.Forms.ComboBox
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Spec_E As System.Windows.Forms.ComboBox
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Cer_id_E As System.Windows.Forms.TextBox
    Friend WithEvents Fun_Level_E As System.Windows.Forms.ComboBox
    Friend WithEvents Job_E As System.Windows.Forms.ComboBox
    Friend WithEvents Annual_E As System.Windows.Forms.TextBox
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Data_direct_E As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Fun_Deg_E As System.Windows.Forms.ComboBox
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Emergency_E As System.Windows.Forms.TextBox
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Data_original_E As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Birth_Place_E As System.Windows.Forms.ComboBox
    Friend WithEvents Conf_id_E As System.Windows.Forms.TextBox
    Friend WithEvents emp_E As System.Windows.Forms.TextBox
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Email_E As System.Windows.Forms.TextBox
    Friend WithEvents e_name_E As System.Windows.Forms.TextBox
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Phon_E As System.Windows.Forms.TextBox
    Friend WithEvents emp_m_E As System.Windows.Forms.TextBox
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Address_E As System.Windows.Forms.TextBox
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents emp_NW_E As System.Windows.Forms.TextBox
    Friend WithEvents Nationa_E As System.Windows.Forms.TextBox
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Conf_type_E As System.Windows.Forms.ComboBox
    Friend WithEvents Gender_E As System.Windows.Forms.ComboBox
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Birth_date_E As System.Windows.Forms.DateTimePicker
    Friend WithEvents Social_case_E As System.Windows.Forms.ComboBox
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Family_Serah As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents TabControl4 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents txt_mang As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView4 As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker12 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents ComboBox23 As System.Windows.Forms.ComboBox
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents TextBox29 As System.Windows.Forms.TextBox
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents txt_dep As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView5 As System.Windows.Forms.DataGridView
    Friend WithEvents TabControl5 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage13 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage14 As System.Windows.Forms.TabPage
    Friend WithEvents TabControl6 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage15 As System.Windows.Forms.TabPage
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents txt_U As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView8 As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage16 As System.Windows.Forms.TabPage
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents TextBox34 As System.Windows.Forms.TextBox
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker14 As System.Windows.Forms.DateTimePicker
    Friend WithEvents TextBox33 As System.Windows.Forms.TextBox
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker13 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents TextBox32 As System.Windows.Forms.TextBox
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents txt_C As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView6 As System.Windows.Forms.DataGridView
    Friend WithEvents Button28 As System.Windows.Forms.Button
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents TextBox37 As System.Windows.Forms.TextBox
    Friend WithEvents Label101 As System.Windows.Forms.Label
    Friend WithEvents Label99 As System.Windows.Forms.Label
    Friend WithEvents ComboBox24 As System.Windows.Forms.ComboBox
    Friend WithEvents Button29 As System.Windows.Forms.Button
    Friend WithEvents Button30 As System.Windows.Forms.Button
    Friend WithEvents TextBox36 As System.Windows.Forms.TextBox
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents Button31 As System.Windows.Forms.Button
    Friend WithEvents Button32 As System.Windows.Forms.Button
    Friend WithEvents Label97 As System.Windows.Forms.Label
    Friend WithEvents txt_T As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView7 As System.Windows.Forms.DataGridView
    Friend WithEvents Button38 As System.Windows.Forms.Button
    Friend WithEvents Button33 As System.Windows.Forms.Button
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents ComboBox25 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox39 As System.Windows.Forms.TextBox
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents TextBox40 As System.Windows.Forms.TextBox
    Friend WithEvents Label104 As System.Windows.Forms.Label
    Friend WithEvents Button34 As System.Windows.Forms.Button
    Friend WithEvents Button35 As System.Windows.Forms.Button
    Friend WithEvents TextBox41 As System.Windows.Forms.TextBox
    Friend WithEvents Label106 As System.Windows.Forms.Label
    Friend WithEvents Button36 As System.Windows.Forms.Button
    Friend WithEvents Button37 As System.Windows.Forms.Button
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Button41 As System.Windows.Forms.Button
    Friend WithEvents Button42 As System.Windows.Forms.Button
    Friend WithEvents Button39 As System.Windows.Forms.Button
    Friend WithEvents Button40 As System.Windows.Forms.Button
    Friend WithEvents dgvPl As System.Windows.Forms.DataGridView
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents Button43 As System.Windows.Forms.Button
    Friend WithEvents Button44 As System.Windows.Forms.Button
    Friend WithEvents dgvQl As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridView9 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents DataGridView12 As System.Windows.Forms.DataGridView
    Friend WithEvents Button49 As System.Windows.Forms.Button
    Friend WithEvents Button50 As System.Windows.Forms.Button
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents DataGridView11 As System.Windows.Forms.DataGridView
    Friend WithEvents Button47 As System.Windows.Forms.Button
    Friend WithEvents Button48 As System.Windows.Forms.Button
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents DataGridView10 As System.Windows.Forms.DataGridView
    Friend WithEvents Button45 As System.Windows.Forms.Button
    Friend WithEvents Button46 As System.Windows.Forms.Button
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents DataGridView13 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Button51 As System.Windows.Forms.Button
    Friend WithEvents Button52 As System.Windows.Forms.Button
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TabPage17 As System.Windows.Forms.TabPage
    Friend WithEvents Button53 As System.Windows.Forms.Button
End Class
