﻿Imports System.Data.SqlClient




Public Class Backup_Database
    Public SqlConnection As New SqlConnection("Data Source=DESKTOP-65D1KO0\SQLSERVE2012;Initial Catalog=emp;Integrated Security=True")



    Sub Backup()
        Dim cmd As New SqlCommand("backup database emp to disk = 'D:\Emp1.back' with init, format", SqlConnection)
        SqlConnection.Open()

        cmd.ExecuteNonQuery()
        SqlConnection.Close()



    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Backup()
            MsgBox("ok")
        Catch

        End Try
    End Sub

    Private Sub Backup_Database_Load(sender As Object, e As EventArgs) Handles MyBase.Load



    End Sub
End Class