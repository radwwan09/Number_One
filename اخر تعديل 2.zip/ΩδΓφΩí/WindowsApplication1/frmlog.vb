﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmlog
    Dim con As SqlConnection = New SqlConnection("Data Source=DESKTOP-3A2EOS3\SQLEXPRESS;Initial Catalog=Emp;Integrated Security=True")



    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtUser.Focus()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()

    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        Try
            Dim cmd As SqlCommand = New SqlCommand("select * from Users where User_Name ='" + txtUser.Text + "' and User_pass ='" + txtPass.Text + "'", con)
            Dim sda As SqlDataAdapter = New SqlDataAdapter(cmd)
            Dim dt As DataTable = New DataTable()
            sda.Fill(dt)
            If (dt.Rows.Count > 0) Then


                Home.Show()
                Me.Hide()

            Else
                MessageBox.Show("هناك خطأ ")
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Dim sc As SendCode = New SendCode()
        sc.Show()
    End Sub

    Private Sub txtUser_KeyDown(sender As Object, e As KeyEventArgs) Handles txtUser.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then
                txtPass.Focus()
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub txtPass_KeyDown(sender As Object, e As KeyEventArgs) Handles txtPass.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then
                Dim cmd As SqlCommand = New SqlCommand("select * from Users where User_Name ='" + txtUser.Text + "' and User_pass ='" + txtPass.Text + "'", con)
                Dim sda As SqlDataAdapter = New SqlDataAdapter(cmd)
                Dim dt As DataTable = New DataTable()
                sda.Fill(dt)
                If (dt.Rows.Count > 0) Then


                    Home.Show()
                    Me.Hide()
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub
End Class
