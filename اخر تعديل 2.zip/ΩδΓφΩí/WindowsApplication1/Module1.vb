﻿Imports System.Data
Imports System.Data.SqlClient
Module Module1
    Dim con As SqlConnection = New SqlConnection("Data Source=DESKTOP-3A2EOS3\SQLEXPRESS;Initial Catalog=Emp;Integrated Security=True")

    Public Sub fill_dgv(dgv As DataGridView, sql As String)
        dgv.DataSource = ""
        Dim dt As New DataTable
        Dim da As New SqlDataAdapter(sql, con)
        da.Fill(dt)
        dgv.AutoGenerateColumns = False
        dgv.DataSource = dt.DefaultView
    End Sub
    Public Sub fill_Family(dgv As DataGridView, id_ As Integer)
        dgv.DataSource = ""
        Dim dt As New DataTable
        Dim da As New SqlDataAdapter("select * from Family where Emp_Id=" & id_, con)
        da.Fill(dt)
        dgv.AutoGenerateColumns = False
        dgv.DataSource = dt.DefaultView
    End Sub
    Public Sub fill_Combo(Combo As ComboBox, sql As String, x As Integer)
        Combo.Items.Clear()
        Dim dtC As New DataTable
        Dim daC As New SqlDataAdapter(sql, con)
        daC.Fill(dtC)
        For i = 0 To dtC.Rows.Count - 1
            Combo.Items.Add(dtC(i)(x).ToString)
        Next
    End Sub
    Public Function count_R(tbl_name, id_) As Integer

        count_R = 0

        Dim dt As New DataTable
        Dim da As New SqlDataAdapter("select * from " & tbl_name & " order by " & id_ & " ", con)
        da.Fill(dt)
        If dt.Rows.Count <> 0 Then
            Dim i = dt.Rows.Count - 1
            count_R = Val(dt.Rows(i).Item(id_))
        End If
    End Function
    
End Module
