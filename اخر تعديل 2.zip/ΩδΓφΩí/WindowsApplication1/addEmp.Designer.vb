﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class addEmp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Emp_Id = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Emp_Name = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Emp_M = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Conf_Id = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Emp_NW = New System.Windows.Forms.TextBox()
        Me.Conf_Type = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Birth_Data = New System.Windows.Forms.DateTimePicker()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Social_Case = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Gender = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Nationa = New System.Windows.Forms.TextBox()
        Me.Address = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Phone = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Email = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Birth_Place = New System.Windows.Forms.ComboBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Dep_id_A = New System.Windows.Forms.ComboBox()
        Me.Country_A = New System.Windows.Forms.ComboBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Getting_Date_A = New System.Windows.Forms.DateTimePicker()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Costing_A = New System.Windows.Forms.ComboBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Qual_A = New System.Windows.Forms.ComboBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Spec_A = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Cer_id_A = New System.Windows.Forms.TextBox()
        Me.Fun_level_A = New System.Windows.Forms.ComboBox()
        Me.job_N_A = New System.Windows.Forms.ComboBox()
        Me.Alb_A = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.DateTimePicker3 = New System.Windows.Forms.DateTimePicker()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Fun_Deg_A = New System.Windows.Forms.ComboBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Elb_A = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Emp_Id
        '
        Me.Emp_Id.Location = New System.Drawing.Point(350, 23)
        Me.Emp_Id.Margin = New System.Windows.Forms.Padding(4)
        Me.Emp_Id.Name = "Emp_Id"
        Me.Emp_Id.Size = New System.Drawing.Size(150, 23)
        Me.Emp_Id.TabIndex = 0
        Me.Emp_Id.UseWaitCursor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(520, 26)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "رقم الموظف"
        Me.Label1.UseWaitCursor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(240, 26)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 16)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "اسم الموظف"
        Me.Label2.UseWaitCursor = True
        '
        'Emp_Name
        '
        Me.Emp_Name.Location = New System.Drawing.Point(17, 20)
        Me.Emp_Name.Margin = New System.Windows.Forms.Padding(4)
        Me.Emp_Name.Name = "Emp_Name"
        Me.Emp_Name.Size = New System.Drawing.Size(203, 23)
        Me.Emp_Name.TabIndex = 2
        Me.Emp_Name.UseWaitCursor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(240, 61)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 16)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "اسم الام"
        Me.Label3.UseWaitCursor = True
        '
        'Emp_M
        '
        Me.Emp_M.Location = New System.Drawing.Point(17, 55)
        Me.Emp_M.Margin = New System.Windows.Forms.Padding(4)
        Me.Emp_M.Name = "Emp_M"
        Me.Emp_M.Size = New System.Drawing.Size(203, 23)
        Me.Emp_M.TabIndex = 4
        Me.Emp_M.UseWaitCursor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(519, 61)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 16)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "نوع وثيقة الاثبات"
        Me.Label4.UseWaitCursor = True
        '
        'Conf_Id
        '
        Me.Conf_Id.Location = New System.Drawing.Point(350, 99)
        Me.Conf_Id.Margin = New System.Windows.Forms.Padding(4)
        Me.Conf_Id.Name = "Conf_Id"
        Me.Conf_Id.Size = New System.Drawing.Size(153, 23)
        Me.Conf_Id.TabIndex = 6
        Me.Conf_Id.UseWaitCursor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(520, 102)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(55, 16)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "رقم الوثيقة"
        Me.Label5.UseWaitCursor = True
        '
        'Emp_NW
        '
        Me.Emp_NW.Location = New System.Drawing.Point(350, 136)
        Me.Emp_NW.Margin = New System.Windows.Forms.Padding(4)
        Me.Emp_NW.Name = "Emp_NW"
        Me.Emp_NW.Size = New System.Drawing.Size(153, 23)
        Me.Emp_NW.TabIndex = 8
        Me.Emp_NW.UseWaitCursor = True
        '
        'Conf_Type
        '
        Me.Conf_Type.FormattingEnabled = True
        Me.Conf_Type.Items.AddRange(New Object() {"جواز سفر", "بطاقة شخصية"})
        Me.Conf_Type.Location = New System.Drawing.Point(350, 58)
        Me.Conf_Type.Name = "Conf_Type"
        Me.Conf_Type.Size = New System.Drawing.Size(153, 24)
        Me.Conf_Type.TabIndex = 10
        Me.Conf_Type.UseWaitCursor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(519, 139)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(65, 16)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "الرقم الوطني"
        Me.Label6.UseWaitCursor = True
        '
        'Birth_Data
        '
        Me.Birth_Data.Location = New System.Drawing.Point(350, 170)
        Me.Birth_Data.Name = "Birth_Data"
        Me.Birth_Data.Size = New System.Drawing.Size(153, 23)
        Me.Birth_Data.TabIndex = 12
        Me.Birth_Data.UseWaitCursor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(520, 176)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(63, 16)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "تاريخ الميلاد"
        Me.Label7.UseWaitCursor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(519, 210)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(62, 16)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "مكان الميلاد"
        Me.Label8.UseWaitCursor = True
        '
        'Social_Case
        '
        Me.Social_Case.FormattingEnabled = True
        Me.Social_Case.Items.AddRange(New Object() {"أعزب", "متزوج"})
        Me.Social_Case.Location = New System.Drawing.Point(68, 95)
        Me.Social_Case.Name = "Social_Case"
        Me.Social_Case.Size = New System.Drawing.Size(152, 24)
        Me.Social_Case.TabIndex = 17
        Me.Social_Case.UseWaitCursor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(240, 102)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(81, 16)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "الحالة الاجتماعية"
        Me.Label9.UseWaitCursor = True
        '
        'Gender
        '
        Me.Gender.FormattingEnabled = True
        Me.Gender.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Gender.Location = New System.Drawing.Point(68, 128)
        Me.Gender.Name = "Gender"
        Me.Gender.Size = New System.Drawing.Size(152, 24)
        Me.Gender.TabIndex = 19
        Me.Gender.UseWaitCursor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(240, 135)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(36, 16)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "الجنس"
        Me.Label10.UseWaitCursor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(240, 168)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(39, 16)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "الجنسية"
        Me.Label11.UseWaitCursor = True
        '
        'Nationa
        '
        Me.Nationa.Location = New System.Drawing.Point(17, 162)
        Me.Nationa.Margin = New System.Windows.Forms.Padding(4)
        Me.Nationa.Name = "Nationa"
        Me.Nationa.Size = New System.Drawing.Size(203, 23)
        Me.Nationa.TabIndex = 21
        Me.Nationa.UseWaitCursor = True
        '
        'Address
        '
        Me.Address.Location = New System.Drawing.Point(17, 197)
        Me.Address.Margin = New System.Windows.Forms.Padding(4)
        Me.Address.Name = "Address"
        Me.Address.Size = New System.Drawing.Size(203, 23)
        Me.Address.TabIndex = 23
        Me.Address.UseWaitCursor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(242, 203)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(39, 16)
        Me.Label12.TabIndex = 22
        Me.Label12.Text = "العنوان"
        Me.Label12.UseWaitCursor = True
        '
        'Phone
        '
        Me.Phone.Location = New System.Drawing.Point(17, 232)
        Me.Phone.Margin = New System.Windows.Forms.Padding(4)
        Me.Phone.Name = "Phone"
        Me.Phone.Size = New System.Drawing.Size(203, 23)
        Me.Phone.TabIndex = 25
        Me.Phone.UseWaitCursor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(240, 238)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(37, 16)
        Me.Label13.TabIndex = 24
        Me.Label13.Text = "الهاتف"
        Me.Label13.UseWaitCursor = True
        '
        'Email
        '
        Me.Email.Location = New System.Drawing.Point(17, 271)
        Me.Email.Margin = New System.Windows.Forms.Padding(4)
        Me.Email.Name = "Email"
        Me.Email.Size = New System.Drawing.Size(203, 23)
        Me.Email.TabIndex = 27
        Me.Email.UseWaitCursor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(240, 274)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(38, 16)
        Me.Label14.TabIndex = 26
        Me.Label14.Text = "الايميل"
        Me.Label14.UseWaitCursor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1177, 355)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(81, 29)
        Me.Button1.TabIndex = 28
        Me.Button1.Text = "اضافة"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(1074, 355)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(86, 29)
        Me.Button2.TabIndex = 29
        Me.Button2.Text = "الغاء"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Birth_Place)
        Me.Panel1.Controls.Add(Me.Conf_Id)
        Me.Panel1.Controls.Add(Me.Emp_Id)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Email)
        Me.Panel1.Controls.Add(Me.Emp_Name)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Phone)
        Me.Panel1.Controls.Add(Me.Emp_M)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Address)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.Emp_NW)
        Me.Panel1.Controls.Add(Me.Nationa)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Conf_Type)
        Me.Panel1.Controls.Add(Me.Gender)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Birth_Data)
        Me.Panel1.Controls.Add(Me.Social_Case)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Location = New System.Drawing.Point(12, 26)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(628, 323)
        Me.Panel1.TabIndex = 30
        Me.Panel1.UseWaitCursor = True
        '
        'Birth_Place
        '
        Me.Birth_Place.FormattingEnabled = True
        Me.Birth_Place.Items.AddRange(New Object() {"جواز سفر", "بطاقة شخصية"})
        Me.Birth_Place.Location = New System.Drawing.Point(350, 207)
        Me.Birth_Place.Name = "Birth_Place"
        Me.Birth_Place.Size = New System.Drawing.Size(153, 24)
        Me.Birth_Place.TabIndex = 28
        Me.Birth_Place.UseWaitCursor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(64, 15)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(83, 16)
        Me.Label15.TabIndex = 31
        Me.Label15.Text = "البيانات الشخصية"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Dep_id_A)
        Me.Panel2.Controls.Add(Me.Country_A)
        Me.Panel2.Controls.Add(Me.Label30)
        Me.Panel2.Controls.Add(Me.Getting_Date_A)
        Me.Panel2.Controls.Add(Me.Label29)
        Me.Panel2.Controls.Add(Me.Costing_A)
        Me.Panel2.Controls.Add(Me.Label28)
        Me.Panel2.Controls.Add(Me.Qual_A)
        Me.Panel2.Controls.Add(Me.Label27)
        Me.Panel2.Controls.Add(Me.Spec_A)
        Me.Panel2.Controls.Add(Me.Label26)
        Me.Panel2.Controls.Add(Me.Label25)
        Me.Panel2.Controls.Add(Me.Cer_id_A)
        Me.Panel2.Controls.Add(Me.Fun_level_A)
        Me.Panel2.Controls.Add(Me.job_N_A)
        Me.Panel2.Controls.Add(Me.Alb_A)
        Me.Panel2.Controls.Add(Me.Label18)
        Me.Panel2.Controls.Add(Me.DateTimePicker3)
        Me.Panel2.Controls.Add(Me.Label16)
        Me.Panel2.Controls.Add(Me.Label23)
        Me.Panel2.Controls.Add(Me.Fun_Deg_A)
        Me.Panel2.Controls.Add(Me.Label22)
        Me.Panel2.Controls.Add(Me.Label21)
        Me.Panel2.Controls.Add(Me.Label20)
        Me.Panel2.Controls.Add(Me.Elb_A)
        Me.Panel2.Controls.Add(Me.Label19)
        Me.Panel2.Controls.Add(Me.DateTimePicker2)
        Me.Panel2.Controls.Add(Me.Label17)
        Me.Panel2.Location = New System.Drawing.Point(655, 26)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(656, 323)
        Me.Panel2.TabIndex = 32
        '
        'Dep_id_A
        '
        Me.Dep_id_A.FormattingEnabled = True
        Me.Dep_id_A.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Dep_id_A.Location = New System.Drawing.Point(29, 197)
        Me.Dep_id_A.Name = "Dep_id_A"
        Me.Dep_id_A.Size = New System.Drawing.Size(152, 24)
        Me.Dep_id_A.TabIndex = 57
        Me.Dep_id_A.UseWaitCursor = True
        '
        'Country_A
        '
        Me.Country_A.FormattingEnabled = True
        Me.Country_A.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Country_A.Location = New System.Drawing.Point(29, 165)
        Me.Country_A.Name = "Country_A"
        Me.Country_A.Size = New System.Drawing.Size(152, 24)
        Me.Country_A.TabIndex = 56
        Me.Country_A.UseWaitCursor = True
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(217, 168)
        Me.Label30.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(72, 16)
        Me.Label30.TabIndex = 55
        Me.Label30.Text = "مكان الاصدار"
        Me.Label30.UseWaitCursor = True
        '
        'Getting_Date_A
        '
        Me.Getting_Date_A.Location = New System.Drawing.Point(29, 129)
        Me.Getting_Date_A.Name = "Getting_Date_A"
        Me.Getting_Date_A.Size = New System.Drawing.Size(150, 23)
        Me.Getting_Date_A.TabIndex = 53
        Me.Getting_Date_A.UseWaitCursor = True
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(217, 135)
        Me.Label29.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(73, 16)
        Me.Label29.TabIndex = 54
        Me.Label29.Text = "تاريخ الاصدار"
        Me.Label29.UseWaitCursor = True
        '
        'Costing_A
        '
        Me.Costing_A.FormattingEnabled = True
        Me.Costing_A.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Costing_A.Location = New System.Drawing.Point(27, 93)
        Me.Costing_A.Name = "Costing_A"
        Me.Costing_A.Size = New System.Drawing.Size(152, 24)
        Me.Costing_A.TabIndex = 52
        Me.Costing_A.UseWaitCursor = True
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(245, 101)
        Me.Label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(36, 16)
        Me.Label28.TabIndex = 51
        Me.Label28.Text = "التقدير"
        Me.Label28.UseWaitCursor = True
        '
        'Qual_A
        '
        Me.Qual_A.FormattingEnabled = True
        Me.Qual_A.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Qual_A.Location = New System.Drawing.Point(27, 59)
        Me.Qual_A.Name = "Qual_A"
        Me.Qual_A.Size = New System.Drawing.Size(152, 24)
        Me.Qual_A.TabIndex = 50
        Me.Qual_A.UseWaitCursor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(246, 64)
        Me.Label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(39, 16)
        Me.Label27.TabIndex = 49
        Me.Label27.Text = "المؤهل"
        Me.Label27.UseWaitCursor = True
        '
        'Spec_A
        '
        Me.Spec_A.FormattingEnabled = True
        Me.Spec_A.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Spec_A.Location = New System.Drawing.Point(27, 21)
        Me.Spec_A.Name = "Spec_A"
        Me.Spec_A.Size = New System.Drawing.Size(152, 24)
        Me.Spec_A.TabIndex = 48
        Me.Spec_A.UseWaitCursor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(229, 26)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(51, 16)
        Me.Label26.TabIndex = 47
        Me.Label26.Text = "التخصص"
        Me.Label26.UseWaitCursor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(545, 274)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(84, 16)
        Me.Label25.TabIndex = 46
        Me.Label25.Text = "رقم وثيقة التخرج"
        Me.Label25.UseWaitCursor = True
        '
        'Cer_id_A
        '
        Me.Cer_id_A.Location = New System.Drawing.Point(327, 271)
        Me.Cer_id_A.Margin = New System.Windows.Forms.Padding(4)
        Me.Cer_id_A.Name = "Cer_id_A"
        Me.Cer_id_A.Size = New System.Drawing.Size(150, 23)
        Me.Cer_id_A.TabIndex = 45
        Me.Cer_id_A.UseWaitCursor = True
        '
        'Fun_level_A
        '
        Me.Fun_level_A.FormattingEnabled = True
        Me.Fun_level_A.Items.AddRange(New Object() {"أعزب", "متزوج"})
        Me.Fun_level_A.Location = New System.Drawing.Point(325, 200)
        Me.Fun_level_A.Name = "Fun_level_A"
        Me.Fun_level_A.Size = New System.Drawing.Size(152, 24)
        Me.Fun_level_A.TabIndex = 44
        Me.Fun_level_A.UseWaitCursor = True
        '
        'job_N_A
        '
        Me.job_N_A.FormattingEnabled = True
        Me.job_N_A.Items.AddRange(New Object() {"أعزب", "متزوج"})
        Me.job_N_A.Location = New System.Drawing.Point(325, 163)
        Me.job_N_A.Name = "job_N_A"
        Me.job_N_A.Size = New System.Drawing.Size(150, 24)
        Me.job_N_A.TabIndex = 29
        Me.job_N_A.UseWaitCursor = True
        '
        'Alb_A
        '
        Me.Alb_A.Location = New System.Drawing.Point(325, 93)
        Me.Alb_A.Margin = New System.Windows.Forms.Padding(4)
        Me.Alb_A.Name = "Alb_A"
        Me.Alb_A.Size = New System.Drawing.Size(150, 23)
        Me.Alb_A.TabIndex = 42
        Me.Alb_A.UseWaitCursor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(504, 96)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(114, 16)
        Me.Label18.TabIndex = 43
        Me.Label18.Text = "رصيد الاجازات السنوية"
        Me.Label18.UseWaitCursor = True
        '
        'DateTimePicker3
        '
        Me.DateTimePicker3.Location = New System.Drawing.Point(325, 20)
        Me.DateTimePicker3.Name = "DateTimePicker3"
        Me.DateTimePicker3.Size = New System.Drawing.Size(150, 23)
        Me.DateTimePicker3.TabIndex = 40
        Me.DateTimePicker3.UseWaitCursor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(526, 26)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(94, 16)
        Me.Label16.TabIndex = 41
        Me.Label16.Text = "تاريخ مباشرة العمل"
        Me.Label16.UseWaitCursor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(246, 203)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(50, 16)
        Me.Label23.TabIndex = 39
        Me.Label23.Text = "رقم القسم"
        Me.Label23.UseWaitCursor = True
        '
        'Fun_Deg_A
        '
        Me.Fun_Deg_A.FormattingEnabled = True
        Me.Fun_Deg_A.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.Fun_Deg_A.Location = New System.Drawing.Point(325, 233)
        Me.Fun_Deg_A.Name = "Fun_Deg_A"
        Me.Fun_Deg_A.Size = New System.Drawing.Size(152, 24)
        Me.Fun_Deg_A.TabIndex = 38
        Me.Fun_Deg_A.UseWaitCursor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(576, 241)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(38, 16)
        Me.Label22.TabIndex = 37
        Me.Label22.Text = "الدرجة"
        Me.Label22.UseWaitCursor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(539, 203)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(84, 16)
        Me.Label21.TabIndex = 35
        Me.Label21.Text = "المستوي الوظيفي"
        Me.Label21.UseWaitCursor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(569, 166)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(59, 16)
        Me.Label20.TabIndex = 33
        Me.Label20.Text = "اسم الوظيفة"
        Me.Label20.UseWaitCursor = True
        '
        'Elb_A
        '
        Me.Elb_A.Location = New System.Drawing.Point(325, 128)
        Me.Elb_A.Margin = New System.Windows.Forms.Padding(4)
        Me.Elb_A.Name = "Elb_A"
        Me.Elb_A.Size = New System.Drawing.Size(150, 23)
        Me.Elb_A.TabIndex = 30
        Me.Elb_A.UseWaitCursor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(501, 135)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(116, 16)
        Me.Label19.TabIndex = 31
        Me.Label19.Text = "رصيد الاجازات الطارئة"
        Me.Label19.UseWaitCursor = True
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Location = New System.Drawing.Point(325, 58)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(150, 23)
        Me.DateTimePicker2.TabIndex = 28
        Me.DateTimePicker2.UseWaitCursor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(482, 64)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(132, 16)
        Me.Label17.TabIndex = 29
        Me.Label17.Text = "تاريخ مباشرة العمل الاصلي"
        Me.Label17.UseWaitCursor = True
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(678, 15)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(78, 16)
        Me.Label24.TabIndex = 33
        Me.Label24.Text = "البيانات الوظيفية"
        '
        'addEmp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1321, 397)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "addEmp"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.RightToLeftLayout = True
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "اضافة موظف"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Emp_Id As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Emp_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Emp_M As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Conf_Id As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Emp_NW As System.Windows.Forms.TextBox
    Friend WithEvents Conf_Type As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Birth_Data As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Social_Case As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Gender As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Nationa As System.Windows.Forms.TextBox
    Friend WithEvents Address As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Phone As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Email As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Fun_Deg_A As System.Windows.Forms.ComboBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Elb_A As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Birth_Place As System.Windows.Forms.ComboBox
    Friend WithEvents Getting_Date_A As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Costing_A As System.Windows.Forms.ComboBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Qual_A As System.Windows.Forms.ComboBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Spec_A As System.Windows.Forms.ComboBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Cer_id_A As System.Windows.Forms.TextBox
    Friend WithEvents Fun_level_A As System.Windows.Forms.ComboBox
    Friend WithEvents job_N_A As System.Windows.Forms.ComboBox
    Friend WithEvents Alb_A As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker3 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Dep_id_A As System.Windows.Forms.ComboBox
    Friend WithEvents Country_A As System.Windows.Forms.ComboBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
End Class
