﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class addFamily_Emp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtEmp_Id = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtNationa = New System.Windows.Forms.TextBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.CM_Birth_Place_F = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtNW = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Birth_Date = New System.Windows.Forms.DateTimePicker()
        Me.CM_Gender = New System.Windows.Forms.ComboBox()
        Me.CM_Adjective = New System.Windows.Forms.ComboBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtEmp_Id
        '
        Me.txtEmp_Id.BackColor = System.Drawing.Color.White
        Me.txtEmp_Id.Location = New System.Drawing.Point(394, 38)
        Me.txtEmp_Id.Name = "txtEmp_Id"
        Me.txtEmp_Id.ReadOnly = True
        Me.txtEmp_Id.Size = New System.Drawing.Size(145, 28)
        Me.txtEmp_Id.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(542, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 21)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "رقم الموظف :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(312, 41)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 21)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "الاسم :"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(29, 38)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(277, 28)
        Me.txtName.TabIndex = 2
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtNationa)
        Me.GroupBox1.Controls.Add(Me.btnExit)
        Me.GroupBox1.Controls.Add(Me.btnEnter)
        Me.GroupBox1.Controls.Add(Me.CM_Birth_Place_F)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtNW)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Birth_Date)
        Me.GroupBox1.Controls.Add(Me.CM_Gender)
        Me.GroupBox1.Controls.Add(Me.CM_Adjective)
        Me.GroupBox1.Controls.Add(Me.txtName)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtEmp_Id)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(639, 264)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "معلومات الفرد"
        '
        'txtNationa
        '
        Me.txtNationa.Location = New System.Drawing.Point(106, 126)
        Me.txtNationa.Name = "txtNationa"
        Me.txtNationa.Size = New System.Drawing.Size(200, 28)
        Me.txtNationa.TabIndex = 19
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(351, 223)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(9, 6, 9, 6)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(88, 32)
        Me.btnExit.TabIndex = 18
        Me.btnExit.Text = "الغاء"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnEnter
        '
        Me.btnEnter.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEnter.Location = New System.Drawing.Point(218, 223)
        Me.btnEnter.Margin = New System.Windows.Forms.Padding(9, 6, 9, 6)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(88, 32)
        Me.btnEnter.TabIndex = 17
        Me.btnEnter.Text = "اضافة"
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'CM_Birth_Place_F
        '
        Me.CM_Birth_Place_F.FormattingEnabled = True
        Me.CM_Birth_Place_F.Location = New System.Drawing.Point(394, 174)
        Me.CM_Birth_Place_F.Name = "CM_Birth_Place_F"
        Me.CM_Birth_Place_F.Size = New System.Drawing.Size(145, 28)
        Me.CM_Birth_Place_F.TabIndex = 15
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(546, 177)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(89, 21)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "مكان الميلاد :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(312, 177)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(75, 21)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "ت/الميلاد :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(312, 129)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 21)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "الجنسية :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(542, 129)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 21)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "الجنس :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(312, 86)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 21)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "الصفة :"
        '
        'txtNW
        '
        Me.txtNW.Location = New System.Drawing.Point(394, 83)
        Me.txtNW.Name = "txtNW"
        Me.txtNW.Size = New System.Drawing.Size(145, 28)
        Me.txtNW.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(542, 86)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(95, 21)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "الرقم الوطني :"
        '
        'Birth_Date
        '
        Me.Birth_Date.Location = New System.Drawing.Point(106, 171)
        Me.Birth_Date.Name = "Birth_Date"
        Me.Birth_Date.Size = New System.Drawing.Size(200, 28)
        Me.Birth_Date.TabIndex = 7
        '
        'CM_Gender
        '
        Me.CM_Gender.FormattingEnabled = True
        Me.CM_Gender.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.CM_Gender.Location = New System.Drawing.Point(394, 126)
        Me.CM_Gender.Name = "CM_Gender"
        Me.CM_Gender.Size = New System.Drawing.Size(145, 28)
        Me.CM_Gender.TabIndex = 5
        '
        'CM_Adjective
        '
        Me.CM_Adjective.FormattingEnabled = True
        Me.CM_Adjective.Items.AddRange(New Object() {"زوج", "زوجة", "ابن ", "ابنه"})
        Me.CM_Adjective.Location = New System.Drawing.Point(106, 83)
        Me.CM_Adjective.Name = "CM_Adjective"
        Me.CM_Adjective.Size = New System.Drawing.Size(200, 28)
        Me.CM_Adjective.TabIndex = 4
        '
        'addFamily_Emp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(658, 288)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "addFamily_Emp"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents txtEmp_Id As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents CM_Birth_Place_F As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtNW As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Birth_Date As System.Windows.Forms.DateTimePicker
    Friend WithEvents CM_Gender As System.Windows.Forms.ComboBox
    Friend WithEvents CM_Adjective As System.Windows.Forms.ComboBox
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnEnter As System.Windows.Forms.Button
    Friend WithEvents txtNationa As System.Windows.Forms.TextBox
End Class
