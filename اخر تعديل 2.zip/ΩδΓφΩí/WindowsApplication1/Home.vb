﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Home
    Dim stat_Mang As String
    Dim stat_User As String
    Dim con As SqlConnection = New SqlConnection("Data Source=DESKTOP-3A2EOS3\SQLEXPRESS;Initial Catalog=Emp;Integrated Security=True")
    Dim cmd As New SqlCommand
    Public number_Row_Hol As Integer
    Sub Backup()
        Dim cmd As New SqlCommand("backup database emp to disk = 'G:\Emp1.back' with init, format", con)
        con.Open()

        cmd.ExecuteNonQuery()
        con.Close()
    End Sub
    Sub fillDGV()
        ''**********************ملء الداتا قرد***************************
        fill_dgv(dgv_Mang, "select * from Managments")
        dgv_Mang.Columns(0).Width = 200
        dgv_Mang.Columns(1).Width = 220
        fill_dgv(dgvEmp, "select * from Employees")
        fill_dgv(dgvPl, "select * from Places")
        fill_dgv(dgvQl, "select * from Qualifications")
        fill_dgv(dgvTH, "select * from Type_Holiday")
        fill_dgv(dgvJ, "select * from Job")
        fill_dgv(dgvLJ, "select * from Job_level")
        fill_dgv(dgvD, "select * from Deg")
        fill_dgv(dgvS, "select * from Spec")
        fill_dgv(dgvDep, "select * from Sections")
        dgvDep.Columns(0).Width = 200
        dgvDep.Columns(1).Width = 200
        dgvDep.Columns(2).Width = 200
        dgvDep.Columns(3).Width = 200
        fill_dgv(dgvHoli_Emp, "select * from Holidays")
        dgvHoli_Emp.Columns(0).Width = 146
        dgvHoli_Emp.Columns(1).Width = 200
        dgvHoli_Emp.Columns(2).Width = 200
        dgvHoli_Emp.Columns(3).Width = 200
        dgvHoli_Emp.Columns(4).Width = 200
        dgvHoli_Emp.Columns(5).Width = 170
        dgvFamily_Emp.Columns(0).Width = 180
        dgvFamily_Emp.Columns(1).Width = 200
        dgvFamily_Emp.Columns(2).Width = 120
        dgvFamily_Emp.Columns(3).Width = 120
        dgvFamily_Emp.Columns(4).Width = 120
        dgvFamily_Emp.Columns(5).Width = 140
        dgvFamily_Emp.Columns(6).Width = 138
        dgvFamily_Emp.Columns(7).Width = 133

        fill_dgv(dgvCaseEmp, "select * from Case_Emp")
        dgvCaseEmp.Columns(0).Width = 200
        dgvCaseEmp.Columns(1).Width = 200
        dgvCaseEmp.Columns(2).Width = 200
        dgvCaseEmp.Columns(3).Width = 200
        fill_dgv(dgvCourses, "select * from Courses")
        dgvCourses.Columns(0).Width = 200
        dgvCourses.Columns(1).Width = 200
        dgvCourses.Columns(2).Width = 200
        dgvCourses.Columns(3).Width = 200
        dgvCourses.Columns(4).Width = 200
        dgvCourses.Columns(5).Width = 200
    End Sub
    Public Sub fill_dgvH()
        dgvHoli_Emp.DataSource = ""
        Dim dt As New DataTable
        Dim dth As New DataTable
        dt.Clear()
        Dim da As New SqlDataAdapter("select [Emp_Id] FROM [Emp].[dbo].[Employees]", con)
        da.Fill(dt)
        dth.Clear()
        For i = 0 To dt.Rows.Count - 1
            Dim dah As New SqlDataAdapter("select top 1* from Emp_in_Holid  where Emp_Id =" & dt(i)(0) & " ORDER BY ID DESC", con)
            dah.Fill(dth)
        Next

        dgvHoli_Emp.AutoGenerateColumns = False
        dgvHoli_Emp.DataSource = dth.DefaultView
    End Sub
    Sub cler_Holi()
        txtEmp_id_H.Clear()
        txtEmp_id_E.Clear()
        txtEmp_name_H.Clear()
        txtEmp_name_E.Clear()
        txtDay_Annual_E.Clear()
        txtDay_Annual_H.Clear()
        txtDay_Emergency_H.Clear()
        txtDay_Emergency_E.Clear()
        CM_H_type_A.ResetText()
        CM_H_type_E.ResetText()
        H_start_A.ResetText()
        H_start_E.ResetText()
        H_end_A.ResetText()
        H_end_E.ResetText()
        L_D_H_A.Text = ""
        L_D_H_E.Text = ""
    End Sub

    Sub cler_Emp()
        Emp_Id.Text = count_R("Employees", "Emp_Id") + 1
        Emp_Name.Clear()
        Emp_M.Clear()
        Conf_Type.ResetText()
        Conf_Id.Clear()
        Emp_NW.Clear()
        Birth_Data.Value = Now.Date
        CM_Birth_Place.ResetText()
        CM_Social_Case.ResetText()
        CM_Gender.ResetText()
        Nationa.Clear()
        Address.Clear()
        Phone.Clear()
        Email.Clear()
        D_O_D_A.Value = Now.Date
        D_O_O_W.Value = Now.Date
        Annual_L_Balance.Clear()
        E_L_Balance.Clear()
        CM_Job_Id.ResetText()
        CM_L_J_Id.ResetText()
        CM_F_Deg_Id.ResetText()
        Cer_Id.Clear()
        CM_Spec_Id.ResetText()
        CM_Qual_Id.ResetText()
        CM_Costing.ResetText()
        Getting_Date.Value = Now.Date
        CM_Country.ResetText()
        CM_Dep_Id.ResetText()
    End Sub

    Sub fillCombo()
        ''************************ملء الكومبو*************************
        fill_Combo(CM_Spec_Id, "select * from Spec", 1)
        fill_Combo(CM_Birth_Place, "select * from Places", 1)
        fill_Combo(CM_Job_Id, "select * from Job", 1)
        fill_Combo(CM_L_J_Id, "select * from Job_level", 1)
        fill_Combo(CM_F_Deg_Id, "select * from Deg", 1)
        fill_Combo(CM_Qual_Id, "select * from Qualifications", 1)
        fill_Combo(CM_Country, "select * from Places", 1)
        fill_Combo(CM_Dep_Id, "select * from Sections", 1)
        fill_Combo(CM_M_To_D, "select * from Managments", 1)
        fill_Combo(CM_H_type_A, "select * from Type_Holiday", 1)
        fill_Combo(CM_H_type_E, "select * from Type_Holiday", 1)

    End Sub
    Sub PVis()
        Panal_Mang.Visible = False
        panal_Dep.Visible = False
    End Sub
    Sub c_r()
        Emp_Id.Text = count_R("Employees", "Emp_Id") + 1
        txt_Dep_Id_A.Text = count_R("Sections", "Dep_id") + 1
        txt_Mane_Id_A.Text = count_R("Managments", "Mang_id") + 1

    End Sub

    Private Sub Home_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillDGV()
        fillCombo()
        btnedit_Emp.Enabled = False
        btnDelet_Emp.Enabled = False
        btnadd_Emp.Enabled = True
        c_r()
        PVis()
        fill_dgvH()
    End Sub

    Private Sub txtEmp_id_H_KeyDown(sender As Object, e As KeyEventArgs) Handles txtEmp_id_H.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then
                cmd = New SqlCommand("select Emp_Name , Annual_leave_balance, Emergency_leave_balance from Employees  where Emp_Id =" & txtEmp_id_H.Text, con)
                con.Open()
                Dim dr As SqlDataReader = cmd.ExecuteReader
                dr.Read()
                If dr.HasRows Then
                    txtEmp_name_H.Text = dr(0)
                    txtDay_Annual_H.Text = dr(1)
                    txtDay_Emergency_H.Text = dr(2)


                Else
                    MsgBox("لا يوجد موظف بالرقم الذي ادخلته", MsgBoxStyle.Exclamation, "تنبيه")


                End If
                dr.Close()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            con.Close()
        End Try
    End Sub



    Private Sub Button40_Click(sender As Object, e As EventArgs) Handles Button40.Click
        Dim frmp As New addPlace
        frmp.state = "add"
        frmp.btnEnter.Text = "اضافة"
        frmp.ShowDialog()
        fillDGV()
    End Sub

    Private Sub Button39_Click(sender As Object, e As EventArgs) Handles Button39.Click
        Dim frmp As New addPlace
        frmp.state = "edit"
        frmp.id = dgvPl.CurrentRow.Cells(0).Value
        frmp.txtN.Text = dgvPl.CurrentRow.Cells(1).Value
        frmp.btnEnter.Text = "تعديل"
        frmp.ShowDialog()
        fillDGV()
    End Sub


    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Panal_Mang.Visible = True
        txt_Name_Mang.Clear()
        txt_Name_Mang.Focus()
        stat_Mang = "add"
        c_r()
    End Sub

    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        Try
            Dim strQury As String = ""


            If stat_Mang = "add" Then
                strQury = "INSERT INTO [dbo].[Managments] ([Mang_id],[Mang_Name]) VALUES (" & txt_Mane_Id_A.Text & ",'" & txt_Name_Mang.Text & "')"

            Else

                strQury = " UPDATE [dbo].[Managments] SET [Mang_Name] = '" & txt_Name_Mang.Text & "' WHERE Mang_id= " & dgv_Mang.CurrentRow.Cells(0).Value

            End If
            Dim cmd As New SqlCommand(strQury, con)
            con.Open()
            cmd.ExecuteNonQuery()
            MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")
            txt_Name_Mang.Clear()
        Catch ex As Exception

            MsgBox(ex.Message)
        Finally
            con.Close()
            fillDGV()
            Panal_Mang.Visible = False
            c_r()
        End Try
    End Sub

    Private Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click
        c_r()
        Panal_Mang.Visible = False
        txt_Mane_Id_A.Clear()
        txt_Name_Mang.Clear()
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        Panal_Mang.Visible = True
        txt_Name_Mang.Focus()
        txt_Mane_Id_A.Text = dgv_Mang.CurrentRow.Cells(0).Value.ToString
        txt_Name_Mang.Text = dgv_Mang.CurrentRow.Cells(1).Value.ToString
        stat_Mang = "edit"
    End Sub


    Private Sub Button22_Click(sender As Object, e As EventArgs) Handles Button22.Click
        panal_Dep.Visible = True
        txt_Name_Dep.Focus()
        txt_Name_Dep.Clear()
        CM_M_To_D.ResetText()
        stat_Mang = "add"
        c_r()
    End Sub

    Private Sub Button20_Click(sender As Object, e As EventArgs) Handles Button20.Click
        Try
            Dim strQury As String = ""


            If stat_Mang = "add" Then
                strQury = "INSERT INTO [dbo].[Sections] ([Dep_id],[Dep_Name],[Dep_opening_date],[Mang_id]) VALUES (" & txt_Dep_Id_A.Text & ",'" & txt_Name_Dep.Text & "','" & D_O_D.Value.Date & "'," & CM_M_To_D.SelectedIndex + 1 & ")"

            Else

                strQury = " UPDATE [dbo].[Sections] SET [Dep_Name] = '" & txt_Name_Dep.Text & "',[Dep_opening_date]='" & D_O_D.Value.Date & "',[Mang_id]=" & CM_M_To_D.SelectedIndex + 1 & " WHERE [Dep_id]= " & dgvDep.CurrentRow.Cells(0).Value

            End If
            Dim cmd As New SqlCommand(strQury, con)
            con.Open()
            cmd.ExecuteNonQuery()
            MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")
            txt_Name_Mang.Clear()
        Catch ex As Exception

            MsgBox(ex.Message)
        Finally
            con.Close()
            fillDGV()
            Panal_Mang.Visible = False
            c_r()
        End Try
    End Sub

    Private Sub Button21_Click(sender As Object, e As EventArgs) Handles Button21.Click
        panal_Dep.Visible = True
        txt_Name_Dep.Focus()
        txt_Dep_Id_A.Text = dgvDep.CurrentRow.Cells(1).Value.ToString
        txt_Name_Dep.Text = dgvDep.CurrentRow.Cells(1).Value.ToString
        D_O_D.Value = dgvDep.CurrentRow.Cells(2).Value
        CM_M_To_D.SelectedIndex = dgvDep.CurrentRow.Cells(3).Value - 1
        stat_Mang = "edit"
    End Sub

    Private Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        panal_Dep.Visible = False
        txt_Dep_Id_A.Clear()
        txt_Name_Dep.Clear()
        CM_M_To_D.ResetText()
        D_O_D.Value = Now.Date
        c_r()
    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click

        Panal_Mang.Visible = False
        txt_Mane_Id_A.Clear()
        txt_Name_Mang.Clear()
    End Sub

    Private Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click
        panal_Dep.Visible = False
        txt_Dep_Id_A.Clear()
        txt_Name_Dep.Clear()
        CM_M_To_D.ResetText()
        D_O_D.Value = Now.Date

    End Sub





    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try

            Dim cmd As New SqlCommand("INSERT INTO [dbo].[Holidays]([H_id],[H_period],[H_start],[H_end],[Emp_Id]) VALUES (" & (CM_H_type_A.SelectedIndex + 1) & "," & L_D_H_A.Text & ",@date1,@date2," & CInt(txtEmp_id_H.Text) & ")", con)
            cmd.Parameters.AddWithValue("@date1", SqlDbType.Date).Value = H_start_A.Value.Date
            cmd.Parameters.AddWithValue("@date2", SqlDbType.Date).Value = H_end_A.Value.Date
            con.Open()
            cmd.ExecuteNonQuery()
            MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")


        Catch ex As Exception

            MsgBox(ex.Message)
        Finally
            con.Close()
            fillDGV()
            Panal_Mang.Visible = False
            cler_Holi()
        End Try
    End Sub





    Private Sub H_end_A_ValueChanged(sender As Object, e As EventArgs) Handles H_end_A.ValueChanged
        Dim From_D As Date = H_start_A.Value.Date
        Dim To_D As Date = H_end_A.Value.Date
        Dim resDate As TimeSpan = To_D - From_D
        L_D_H_A.Text = CInt(resDate.Days)
    End Sub

    Private Sub Emp_id_E_KeyDown(sender As Object, e As KeyEventArgs) Handles txtEmp_id_E.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then
                cmd = New SqlCommand("select top 1* from Emp_in_Holid  where Emp_Id =" & txtEmp_id_E.Text & " ORDER BY ID DESC", con)
                con.Open()
                Dim dr As SqlDataReader = cmd.ExecuteReader
                dr.Read()
                If dr.HasRows Then
                    txtEmp_name_E.Text = dr(1)
                    txtDay_Annual_E.Text = dr(2)
                    txtDay_Emergency_E.Text = dr(3)
                    CM_H_type_E.SelectedIndex = (dr(4) - 1)
                    L_D_H_E.Text = dr(5)
                    H_start_E.Value = dr(6)
                    H_end_E.Value = dr(7)
                    number_Row_Hol = dr(8)

                Else
                    MsgBox("لا يوجد موظف بالرقم الذي ادخلته", MsgBoxStyle.Exclamation, "تنبيه")


                End If
                dr.Close()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try

            Dim cmd As New SqlCommand("UPDATE [dbo].[Holidays] SET [H_id]=" & CM_H_type_E.SelectedIndex + 1 & ", [H_period] = " & L_D_H_E.Text & ",[H_start] =@date1 ,[H_end]= @date2 ,[Emp_Id] = " & txtEmp_id_E.Text & " where ID=" & number_Row_Hol, con)
            cmd.Parameters.AddWithValue("@date1", SqlDbType.Date).Value = H_start_E.Value.Date
            cmd.Parameters.AddWithValue("@date2", SqlDbType.Date).Value = H_end_E.Value.Date
            con.Open()
            cmd.ExecuteNonQuery()
            MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")

        Catch ex As Exception

            MsgBox(ex.Message)
        Finally
            con.Close()
            fillDGV()
            Panal_Mang.Visible = False
            fill_dgvH()
            cler_Holi()
        End Try
    End Sub

    Private Sub H_end_E_ValueChanged(sender As Object, e As EventArgs) Handles H_end_E.ValueChanged
        Dim From_D As Date = H_start_E.Value.Date
        Dim To_D As Date = H_end_E.Value.Date
        Dim resDate As TimeSpan = To_D - From_D
        L_D_H_E.Text = CInt(resDate.Days)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        cler_Holi()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        cler_Holi()
    End Sub

    Private Sub Button42_Click(sender As Object, e As EventArgs) Handles Button42.Click
        Dim frmp As New addQual
        frmp.state = "add"
        frmp.btnEnter.Text = "اضافة"
        frmp.ShowDialog()
        frmp.ShowDialog()
        fillDGV()
    End Sub

    Private Sub Button41_Click(sender As Object, e As EventArgs) Handles Button41.Click
        Dim frmp As New addQual
        frmp.state = "edit"
        frmp.id = dgvQl.CurrentRow.Cells(0).Value
        frmp.txtN.Text = dgvQl.CurrentRow.Cells(1).Value
        frmp.btnEnter.Text = "تعديل"
        frmp.ShowDialog()
        fillDGV()
    End Sub

    Private Sub Button44_Click(sender As Object, e As EventArgs) Handles Button44.Click
        Dim frmp As New add_T_Holiday
        frmp.state = "add"
        frmp.btnEnter.Text = "اضافة"
        frmp.ShowDialog()
        fillDGV()
    End Sub

    Private Sub Button43_Click(sender As Object, e As EventArgs) Handles Button43.Click
        Dim frmp As New add_T_Holiday
        frmp.state = "edit"
        frmp.id = dgvTH.CurrentRow.Cells(0).Value
        frmp.txtN.Text = dgvTH.CurrentRow.Cells(1).Value
        frmp.btnEnter.Text = "تعديل"
        frmp.ShowDialog()
        fillDGV()
    End Sub

    Private Sub Button46_Click(sender As Object, e As EventArgs) Handles Button46.Click
        Dim frmp As New add_Job
        frmp.state = "add"
        frmp.btnEnter.Text = "اضافة"
        frmp.ShowDialog()
        fillDGV()
    End Sub

    Private Sub Button45_Click(sender As Object, e As EventArgs) Handles Button45.Click
        Dim frmp As New add_Job
        frmp.state = "edit"
        frmp.id = dgvJ.CurrentRow.Cells(0).Value
        frmp.txtN.Text = dgvJ.CurrentRow.Cells(1).Value
        frmp.btnEnter.Text = "تعديل"
        frmp.ShowDialog()
        fillDGV()
    End Sub

    Private Sub Button48_Click(sender As Object, e As EventArgs) Handles Button48.Click
        Dim frmp As New add_Job_L
        frmp.state = "add"
        frmp.btnEnter.Text = "اضافة"
        frmp.ShowDialog()
        fillDGV()
    End Sub

    Private Sub Button47_Click(sender As Object, e As EventArgs) Handles Button47.Click
        Dim frmp As New add_Job_L
        frmp.state = "edit"
        frmp.id = dgvLJ.CurrentRow.Cells(0).Value
        frmp.txtN.Text = dgvLJ.CurrentRow.Cells(1).Value
        frmp.btnEnter.Text = "تعديل"
        frmp.ShowDialog()
        fillDGV()
    End Sub

    Private Sub Button50_Click(sender As Object, e As EventArgs) Handles Button50.Click
        Dim frmp As New add_Deg
        frmp.state = "add"
        frmp.btnEnter.Text = "اضافة"
        frmp.ShowDialog()
        fillDGV()
    End Sub

    Private Sub Button49_Click(sender As Object, e As EventArgs) Handles Button49.Click
        Dim frmp As New add_Deg
        frmp.state = "edit"
        frmp.id = dgvD.CurrentRow.Cells(0).Value
        frmp.txtN.Text = dgvD.CurrentRow.Cells(1).Value
        frmp.btnEnter.Text = "تعديل"
        frmp.ShowDialog()
        fillDGV()
    End Sub

    Private Sub Button52_Click(sender As Object, e As EventArgs) Handles Button52.Click
        Dim frmp As New add_Spec
        frmp.state = "add"
        frmp.btnEnter.Text = "اضافة"
        frmp.ShowDialog()
        fillDGV()
    End Sub

    Private Sub Button51_Click(sender As Object, e As EventArgs) Handles Button51.Click
        Dim frmp As New add_Spec
        frmp.state = "edit"
        frmp.id = dgvS.CurrentRow.Cells(0).Value
        frmp.txtN.Text = dgvS.CurrentRow.Cells(1).Value
        frmp.btnEnter.Text = "تعديل"
        frmp.ShowDialog()
        fillDGV()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles btnadd_Emp.Click
        Try

            Dim cmd As New SqlCommand("INSERT INTO [dbo].[Employees] ([Emp_Id],[Emp_Name],[Emp_M],[Conf_Type],[Conf_Id],[Emp_NW],[Birth_Date],[Birth_Place],[Social_Case],[Gender],[Nationa],[Address],[Phone],[Email],[Data_of_direct_action],[Data_of_original_work],[Annual_leave_balance],[Emergency_leave_balance],[Job_Id],[Fun_level_id],[Fun_Deg_id],[Cer_id],[Spec_id],[Qual_id],[Costing],[Getting_Date],[Country],[Dep_id]) VALUES (@Emp_Id,@Emp_Name,@Emp_M,@Conf_Type,@Conf_Id,@Emp_NW,@Birth_Date,@Birth_Place,@Social_Case,@Gender,@Nationa, @Address,@Phone,@Email,@Data_of_direct_action,@Data_of_original_work,@Annual_leave_balance,@Emergency_leave_balance, @Job_Id,@Fun_level_id,@Fun_Deg_id,@Cer_id,@Spec_id,@Qual_id,@Costing,@Getting_Date, @Country,@Dep_id)", con)

            ' @Spec_id,@Qual_id,@Costing,@Getting_Date, @Country,@Dep_id
            cmd.Parameters.AddWithValue("@Emp_Id", SqlDbType.Int).Value = Emp_Id.Text
            cmd.Parameters.AddWithValue("@Emp_Name", SqlDbType.VarChar).Value = Emp_Name.Text
            cmd.Parameters.AddWithValue("@Emp_M", SqlDbType.VarChar).Value = Emp_M.Text
            cmd.Parameters.AddWithValue("@Conf_Type", SqlDbType.VarChar).Value = Conf_Type.SelectedItem.ToString
            cmd.Parameters.AddWithValue("@Conf_Id", SqlDbType.VarChar).Value = Conf_Id.Text
            cmd.Parameters.AddWithValue("@Emp_NW", SqlDbType.Int).Value = Emp_NW.Text
            cmd.Parameters.AddWithValue("@Birth_Date", SqlDbType.Date).Value = Birth_Data.Value
            cmd.Parameters.AddWithValue("@Birth_Place", SqlDbType.Int).Value = CM_Birth_Place.SelectedIndex + 1
            cmd.Parameters.AddWithValue("@Social_Case", SqlDbType.VarChar).Value = CM_Social_Case.SelectedItem.ToString
            cmd.Parameters.AddWithValue("@Gender", SqlDbType.VarChar).Value = CM_Gender.SelectedItem.ToString
            cmd.Parameters.AddWithValue("@Nationa", SqlDbType.VarChar).Value = Nationa.Text
            cmd.Parameters.AddWithValue("@Address", SqlDbType.VarChar).Value = Address.Text
            cmd.Parameters.AddWithValue("@Phone", SqlDbType.Int).Value = Phone.Text
            cmd.Parameters.AddWithValue("@Email", SqlDbType.VarChar).Value = Email.Text
            cmd.Parameters.AddWithValue("@Data_of_direct_action", SqlDbType.Date).Value = D_O_D_A.Value
            cmd.Parameters.AddWithValue("@Data_of_original_work", SqlDbType.Date).Value = D_O_O_W.Value
            cmd.Parameters.AddWithValue("@Annual_leave_balance", SqlDbType.Int).Value = Annual_L_Balance.Text
            cmd.Parameters.AddWithValue("@Emergency_leave_balance", SqlDbType.Int).Value = E_L_Balance.Text
            cmd.Parameters.AddWithValue("@Job_Id", SqlDbType.Int).Value = CM_Job_Id.SelectedIndex + 1
            cmd.Parameters.AddWithValue("@Fun_level_id", SqlDbType.Int).Value = CM_L_J_Id.SelectedIndex + 1
            cmd.Parameters.AddWithValue("@Fun_Deg_id", SqlDbType.Int).Value = CM_F_Deg_Id.SelectedIndex + 1
            cmd.Parameters.AddWithValue("@Cer_id", SqlDbType.Int).Value = Cer_Id.Text
            cmd.Parameters.AddWithValue("@Spec_id", SqlDbType.Int).Value = CM_Spec_Id.SelectedIndex + 1
            cmd.Parameters.AddWithValue("@Qual_id", SqlDbType.Int).Value = CM_Qual_Id.SelectedIndex + 1
            cmd.Parameters.AddWithValue("@Costing", SqlDbType.VarChar).Value = CM_Costing.SelectedItem.ToString
            cmd.Parameters.AddWithValue("@Getting_Date", SqlDbType.Date).Value = Getting_Date.Value
            cmd.Parameters.AddWithValue("@Country", SqlDbType.Int).Value = CM_Country.SelectedIndex + 1
            cmd.Parameters.AddWithValue("@Dep_id", SqlDbType.Int).Value = CM_Dep_Id.SelectedIndex + 1

            con.Open()
            cmd.ExecuteNonQuery()
            MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")
            txt_Name_Mang.Clear()
        Catch ex As Exception

            MsgBox(ex.Message)
        Finally
            con.Close()
            fillDGV()
            c_r()

        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnexit_Emp.Click
        cler_Emp()

    End Sub

    Private Sub dgvEmp_DoubleClick(sender As Object, e As EventArgs) Handles dgvEmp.DoubleClick
        If TabFamily.Focus = True Then
            fill_Family(dgvFamily_Emp, dgvEmp.CurrentRow.Cells(0).Value)
        End If
        If Emp_Name.Focus = True Then
            Emp_Id.Text = dgvEmp.CurrentRow.Cells(0).Value
            Emp_Name.Text = dgvEmp.CurrentRow.Cells(1).Value
            Emp_M.Text = dgvEmp.CurrentRow.Cells(2).Value
            Conf_Type.SelectedItem = dgvEmp.CurrentRow.Cells(3).Value
            Conf_Id.Text = dgvEmp.CurrentRow.Cells(4).Value
            Emp_NW.Text = dgvEmp.CurrentRow.Cells(5).Value
            Birth_Data.Value = dgvEmp.CurrentRow.Cells(6).Value
            CM_Birth_Place.SelectedIndex = dgvEmp.CurrentRow.Cells(7).Value - 1
            CM_Social_Case.SelectedItem = dgvEmp.CurrentRow.Cells(8).Value.ToString
            CM_Gender.SelectedItem = dgvEmp.CurrentRow.Cells(9).Value.ToString
            Nationa.Text = dgvEmp.CurrentRow.Cells(10).Value
            Address.Text = dgvEmp.CurrentRow.Cells(11).Value
            Phone.Text = dgvEmp.CurrentRow.Cells(12).Value
            Email.Text = dgvEmp.CurrentRow.Cells(13).Value
            D_O_D_A.Value = dgvEmp.CurrentRow.Cells(14).Value
            D_O_O_W.Value = dgvEmp.CurrentRow.Cells(15).Value
            Annual_L_Balance.Text = dgvEmp.CurrentRow.Cells(16).Value
            E_L_Balance.Text = dgvEmp.CurrentRow.Cells(17).Value
            CM_Job_Id.SelectedIndex = dgvEmp.CurrentRow.Cells(18).Value - 1
            CM_L_J_Id.SelectedIndex = dgvEmp.CurrentRow.Cells(19).Value - 1
            CM_F_Deg_Id.SelectedIndex = dgvEmp.CurrentRow.Cells(20).Value - 1
            Cer_Id.Text = dgvEmp.CurrentRow.Cells(21).Value
            CM_Spec_Id.SelectedIndex = dgvEmp.CurrentRow.Cells(22).Value - 1
            CM_Qual_Id.SelectedIndex = dgvEmp.CurrentRow.Cells(23).Value - 1
            CM_Costing.SelectedItem = dgvEmp.CurrentRow.Cells(24).Value.ToString
            CM_Country.SelectedIndex = dgvEmp.CurrentRow.Cells(26).Value - 1
            CM_Dep_Id.SelectedIndex = dgvEmp.CurrentRow.Cells(27).Value - 1
            btnadd_Emp.Enabled = False
            btnedit_Emp.Enabled = True
            btnDelet_Emp.Enabled = True
        End If
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Dim frmp As New addFamily_Emp
        frmp.state = "add"
        frmp.btnEnter.Text = "اضافة"
        frmp.txtEmp_Id.Text = dgvEmp.CurrentRow.Cells(0).Value
        frmp.ShowDialog()
        fillDGV()
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Dim frmp As New addFamily_Emp
        frmp.state = "edit"
        fill_Combo(frmp.CM_Birth_Place_F, "select * from Places", 1)
        frmp.txtEmp_Id.Text = dgvFamily_Emp.CurrentRow.Cells(7).Value
        frmp.txtName.Text = dgvFamily_Emp.CurrentRow.Cells(1).Value
        frmp.txtNW.Text = dgvFamily_Emp.CurrentRow.Cells(0).Value
        frmp.CM_Adjective.SelectedItem = dgvFamily_Emp.CurrentRow.Cells(2).Value
        frmp.CM_Gender.SelectedItem = dgvFamily_Emp.CurrentRow.Cells(3).Value
        frmp.txtNationa.Text = dgvFamily_Emp.CurrentRow.Cells(4).Value
        frmp.CM_Birth_Place_F.SelectedIndex = (dgvFamily_Emp.CurrentRow.Cells(6).Value - 1)
        'CM_M_To_D.SelectedIndex = dgvDep.CurrentRow.Cells(3).Value - 1
        frmp.Birth_Date.Value = dgvFamily_Emp.CurrentRow.Cells(5).Value
        frmp.btnEnter.Text = "تعديل"
        frmp.ShowDialog()
        fillDGV()
    End Sub


    Private Sub Button53_Click(sender As Object, e As EventArgs) Handles Button53.Click
        Dim MSG_ = MessageBox.Show("هل انت متاكد من حذف :" & dgvFamily_Emp.CurrentRow.Cells(1).Value.ToString, "رسالة تنبيه ", MessageBoxButtons.YesNo)
        If MSG_ = Windows.Forms.DialogResult.Yes Then
            Try
                Dim cmd As New SqlCommand("DELETE FROM [dbo].[Family] WHERE [Emp_Id] = @Emp_Id AND [F_NW] = @F_NW", con)
                cmd.Parameters.AddWithValue("@Emp_Id", SqlDbType.Int).Value = dgvFamily_Emp.CurrentRow.Cells(7).Value
                cmd.Parameters.AddWithValue("@F_NW", SqlDbType.VarChar).Value = dgvFamily_Emp.CurrentRow.Cells(0).Value
                con.Open()
                cmd.ExecuteNonQuery()
                MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")

            Catch ex As Exception

                MsgBox(ex.Message)
            Finally
                con.Close()

                fill_Family(dgvFamily_Emp, dgvEmp.CurrentRow.Cells(0).Value)
            End Try
        End If
    End Sub


    Private Sub btnedit_Emp_Click(sender As Object, e As EventArgs) Handles btnedit_Emp.Click
        Try

            Dim cmd As New SqlCommand("UPDATE [dbo].[Employees]SET [Emp_Name] = @Emp_Name ,[Emp_M] = @Emp_M ,[Conf_Type] = @Conf_Type ,[Conf_Id] = @Conf_Id ,[Emp_NW] = @Emp_NW ,[Birth_Date] = @Birth_Date ,[Birth_Place] = @Birth_Place ,[Social_Case] = @Social_Case ,[Gender] = @Gender ,[Nationa] = @Nationa ,[Address] = @Address ,[Phone] = @Phone ,[Email] = @Email ,[Data_of_direct_action] = @Data_of_direct_action ,[Data_of_original_work] = @Data_of_original_work ,[Annual_leave_balance] = @Annual_leave_balance ,[Emergency_leave_balance] = @Emergency_leave_balance ,[Job_Id] = @Job_Id ,[Fun_level_id] = @Fun_level_id ,[Fun_Deg_id] = @Fun_Deg_id ,[Cer_id] = @Cer_id ,[Spec_id] = @Spec_id ,[Qual_id] = @Qual_id ,[Costing] = @Costing,[Getting_Date] = @Getting_Date,[Country] = @Country,[Dep_id] = @Dep_id WHERE [Emp_Id] =@Emp_Id", con)


            cmd.Parameters.AddWithValue("@Emp_Id", SqlDbType.Int).Value = Emp_Id.Text
            cmd.Parameters.AddWithValue("@Emp_Name", SqlDbType.VarChar).Value = Emp_Name.Text
            cmd.Parameters.AddWithValue("@Emp_M", SqlDbType.VarChar).Value = Emp_M.Text
            cmd.Parameters.AddWithValue("@Conf_Type", SqlDbType.VarChar).Value = Conf_Type.SelectedItem.ToString
            cmd.Parameters.AddWithValue("@Conf_Id", SqlDbType.VarChar).Value = Conf_Id.Text
            cmd.Parameters.AddWithValue("@Emp_NW", SqlDbType.Int).Value = Emp_NW.Text
            cmd.Parameters.AddWithValue("@Birth_Date", SqlDbType.Date).Value = Birth_Data.Value
            cmd.Parameters.AddWithValue("@Birth_Place", SqlDbType.Int).Value = CM_Birth_Place.SelectedIndex + 1
            cmd.Parameters.AddWithValue("@Social_Case", SqlDbType.VarChar).Value = CM_Social_Case.SelectedItem.ToString
            cmd.Parameters.AddWithValue("@Gender", SqlDbType.VarChar).Value = CM_Gender.SelectedItem.ToString
            cmd.Parameters.AddWithValue("@Nationa", SqlDbType.VarChar).Value = Nationa.Text
            cmd.Parameters.AddWithValue("@Address", SqlDbType.VarChar).Value = Address.Text
            cmd.Parameters.AddWithValue("@Phone", SqlDbType.Int).Value = Phone.Text
            cmd.Parameters.AddWithValue("@Email", SqlDbType.VarChar).Value = Email.Text
            cmd.Parameters.AddWithValue("@Data_of_direct_action", SqlDbType.Date).Value = D_O_D_A.Value
            cmd.Parameters.AddWithValue("@Data_of_original_work", SqlDbType.Date).Value = D_O_O_W.Value
            cmd.Parameters.AddWithValue("@Annual_leave_balance", SqlDbType.Int).Value = Annual_L_Balance.Text
            cmd.Parameters.AddWithValue("@Emergency_leave_balance", SqlDbType.Int).Value = E_L_Balance.Text
            cmd.Parameters.AddWithValue("@Job_Id", SqlDbType.Int).Value = CM_Job_Id.SelectedIndex + 1
            cmd.Parameters.AddWithValue("@Fun_level_id", SqlDbType.Int).Value = CM_L_J_Id.SelectedIndex + 1
            cmd.Parameters.AddWithValue("@Fun_Deg_id", SqlDbType.Int).Value = CM_F_Deg_Id.SelectedIndex + 1
            cmd.Parameters.AddWithValue("@Cer_id", SqlDbType.Int).Value = Cer_Id.Text
            cmd.Parameters.AddWithValue("@Spec_id", SqlDbType.Int).Value = CM_Spec_Id.SelectedIndex + 1
            cmd.Parameters.AddWithValue("@Qual_id", SqlDbType.Int).Value = CM_Qual_Id.SelectedIndex + 1
            cmd.Parameters.AddWithValue("@Costing", SqlDbType.VarChar).Value = CM_Costing.SelectedItem.ToString
            cmd.Parameters.AddWithValue("@Getting_Date", SqlDbType.Date).Value = Getting_Date.Value
            cmd.Parameters.AddWithValue("@Country", SqlDbType.Int).Value = CM_Country.SelectedIndex + 1
            cmd.Parameters.AddWithValue("@Dep_id", SqlDbType.Int).Value = CM_Dep_Id.SelectedIndex + 1

            con.Open()
            cmd.ExecuteNonQuery()
            MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")
            txt_Name_Mang.Clear()
        Catch ex As Exception

            MsgBox(ex.Message)
        Finally
            con.Close()
            fillDGV()
            c_r()
            cler_Emp()
            btnadd_Emp.Enabled = True
        End Try
    End Sub

    Private Sub btnDelet_Emp_Click(sender As Object, e As EventArgs) Handles btnDelet_Emp.Click
        Dim MSG_ = MessageBox.Show("هل انت متاكد من حذف :" & dgvEmp.CurrentRow.Cells(1).Value.ToString, "رسالة تنبيه ", MessageBoxButtons.YesNo)
        If MSG_ = Windows.Forms.DialogResult.Yes Then
            Try
                ';Family 
                con.Open()
                Dim cmdfamily As New SqlCommand("DELETE FROM [dbo].[Family] WHERE [Emp_Id] = @Emp_Id ", con)
                cmdfamily.Parameters.AddWithValue("@Emp_Id", SqlDbType.Int).Value = dgvEmp.CurrentRow.Cells(0).Value
                cmdfamily.ExecuteNonQuery()
                Dim cmdHoli As New SqlCommand("DELETE FROM [dbo].[Holidays] WHERE [Emp_Id] = @Emp_Id ", con)
                cmdHoli.Parameters.AddWithValue("@Emp_Id", SqlDbType.Int).Value = dgvEmp.CurrentRow.Cells(0).Value

                cmdHoli.ExecuteNonQuery()

                Dim cmd As New SqlCommand("DELETE FROM [dbo].[Employees] WHERE [Emp_Id] = @Emp_Id ", con)
                cmd.Parameters.AddWithValue("@Emp_Id", SqlDbType.Int).Value = dgvEmp.CurrentRow.Cells(0).Value

                cmd.ExecuteNonQuery()
                MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")

            Catch ex As Exception

                MsgBox(ex.Message)
            Finally
                con.Close()
                btnedit_Emp.Enabled = False
                btnDelet_Emp.Enabled = False
                btnadd_Emp.Enabled = True

            End Try
        End If
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        CaseEmp.ShowDialog()
    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click

    End Sub

    Private Sub Button25_Click(sender As Object, e As EventArgs) Handles Button25.Click

    End Sub

    Private Sub Button6_Click_1(sender As Object, e As EventArgs) Handles Button6.Click
        Try
            Backup()
            MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")
        Catch

        End Try
    End Sub

   
    Private Sub Button35_Click(sender As Object, e As EventArgs) Handles Button35.Click
        Try
            Dim strQury As String = ""


            If stat_User = "add" Then
                strQury = "INSERT INTO [dbo].[Users] ([User_Name],[User_pass],[User_email]) VALUES ('" & txt_U_n.Text & "','" & txt_User_pass.Text & "','" & txt_User_email.Text & "')"

            Else

                strQury = " UPDATE [dbo].[Users] SET [User_email] = '" & txt_User_email.Text & "',[User_pass]='" & txt_User_pass.Text & "',[Adjective]=" & CO_User_Adj.SelectedIndex + 1 & "', [User_Name]= " & txt_U_n.Text & "WHERE [User_id] ="

            End If
            Dim cmd As New SqlCommand(strQury, con)
            con.Open()
            cmd.ExecuteNonQuery()
            MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")
            txt_Name_Mang.Clear()
        Catch ex As Exception

            MsgBox(ex.Message)
        Finally
            con.Close()
            fillDGV()
            Panal_User.Visible = False
            c_r()
        End Try
    End Sub

    Private Sub Button37_Click(sender As Object, e As EventArgs) Handles Button37.Click
        Panal_User.Visible = True
        txt_U_n.Clear()
        txt_U_n.Focus()
        txt_User_pass.Clear()
        txt_User_email.Clear()
        CO_User_Adj.ResetText()
    
        stat_User = "add"
        c_r()
    End Sub

    Private Sub Button34_Click(sender As Object, e As EventArgs) Handles Button34.Click
        Panal_User.Visible = False
        txt_U_n.Clear()
        txt_User_pass.Clear()
        txt_User_email.Clear()
        CO_User_Adj.ResetText()


    End Sub

    Private Sub Button38_Click(sender As Object, e As EventArgs) Handles Button38.Click
        Panal_User.Visible = False
        txt_U_n.Clear()
        txt_User_pass.Clear()
        txt_User_email.Clear()
        CO_User_Adj.ResetText()
        c_r()
    End Sub

    Private Sub Button36_Click(sender As Object, e As EventArgs) Handles Button36.Click
        Panal_User.Visible = True
        txt_U_n.Focus()
        txt_User_pass.Text = dgvuser.CurrentRow.Cells(1).Value.ToString
        txt_User_email.Text = dgvuser.CurrentRow.Cells(1).Value.ToString
        CO_User_Adj.SelectedIndex = dgvuser.CurrentRow.Cells(2).Value
        stat_User = "edit"
    End Sub

    
    Private Sub dgvDep_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDep.CellContentClick

    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        If txt_Dep_Id_A.Text = "" Then
            MsgBox("الحقل فارغ")
        Else
            Dim rpt As New CrystalReport1
            Dim f As New Form1
            rpt.RecordSelectionFormula = "{Sections.Dep_id}=" + Me.txt_Dep_Id_A.Text + ""
            f.CrystalReportViewer1.ReportSource = rpt
            f.Show()
        End If
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        If txt_Mane_Id_A.Text = "" Then
            MsgBox("الحقل فارغ")
        Else
            Dim rpt As New CrystalReport3
            Dim f As New Form2
            rpt.RecordSelectionFormula = "{Managments.Mang_id}=" + Me.txt_Mane_Id_A.Text + ""
            f.CrystalReportViewer1.ReportSource = rpt
            f.Show()
        End If
    End Sub

    Private Sub Button54_Click(sender As Object, e As EventArgs) Handles Button54.Click
        If TextBox32.Text = "" Then
            MsgBox("الحقل فارغ")
        Else
            Dim rpt As New CrystalReport2
            Dim f As New Form3
            rpt.RecordSelectionFormula = "{Courses.Cours_Name}=" + Me.TextBox32.Text + ""
            f.CrystalReportViewer1.ReportSource = rpt
            f.Show()
        End If
    End Sub
End Class