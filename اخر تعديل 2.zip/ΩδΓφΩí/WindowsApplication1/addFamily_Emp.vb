﻿Imports System.Data
Imports System.Data.SqlClient
Public Class addFamily_Emp
    Public state As String = "add"

    Dim con As SqlConnection = New SqlConnection("Data Source=DESKTOP-3A2EOS3\SQLEXPRESS;Initial Catalog=Emp;Integrated Security=True")

    Private Sub addFamily_Emp_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fill_Combo(CM_Birth_Place_F, "select * from Places", 1)
        If txtEmp_Id.Text = Nothing Then
            MessageBox.Show("يرجي اختيار الموظف من شاشة العرض", "رسالة تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        Try
            Dim strQury As String = ""


            If state = "add" Then
                strQury = "INSERT INTO [dbo].[Family]([F_NW],[F_Name],[Adjective],[Gender],[Nationa],[Birth_Date],[Birth_Place],[Emp_Id])VALUES(@F_NW,@F_Name,@Adjective,@Gender,@Nationa, @Birth_Date,@Birth_Place,@Emp_Id)"

            Else

                strQury = "UPDATE [dbo].[Family] SET [F_NW] = @F_NW ,[F_Name] =@F_Name ,[Adjective] = @Adjective, [Gender] =@Gender,[Nationa] = @Nationa,[Birth_Date] = @Birth_Date,[Birth_Place] =@Birth_Place WHERE [Emp_Id] = @Emp_Id AND [F_NW] = @F_NW"

            End If
            Dim cmd As New SqlCommand(strQury, con)

            cmd.Parameters.AddWithValue("@Emp_Id", SqlDbType.Int).Value = txtEmp_Id.Text
            cmd.Parameters.AddWithValue("@F_NW", SqlDbType.VarChar).Value = txtNW.Text
            cmd.Parameters.AddWithValue("@F_Name", SqlDbType.VarChar).Value = txtName.Text
            cmd.Parameters.AddWithValue("@Adjective", SqlDbType.VarChar).Value = CM_Adjective.SelectedItem.ToString
            cmd.Parameters.AddWithValue("@Gender", SqlDbType.VarChar).Value = CM_Gender.SelectedItem.ToString
            cmd.Parameters.AddWithValue("@Nationa", SqlDbType.Int).Value = txtNationa.Text
            cmd.Parameters.AddWithValue("@Birth_Date", SqlDbType.Date).Value = Birth_Date.Value
            cmd.Parameters.AddWithValue("@Birth_Place", SqlDbType.Int).Value = CM_Birth_Place_F.SelectedIndex + 1
            con.Open()
            cmd.ExecuteNonQuery()
            MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")

        Catch ex As Exception

            MsgBox(ex.Message)
        Finally
            con.Close()
            Me.Close()
            fill_Family(Home.dgvFamily_Emp, Home.dgvEmp.CurrentRow.Cells(0).Value)
        End Try
    End Sub
End Class