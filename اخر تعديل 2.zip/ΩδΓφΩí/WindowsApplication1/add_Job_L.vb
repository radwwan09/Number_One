﻿Imports System.Data
Imports System.Data.SqlClient
Public Class add_Job_L
    Public state As String = "add"
    Public id As Integer
    Dim con As SqlConnection = New SqlConnection("Data Source=DESKTOP-3A2EOS3\SQLEXPRESS;Initial Catalog=Emp;Integrated Security=True")

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        Try
            Dim strQury As String = ""


            If state = "add" Then
                strQury = "INSERT INTO [dbo].[Job_level] ([Job_level]) VALUES ('" & txtN.Text & "')"

            Else

                strQury = " UPDATE [dbo].[Job_level] SET [Job_level] = '" & txtN.Text & "' WHERE Job_level_id= " & id

            End If
            Dim cmd As New SqlCommand(strQury, con)
            con.Open()
            cmd.ExecuteNonQuery()
            MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")

        Catch ex As Exception

            MsgBox(ex.Message)
        Finally
            con.Close()
            Me.Close()

        End Try
    End Sub

    Private Sub add_Job_L_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class