﻿Imports System.Data
Imports System.Data.SqlClient
Public Class CaseEmp
    Public state As String = "add"

    Dim con As SqlConnection = New SqlConnection("Data Source=DESKTOP-3A2EOS3\SQLEXPRESS;Initial Catalog=Emp;Integrated Security=True")
    Dim cmd As New SqlCommand
    Private Sub CM_Adjective_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CM_Case.SelectedIndexChanged
        If CM_Case.SelectedIndex = 2 Then
            End_Date.Visible = True
            txtReason.Visible = True
            Label3.Visible = True
            Label7.Visible = True
        Else
            End_Date.Visible = False
            txtReason.Visible = False
            Label3.Visible = False
            Label7.Visible = False
        End If
    End Sub

    Private Sub CaseEmp_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        End_Date.Visible = False
        txtReason.Visible = False
        Label3.Visible = False
        Label7.Visible = False
    End Sub

    Private Sub txtEmp_Id_KeyDown(sender As Object, e As KeyEventArgs) Handles txtEmp_Id.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then

                cmd = New SqlCommand("select Emp_Name from Employees  where Emp_Id =" & txtEmp_Id.Text, con)
                con.Open()
                Dim dr As SqlDataReader = cmd.ExecuteReader
                dr.Read()
                If dr.HasRows Then
                    txtName.Text = dr(0)
                  
                Else
                    MsgBox("لا يوجد موظف بالرقم الذي ادخلته", MsgBoxStyle.Exclamation, "تنبيه")


                End If
                dr.Close()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        Try
         
            If state = "add" Then


                If CM_Case.SelectedIndex = 0 Or CM_Case.SelectedIndex = 1 Then
                    Dim cmd As New SqlCommand("INSERT INTO [dbo].[Case_Emp]([Emp_id],[Case_Id])VALUES(@Emp_id ,@Case_Id )", con)

                    cmd.Parameters.AddWithValue("@Emp_Id", SqlDbType.Int).Value = txtEmp_Id.Text
                    cmd.Parameters.AddWithValue("@Case_Id", SqlDbType.Int).Value = CM_Case.SelectedIndex


                    con.Open()
                    cmd.ExecuteNonQuery()
                    MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")


                Else
                    Dim cmd As New SqlCommand("INSERT INTO [dbo].[Case_Emp]([Emp_id],[Case_Id],[Date_End],[Reason])VALUES(@Emp_id ,@Case_Id,@Date_End ,@Reason )", con)

                    cmd.Parameters.AddWithValue("@Emp_Id", SqlDbType.Int).Value = txtEmp_Id.Text
                    cmd.Parameters.AddWithValue("@Case_Id", SqlDbType.Int).Value = CM_Case.SelectedIndex
                    cmd.Parameters.AddWithValue("@Date_End", SqlDbType.VarChar).Value = End_Date.Value
                    cmd.Parameters.AddWithValue("@Reason", SqlDbType.VarChar).Value = txtReason.Text

                    con.Open()
                    cmd.ExecuteNonQuery()
                    MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")


                End If

            Else

                If CM_Case.SelectedIndex = 0 Or CM_Case.SelectedIndex = 1 Then
                    Dim cmd As New SqlCommand("INSERT INTO [dbo].[Case_Emp]([Emp_id],[Case_Id])VALUES(@Emp_id ,@Case_Id )", con)

                    cmd.Parameters.AddWithValue("@Emp_Id", SqlDbType.Int).Value = txtEmp_Id.Text
                    cmd.Parameters.AddWithValue("@Case_Id", SqlDbType.Int).Value = CM_Case.SelectedIndex


                    con.Open()
                    cmd.ExecuteNonQuery()
                    MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")


                Else
                    Dim cmd As New SqlCommand("INSERT INTO [dbo].[Case_Emp]([Emp_id],[Case_Id],[Date_End],[Reason])VALUES(@Emp_id ,@Case_Id,@Date_End ,@Reason )", con)

                    cmd.Parameters.AddWithValue("@Emp_Id", SqlDbType.Int).Value = txtEmp_Id.Text
                    cmd.Parameters.AddWithValue("@Case_Id", SqlDbType.Int).Value = CM_Case.SelectedIndex
                    cmd.Parameters.AddWithValue("@Date_End", SqlDbType.VarChar).Value = End_Date.Value
                    cmd.Parameters.AddWithValue("@Reason", SqlDbType.VarChar).Value = txtReason.Text

                    con.Open()
                    cmd.ExecuteNonQuery()
                    MsgBox("تمت العمليه بنجاح", MsgBoxStyle.Information, "ادارة المنظومة")


                End If

            End If

        Catch ex As Exception

            MsgBox(ex.Message)
        Finally
            con.Close()
            Me.Close()
            Home.fillDGV()
        End Try
    End Sub
End Class