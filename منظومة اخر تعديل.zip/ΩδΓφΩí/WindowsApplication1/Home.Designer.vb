﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Home
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.TabControl6 = New System.Windows.Forms.TabControl()
        Me.TabPage15 = New System.Windows.Forms.TabPage()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Panal_User = New System.Windows.Forms.Panel()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.CO_User_Adj = New System.Windows.Forms.ComboBox()
        Me.txt_User_email = New System.Windows.Forms.TextBox()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.txt_User_pass = New System.Windows.Forms.TextBox()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.txt_U_n = New System.Windows.Forms.TextBox()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.txt_U = New System.Windows.Forms.TextBox()
        Me.dgvuser = New System.Windows.Forms.DataGridView()
        Me.User_Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.User_Pass = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.User_Email = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Adjective = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage16 = New System.Windows.Forms.TabPage()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.dgvS = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button51 = New System.Windows.Forms.Button()
        Me.Button52 = New System.Windows.Forms.Button()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.dgvD = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button49 = New System.Windows.Forms.Button()
        Me.Button50 = New System.Windows.Forms.Button()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.dgvLJ = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button47 = New System.Windows.Forms.Button()
        Me.Button48 = New System.Windows.Forms.Button()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.dgvJ = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.dgvTH = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.dgvQl = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.dgvPl = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.TabControl5 = New System.Windows.Forms.TabControl()
        Me.TabPage13 = New System.Windows.Forms.TabPage()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.TextBox34 = New System.Windows.Forms.TextBox()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.DateTimePicker14 = New System.Windows.Forms.DateTimePicker()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.DateTimePicker13 = New System.Windows.Forms.DateTimePicker()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.txt_C = New System.Windows.Forms.TextBox()
        Me.dgvCourses = New System.Windows.Forms.DataGridView()
        Me.Cours_Id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cours_Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.M_Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cours_Start = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cours_End = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Period = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage14 = New System.Windows.Forms.TabPage()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.TextBox37 = New System.Windows.Forms.TextBox()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.ComboBox24 = New System.Windows.Forms.ComboBox()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.TextBox36 = New System.Windows.Forms.TextBox()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.txt_T = New System.Windows.Forms.TextBox()
        Me.DataGridView7 = New System.Windows.Forms.DataGridView()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TabControl4 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.dgv_Mang = New System.Windows.Forms.DataGridView()
        Me.Mang_Id_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Mang_Name_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panal_Mang = New System.Windows.Forms.Panel()
        Me.txt_Mane_Id_A = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.txt_Name_Mang = New System.Windows.Forms.TextBox()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.txt_mang = New System.Windows.Forms.TextBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.panal_Dep = New System.Windows.Forms.Panel()
        Me.txt_Dep_Id_A = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.D_O_D = New System.Windows.Forms.DateTimePicker()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.CM_M_To_D = New System.Windows.Forms.ComboBox()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.txt_Name_Dep = New System.Windows.Forms.TextBox()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.txt_dep = New System.Windows.Forms.TextBox()
        Me.dgvDep = New System.Windows.Forms.DataGridView()
        Me.Dep_Id_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Dep_Name_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Dep_O_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Mang_Id_Dep = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage18 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TabControl3 = New System.Windows.Forms.TabControl()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtEmp_name_H = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtEmp_id_H = New System.Windows.Forms.TextBox()
        Me.txtDay_Emergency_H = New System.Windows.Forms.TextBox()
        Me.txtDay_Annual_H = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.L_D_H_A = New System.Windows.Forms.Label()
        Me.CM_H_type_A = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.H_end_A = New System.Windows.Forms.DateTimePicker()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.H_start_A = New System.Windows.Forms.DateTimePicker()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtEmp_name_E = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtEmp_id_E = New System.Windows.Forms.TextBox()
        Me.txtDay_Emergency_E = New System.Windows.Forms.TextBox()
        Me.txtDay_Annual_E = New System.Windows.Forms.TextBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.L_D_H_E = New System.Windows.Forms.Label()
        Me.CM_H_type_E = New System.Windows.Forms.ComboBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.H_end_E = New System.Windows.Forms.DateTimePicker()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.H_start_E = New System.Windows.Forms.DateTimePicker()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TabPage12 = New System.Windows.Forms.TabPage()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txt_H = New System.Windows.Forms.TextBox()
        Me.dgvHoli_Emp = New System.Windows.Forms.DataGridView()
        Me.ID_H_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.H_Id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.H_Period_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.H_Start = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.H_End_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Emp_Id_H_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Emp_P = New System.Windows.Forms.TabPage()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TabEmp = New System.Windows.Forms.TabControl()
        Me.TabFamily = New System.Windows.Forms.TabPage()
        Me.Button53 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.dgvFamily_Emp = New System.Windows.Forms.DataGridView()
        Me.family_NW_dg = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.family_Name_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.family_Adjective_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.family_Gender_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.family_Nationa_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.family_Birth_Date_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.family_Birth_Place_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.family_Emp_Id_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tabcase_Emp = New System.Windows.Forms.TabPage()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.dgvCaseEmp = New System.Windows.Forms.DataGridView()
        Me.Case_Emp_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Case_Id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Date_End_Emp = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Reason = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnedit_Emp = New System.Windows.Forms.Button()
        Me.btnDelet_Emp = New System.Windows.Forms.Button()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.CM_Dep_Id = New System.Windows.Forms.ComboBox()
        Me.CM_Country = New System.Windows.Forms.ComboBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Getting_Date = New System.Windows.Forms.DateTimePicker()
        Me.btnexit_Emp = New System.Windows.Forms.Button()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.CM_Costing = New System.Windows.Forms.ComboBox()
        Me.btnadd_Emp = New System.Windows.Forms.Button()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.CM_Qual_Id = New System.Windows.Forms.ComboBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.CM_Spec_Id = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Cer_Id = New System.Windows.Forms.TextBox()
        Me.CM_L_J_Id = New System.Windows.Forms.ComboBox()
        Me.CM_Job_Id = New System.Windows.Forms.ComboBox()
        Me.Annual_L_Balance = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.D_O_D_A = New System.Windows.Forms.DateTimePicker()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.CM_F_Deg_Id = New System.Windows.Forms.ComboBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.E_L_Balance = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.D_O_O_W = New System.Windows.Forms.DateTimePicker()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.CM_Birth_Place = New System.Windows.Forms.ComboBox()
        Me.Conf_Id = New System.Windows.Forms.TextBox()
        Me.Emp_Id = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Email = New System.Windows.Forms.TextBox()
        Me.Emp_Name = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Phone = New System.Windows.Forms.TextBox()
        Me.Emp_M = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Address = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Emp_NW = New System.Windows.Forms.TextBox()
        Me.Nationa = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Conf_Type = New System.Windows.Forms.ComboBox()
        Me.CM_Gender = New System.Windows.Forms.ComboBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Birth_Data = New System.Windows.Forms.DateTimePicker()
        Me.CM_Social_Case = New System.Windows.Forms.ComboBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_Emp = New System.Windows.Forms.TextBox()
        Me.dgvEmp = New System.Windows.Forms.DataGridView()
        Me.Emp_Id_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Emp_Name_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Emp_M_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Conf_Type_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Conf_Id_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Emp_NW_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Birth_Date_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Birth_Place_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Social_Case_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Gender_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Nationa_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Address_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Phone_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Email_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.D_O_D_A_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.D_O_O_W_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.A_L_B_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.E_L_B_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Job_Id_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.F_L_Id_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.F_D_Id_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cer_Id_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Spec_ID_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Qual_Id_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Costing_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Getting_Date_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Country_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Dep_Id_Emp_D = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage6.SuspendLayout()
        Me.TabControl6.SuspendLayout()
        Me.TabPage15.SuspendLayout()
        Me.Panal_User.SuspendLayout()
        CType(Me.dgvuser, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage16.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        CType(Me.dgvS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox10.SuspendLayout()
        CType(Me.dgvD, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox9.SuspendLayout()
        CType(Me.dgvLJ, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox8.SuspendLayout()
        CType(Me.dgvJ, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        CType(Me.dgvTH, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        CType(Me.dgvQl, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.dgvPl, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        Me.TabControl5.SuspendLayout()
        Me.TabPage13.SuspendLayout()
        Me.Panel8.SuspendLayout()
        CType(Me.dgvCourses, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage14.SuspendLayout()
        Me.Panel9.SuspendLayout()
        CType(Me.DataGridView7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.TabControl4.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.dgv_Mang, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panal_Mang.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.panal_Dep.SuspendLayout()
        CType(Me.dgvDep, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.TabControl3.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        CType(Me.dgvHoli_Emp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Emp_P.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabEmp.SuspendLayout()
        Me.TabFamily.SuspendLayout()
        CType(Me.dgvFamily_Emp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabcase_Emp.SuspendLayout()
        CType(Me.dgvCaseEmp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.dgvEmp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.TabControl6)
        Me.TabPage6.Location = New System.Drawing.Point(4, 26)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(1235, 813)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "المستخدم"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'TabControl6
        '
        Me.TabControl6.Controls.Add(Me.TabPage15)
        Me.TabControl6.Controls.Add(Me.TabPage16)
        Me.TabControl6.Location = New System.Drawing.Point(3, 3)
        Me.TabControl6.Name = "TabControl6"
        Me.TabControl6.RightToLeftLayout = True
        Me.TabControl6.SelectedIndex = 0
        Me.TabControl6.Size = New System.Drawing.Size(1229, 784)
        Me.TabControl6.TabIndex = 0
        '
        'TabPage15
        '
        Me.TabPage15.Controls.Add(Me.Button6)
        Me.TabPage15.Controls.Add(Me.Button38)
        Me.TabPage15.Controls.Add(Me.Button33)
        Me.TabPage15.Controls.Add(Me.Panal_User)
        Me.TabPage15.Controls.Add(Me.Button36)
        Me.TabPage15.Controls.Add(Me.Button37)
        Me.TabPage15.Controls.Add(Me.Label98)
        Me.TabPage15.Controls.Add(Me.txt_U)
        Me.TabPage15.Controls.Add(Me.dgvuser)
        Me.TabPage15.Location = New System.Drawing.Point(4, 26)
        Me.TabPage15.Name = "TabPage15"
        Me.TabPage15.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage15.Size = New System.Drawing.Size(1221, 754)
        Me.TabPage15.TabIndex = 0
        Me.TabPage15.Text = "المستخدمون"
        Me.TabPage15.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(243, 258)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(159, 36)
        Me.Button6.TabIndex = 26
        Me.Button6.Text = "انشاء نسخة احتياطية لقاعدة البيانات"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button38
        '
        Me.Button38.Location = New System.Drawing.Point(424, 258)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(116, 36)
        Me.Button38.TabIndex = 24
        Me.Button38.Text = "الغاء"
        Me.Button38.UseVisualStyleBackColor = True
        '
        'Button33
        '
        Me.Button33.Location = New System.Drawing.Point(546, 258)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(116, 36)
        Me.Button33.TabIndex = 23
        Me.Button33.Text = "حذف"
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Panal_User
        '
        Me.Panal_User.BackColor = System.Drawing.Color.Gainsboro
        Me.Panal_User.Controls.Add(Me.Label103)
        Me.Panal_User.Controls.Add(Me.CO_User_Adj)
        Me.Panal_User.Controls.Add(Me.txt_User_email)
        Me.Panal_User.Controls.Add(Me.Label102)
        Me.Panal_User.Controls.Add(Me.txt_User_pass)
        Me.Panal_User.Controls.Add(Me.Label104)
        Me.Panal_User.Controls.Add(Me.Button34)
        Me.Panal_User.Controls.Add(Me.Button35)
        Me.Panal_User.Controls.Add(Me.txt_U_n)
        Me.Panal_User.Controls.Add(Me.Label106)
        Me.Panal_User.Location = New System.Drawing.Point(49, 23)
        Me.Panal_User.Name = "Panal_User"
        Me.Panal_User.Size = New System.Drawing.Size(1067, 204)
        Me.Panal_User.TabIndex = 22
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label103.Location = New System.Drawing.Point(389, 81)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(47, 22)
        Me.Label103.TabIndex = 19
        Me.Label103.Text = "الصفة"
        '
        'CO_User_Adj
        '
        Me.CO_User_Adj.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CO_User_Adj.FormattingEnabled = True
        Me.CO_User_Adj.Items.AddRange(New Object() {"مسؤول", "مستخدم"})
        Me.CO_User_Adj.Location = New System.Drawing.Point(194, 81)
        Me.CO_User_Adj.Name = "CO_User_Adj"
        Me.CO_User_Adj.Size = New System.Drawing.Size(179, 28)
        Me.CO_User_Adj.TabIndex = 18
        '
        'txt_User_email
        '
        Me.txt_User_email.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_User_email.Location = New System.Drawing.Point(546, 78)
        Me.txt_User_email.Name = "txt_User_email"
        Me.txt_User_email.Size = New System.Drawing.Size(349, 29)
        Me.txt_User_email.TabIndex = 17
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label102.Location = New System.Drawing.Point(901, 81)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(50, 22)
        Me.Label102.TabIndex = 16
        Me.Label102.Text = "الايميل"
        '
        'txt_User_pass
        '
        Me.txt_User_pass.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_User_pass.Location = New System.Drawing.Point(117, 24)
        Me.txt_User_pass.Name = "txt_User_pass"
        Me.txt_User_pass.Size = New System.Drawing.Size(256, 29)
        Me.txt_User_pass.TabIndex = 15
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label104.Location = New System.Drawing.Point(379, 27)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(83, 22)
        Me.Label104.TabIndex = 14
        Me.Label104.Text = "كلمة المرور"
        '
        'Button34
        '
        Me.Button34.BackColor = System.Drawing.Color.White
        Me.Button34.Location = New System.Drawing.Point(416, 145)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(116, 36)
        Me.Button34.TabIndex = 9
        Me.Button34.Text = "الغاء"
        Me.Button34.UseVisualStyleBackColor = False
        '
        'Button35
        '
        Me.Button35.BackColor = System.Drawing.Color.White
        Me.Button35.Location = New System.Drawing.Point(550, 145)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(116, 36)
        Me.Button35.TabIndex = 9
        Me.Button35.Text = "حفظ"
        Me.Button35.UseVisualStyleBackColor = False
        '
        'txt_U_n
        '
        Me.txt_U_n.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_U_n.Location = New System.Drawing.Point(546, 29)
        Me.txt_U_n.Name = "txt_U_n"
        Me.txt_U_n.Size = New System.Drawing.Size(349, 29)
        Me.txt_U_n.TabIndex = 1
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label106.Location = New System.Drawing.Point(901, 32)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(95, 22)
        Me.Label106.TabIndex = 0
        Me.Label106.Text = "اسم المستخدم"
        '
        'Button36
        '
        Me.Button36.Location = New System.Drawing.Point(668, 258)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(116, 36)
        Me.Button36.TabIndex = 21
        Me.Button36.Text = "تعديل"
        Me.Button36.UseVisualStyleBackColor = True
        '
        'Button37
        '
        Me.Button37.Location = New System.Drawing.Point(790, 258)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(116, 36)
        Me.Button37.TabIndex = 20
        Me.Button37.Text = "اضافة مستخدم"
        Me.Button37.UseVisualStyleBackColor = True
        '
        'Label98
        '
        Me.Label98.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label98.Location = New System.Drawing.Point(767, 319)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(76, 35)
        Me.Label98.TabIndex = 6
        Me.Label98.Text = "بحث :"
        Me.Label98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_U
        '
        Me.txt_U.Location = New System.Drawing.Point(370, 325)
        Me.txt_U.Name = "txt_U"
        Me.txt_U.Size = New System.Drawing.Size(395, 24)
        Me.txt_U.TabIndex = 7
        Me.txt_U.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'dgvuser
        '
        Me.dgvuser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvuser.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.User_Name, Me.User_Pass, Me.User_Email, Me.Adjective})
        Me.dgvuser.Location = New System.Drawing.Point(49, 370)
        Me.dgvuser.Name = "dgvuser"
        Me.dgvuser.RowTemplate.Height = 26
        Me.dgvuser.Size = New System.Drawing.Size(1067, 375)
        Me.dgvuser.TabIndex = 5
        '
        'User_Name
        '
        Me.User_Name.HeaderText = "اسم المستخدم"
        Me.User_Name.Name = "User_Name"
        '
        'User_Pass
        '
        Me.User_Pass.HeaderText = "كلمة المرور"
        Me.User_Pass.Name = "User_Pass"
        '
        'User_Email
        '
        Me.User_Email.HeaderText = "الأيميل"
        Me.User_Email.Name = "User_Email"
        '
        'Adjective
        '
        Me.Adjective.HeaderText = "الصفة"
        Me.Adjective.Name = "Adjective"
        '
        'TabPage16
        '
        Me.TabPage16.BackColor = System.Drawing.Color.Gainsboro
        Me.TabPage16.Controls.Add(Me.GroupBox11)
        Me.TabPage16.Controls.Add(Me.GroupBox10)
        Me.TabPage16.Controls.Add(Me.GroupBox9)
        Me.TabPage16.Controls.Add(Me.GroupBox8)
        Me.TabPage16.Controls.Add(Me.GroupBox7)
        Me.TabPage16.Controls.Add(Me.GroupBox6)
        Me.TabPage16.Controls.Add(Me.GroupBox5)
        Me.TabPage16.Location = New System.Drawing.Point(4, 26)
        Me.TabPage16.Name = "TabPage16"
        Me.TabPage16.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage16.Size = New System.Drawing.Size(1221, 754)
        Me.TabPage16.TabIndex = 1
        Me.TabPage16.Text = "معلومات"
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.dgvS)
        Me.GroupBox11.Controls.Add(Me.Button51)
        Me.GroupBox11.Controls.Add(Me.Button52)
        Me.GroupBox11.Location = New System.Drawing.Point(723, 366)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(222, 326)
        Me.GroupBox11.TabIndex = 14
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "التخصصات"
        '
        'dgvS
        '
        Me.dgvS.AllowUserToAddRows = False
        Me.dgvS.AllowUserToDeleteRows = False
        Me.dgvS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvS.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12})
        Me.dgvS.Location = New System.Drawing.Point(6, 27)
        Me.dgvS.Margin = New System.Windows.Forms.Padding(10)
        Me.dgvS.Name = "dgvS"
        Me.dgvS.ReadOnly = True
        Me.dgvS.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.dgvS.RowHeadersVisible = False
        Me.dgvS.Size = New System.Drawing.Size(203, 241)
        Me.dgvS.TabIndex = 10
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "Spec_id"
        Me.DataGridViewTextBoxColumn11.FillWeight = 150.0!
        Me.DataGridViewTextBoxColumn11.HeaderText = "رقم التخصص"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "Spec_n"
        Me.DataGridViewTextBoxColumn12.HeaderText = "التخصص"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        '
        'Button51
        '
        Me.Button51.BackColor = System.Drawing.Color.White
        Me.Button51.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button51.Location = New System.Drawing.Point(125, 284)
        Me.Button51.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button51.Name = "Button51"
        Me.Button51.Size = New System.Drawing.Size(78, 33)
        Me.Button51.TabIndex = 8
        Me.Button51.Text = "تعديل"
        Me.Button51.UseVisualStyleBackColor = False
        '
        'Button52
        '
        Me.Button52.BackColor = System.Drawing.Color.White
        Me.Button52.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button52.Location = New System.Drawing.Point(43, 284)
        Me.Button52.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button52.Name = "Button52"
        Me.Button52.Size = New System.Drawing.Size(72, 33)
        Me.Button52.TabIndex = 7
        Me.Button52.Text = "اضافة"
        Me.Button52.UseVisualStyleBackColor = False
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.dgvD)
        Me.GroupBox10.Controls.Add(Me.Button49)
        Me.GroupBox10.Controls.Add(Me.Button50)
        Me.GroupBox10.Location = New System.Drawing.Point(957, 369)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(222, 323)
        Me.GroupBox10.TabIndex = 14
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "الدرجات"
        '
        'dgvD
        '
        Me.dgvD.AllowUserToAddRows = False
        Me.dgvD.AllowUserToDeleteRows = False
        Me.dgvD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvD.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10})
        Me.dgvD.Location = New System.Drawing.Point(5, 24)
        Me.dgvD.Margin = New System.Windows.Forms.Padding(10)
        Me.dgvD.Name = "dgvD"
        Me.dgvD.ReadOnly = True
        Me.dgvD.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.dgvD.RowHeadersVisible = False
        Me.dgvD.Size = New System.Drawing.Size(203, 241)
        Me.dgvD.TabIndex = 10
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "Deg_id"
        Me.DataGridViewTextBoxColumn9.FillWeight = 150.0!
        Me.DataGridViewTextBoxColumn9.HeaderText = "رقم الدرجة"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "Deg_n"
        Me.DataGridViewTextBoxColumn10.HeaderText = "الدرجة"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        '
        'Button49
        '
        Me.Button49.BackColor = System.Drawing.Color.White
        Me.Button49.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button49.Location = New System.Drawing.Point(130, 281)
        Me.Button49.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button49.Name = "Button49"
        Me.Button49.Size = New System.Drawing.Size(78, 33)
        Me.Button49.TabIndex = 8
        Me.Button49.Text = "تعديل"
        Me.Button49.UseVisualStyleBackColor = False
        '
        'Button50
        '
        Me.Button50.BackColor = System.Drawing.Color.White
        Me.Button50.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button50.Location = New System.Drawing.Point(30, 281)
        Me.Button50.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button50.Name = "Button50"
        Me.Button50.Size = New System.Drawing.Size(72, 33)
        Me.Button50.TabIndex = 7
        Me.Button50.Text = "اضافة"
        Me.Button50.UseVisualStyleBackColor = False
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.dgvLJ)
        Me.GroupBox9.Controls.Add(Me.Button47)
        Me.GroupBox9.Controls.Add(Me.Button48)
        Me.GroupBox9.Location = New System.Drawing.Point(18, 6)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(222, 357)
        Me.GroupBox9.TabIndex = 13
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "المستوي الوظيفي"
        '
        'dgvLJ
        '
        Me.dgvLJ.AllowUserToAddRows = False
        Me.dgvLJ.AllowUserToDeleteRows = False
        Me.dgvLJ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvLJ.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8})
        Me.dgvLJ.Location = New System.Drawing.Point(6, 30)
        Me.dgvLJ.Margin = New System.Windows.Forms.Padding(10)
        Me.dgvLJ.Name = "dgvLJ"
        Me.dgvLJ.ReadOnly = True
        Me.dgvLJ.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.dgvLJ.RowHeadersVisible = False
        Me.dgvLJ.Size = New System.Drawing.Size(203, 276)
        Me.dgvLJ.TabIndex = 10
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "Job_level_id"
        Me.DataGridViewTextBoxColumn7.FillWeight = 150.0!
        Me.DataGridViewTextBoxColumn7.HeaderText = "رقم المستوي الوظيفي"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "Job_level"
        Me.DataGridViewTextBoxColumn8.HeaderText = "المستوي الوظيفي"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        '
        'Button47
        '
        Me.Button47.BackColor = System.Drawing.Color.White
        Me.Button47.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button47.Location = New System.Drawing.Point(108, 322)
        Me.Button47.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button47.Name = "Button47"
        Me.Button47.Size = New System.Drawing.Size(78, 33)
        Me.Button47.TabIndex = 8
        Me.Button47.Text = "تعديل"
        Me.Button47.UseVisualStyleBackColor = False
        '
        'Button48
        '
        Me.Button48.BackColor = System.Drawing.Color.White
        Me.Button48.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button48.Location = New System.Drawing.Point(26, 322)
        Me.Button48.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button48.Name = "Button48"
        Me.Button48.Size = New System.Drawing.Size(72, 33)
        Me.Button48.TabIndex = 7
        Me.Button48.Text = "اضافة"
        Me.Button48.UseVisualStyleBackColor = False
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.dgvJ)
        Me.GroupBox8.Controls.Add(Me.Button45)
        Me.GroupBox8.Controls.Add(Me.Button46)
        Me.GroupBox8.Location = New System.Drawing.Point(247, 6)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(222, 380)
        Me.GroupBox8.TabIndex = 12
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "الوظائف"
        '
        'dgvJ
        '
        Me.dgvJ.AllowUserToAddRows = False
        Me.dgvJ.AllowUserToDeleteRows = False
        Me.dgvJ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvJ.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6})
        Me.dgvJ.Location = New System.Drawing.Point(6, 30)
        Me.dgvJ.Margin = New System.Windows.Forms.Padding(10)
        Me.dgvJ.Name = "dgvJ"
        Me.dgvJ.ReadOnly = True
        Me.dgvJ.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.dgvJ.RowHeadersVisible = False
        Me.dgvJ.Size = New System.Drawing.Size(203, 278)
        Me.dgvJ.TabIndex = 10
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Job_id"
        Me.DataGridViewTextBoxColumn5.FillWeight = 150.0!
        Me.DataGridViewTextBoxColumn5.HeaderText = "رقم الوظيفة"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "Job_n"
        Me.DataGridViewTextBoxColumn6.HeaderText = "اسم الوظيفة"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        '
        'Button45
        '
        Me.Button45.BackColor = System.Drawing.Color.White
        Me.Button45.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button45.Location = New System.Drawing.Point(133, 324)
        Me.Button45.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(78, 33)
        Me.Button45.TabIndex = 8
        Me.Button45.Text = "تعديل"
        Me.Button45.UseVisualStyleBackColor = False
        '
        'Button46
        '
        Me.Button46.BackColor = System.Drawing.Color.White
        Me.Button46.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button46.Location = New System.Drawing.Point(33, 324)
        Me.Button46.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(72, 33)
        Me.Button46.TabIndex = 7
        Me.Button46.Text = "اضافة"
        Me.Button46.UseVisualStyleBackColor = False
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.dgvTH)
        Me.GroupBox7.Controls.Add(Me.Button43)
        Me.GroupBox7.Controls.Add(Me.Button44)
        Me.GroupBox7.Location = New System.Drawing.Point(476, 6)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(222, 380)
        Me.GroupBox7.TabIndex = 11
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "الاجازات"
        '
        'dgvTH
        '
        Me.dgvTH.AllowUserToAddRows = False
        Me.dgvTH.AllowUserToDeleteRows = False
        Me.dgvTH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvTH.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4})
        Me.dgvTH.Location = New System.Drawing.Point(6, 30)
        Me.dgvTH.Margin = New System.Windows.Forms.Padding(10)
        Me.dgvTH.Name = "dgvTH"
        Me.dgvTH.ReadOnly = True
        Me.dgvTH.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.dgvTH.RowHeadersVisible = False
        Me.dgvTH.Size = New System.Drawing.Size(203, 278)
        Me.dgvTH.TabIndex = 10
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "H_Id"
        Me.DataGridViewTextBoxColumn3.FillWeight = 150.0!
        Me.DataGridViewTextBoxColumn3.HeaderText = "رقم الاجازة"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "H_type"
        Me.DataGridViewTextBoxColumn4.HeaderText = "نوع الاجازة"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        '
        'Button43
        '
        Me.Button43.BackColor = System.Drawing.Color.White
        Me.Button43.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button43.Location = New System.Drawing.Point(133, 324)
        Me.Button43.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(78, 33)
        Me.Button43.TabIndex = 8
        Me.Button43.Text = "تعديل"
        Me.Button43.UseVisualStyleBackColor = False
        '
        'Button44
        '
        Me.Button44.BackColor = System.Drawing.Color.White
        Me.Button44.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button44.Location = New System.Drawing.Point(33, 324)
        Me.Button44.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(72, 33)
        Me.Button44.TabIndex = 7
        Me.Button44.Text = "اضافة"
        Me.Button44.UseVisualStyleBackColor = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.dgvQl)
        Me.GroupBox6.Controls.Add(Me.Button41)
        Me.GroupBox6.Controls.Add(Me.Button42)
        Me.GroupBox6.Location = New System.Drawing.Point(715, 6)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(222, 380)
        Me.GroupBox6.TabIndex = 9
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "المؤهلات"
        '
        'dgvQl
        '
        Me.dgvQl.AllowUserToAddRows = False
        Me.dgvQl.AllowUserToDeleteRows = False
        Me.dgvQl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvQl.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2})
        Me.dgvQl.Location = New System.Drawing.Point(10, 30)
        Me.dgvQl.Margin = New System.Windows.Forms.Padding(7, 8, 7, 8)
        Me.dgvQl.Name = "dgvQl"
        Me.dgvQl.ReadOnly = True
        Me.dgvQl.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.dgvQl.RowHeadersVisible = False
        Me.dgvQl.Size = New System.Drawing.Size(204, 280)
        Me.dgvQl.TabIndex = 10
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "Qual_Id"
        Me.DataGridViewTextBoxColumn1.FillWeight = 150.0!
        Me.DataGridViewTextBoxColumn1.HeaderText = "رقم المؤهل"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Qual_name"
        Me.DataGridViewTextBoxColumn2.HeaderText = "اسم المؤهل"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        '
        'Button41
        '
        Me.Button41.BackColor = System.Drawing.Color.White
        Me.Button41.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button41.Location = New System.Drawing.Point(133, 324)
        Me.Button41.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(78, 33)
        Me.Button41.TabIndex = 8
        Me.Button41.Text = "تعديل"
        Me.Button41.UseVisualStyleBackColor = False
        '
        'Button42
        '
        Me.Button42.BackColor = System.Drawing.Color.White
        Me.Button42.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button42.Location = New System.Drawing.Point(33, 324)
        Me.Button42.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(72, 33)
        Me.Button42.TabIndex = 7
        Me.Button42.Text = "اضافة"
        Me.Button42.UseVisualStyleBackColor = False
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Button39)
        Me.GroupBox5.Controls.Add(Me.Button40)
        Me.GroupBox5.Controls.Add(Me.dgvPl)
        Me.GroupBox5.Location = New System.Drawing.Point(954, 6)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(222, 380)
        Me.GroupBox5.TabIndex = 0
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "الاماكن"
        '
        'Button39
        '
        Me.Button39.BackColor = System.Drawing.Color.White
        Me.Button39.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button39.Location = New System.Drawing.Point(133, 324)
        Me.Button39.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(78, 33)
        Me.Button39.TabIndex = 8
        Me.Button39.Text = "تعديل"
        Me.Button39.UseVisualStyleBackColor = False
        '
        'Button40
        '
        Me.Button40.BackColor = System.Drawing.Color.White
        Me.Button40.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button40.Location = New System.Drawing.Point(33, 324)
        Me.Button40.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(72, 33)
        Me.Button40.TabIndex = 7
        Me.Button40.Text = "اضافة"
        Me.Button40.UseVisualStyleBackColor = False
        '
        'dgvPl
        '
        Me.dgvPl.AllowUserToAddRows = False
        Me.dgvPl.AllowUserToDeleteRows = False
        Me.dgvPl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvPl.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2})
        Me.dgvPl.Location = New System.Drawing.Point(8, 30)
        Me.dgvPl.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.dgvPl.Name = "dgvPl"
        Me.dgvPl.ReadOnly = True
        Me.dgvPl.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.dgvPl.RowHeadersVisible = False
        Me.dgvPl.Size = New System.Drawing.Size(203, 282)
        Me.dgvPl.TabIndex = 6
        '
        'Column1
        '
        Me.Column1.DataPropertyName = "Place_Id"
        Me.Column1.FillWeight = 150.0!
        Me.Column1.HeaderText = "رقم المكان"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'Column2
        '
        Me.Column2.DataPropertyName = "Place_N"
        Me.Column2.HeaderText = "اسم المكان"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.TabControl5)
        Me.TabPage5.Location = New System.Drawing.Point(4, 26)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1235, 813)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "الدورات"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'TabControl5
        '
        Me.TabControl5.Controls.Add(Me.TabPage13)
        Me.TabControl5.Controls.Add(Me.TabPage14)
        Me.TabControl5.Location = New System.Drawing.Point(6, 6)
        Me.TabControl5.Name = "TabControl5"
        Me.TabControl5.RightToLeftLayout = True
        Me.TabControl5.SelectedIndex = 0
        Me.TabControl5.Size = New System.Drawing.Size(1223, 775)
        Me.TabControl5.TabIndex = 0
        '
        'TabPage13
        '
        Me.TabPage13.Controls.Add(Me.Button23)
        Me.TabPage13.Controls.Add(Me.Panel8)
        Me.TabPage13.Controls.Add(Me.Button26)
        Me.TabPage13.Controls.Add(Me.Button27)
        Me.TabPage13.Controls.Add(Me.Label91)
        Me.TabPage13.Controls.Add(Me.txt_C)
        Me.TabPage13.Controls.Add(Me.dgvCourses)
        Me.TabPage13.Location = New System.Drawing.Point(4, 26)
        Me.TabPage13.Name = "TabPage13"
        Me.TabPage13.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage13.Size = New System.Drawing.Size(1215, 745)
        Me.TabPage13.TabIndex = 0
        Me.TabPage13.Text = "الدورات"
        Me.TabPage13.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(450, 199)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(116, 36)
        Me.Button23.TabIndex = 19
        Me.Button23.Text = "الغاء"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel8.Controls.Add(Me.TextBox34)
        Me.Panel8.Controls.Add(Me.Label96)
        Me.Panel8.Controls.Add(Me.Label93)
        Me.Panel8.Controls.Add(Me.DateTimePicker14)
        Me.Panel8.Controls.Add(Me.TextBox33)
        Me.Panel8.Controls.Add(Me.Label95)
        Me.Panel8.Controls.Add(Me.Label92)
        Me.Panel8.Controls.Add(Me.DateTimePicker13)
        Me.Panel8.Controls.Add(Me.Button24)
        Me.Panel8.Controls.Add(Me.Button25)
        Me.Panel8.Controls.Add(Me.TextBox32)
        Me.Panel8.Controls.Add(Me.Label94)
        Me.Panel8.Location = New System.Drawing.Point(19, 10)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(1155, 183)
        Me.Panel8.TabIndex = 18
        '
        'TextBox34
        '
        Me.TextBox34.BackColor = System.Drawing.Color.White
        Me.TextBox34.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox34.Location = New System.Drawing.Point(157, 71)
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.ReadOnly = True
        Me.TextBox34.Size = New System.Drawing.Size(167, 29)
        Me.TextBox34.TabIndex = 19
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label96.Location = New System.Drawing.Point(330, 74)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(76, 22)
        Me.Label96.TabIndex = 18
        Me.Label96.Text = "مدة الدورة"
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label93.Location = New System.Drawing.Point(658, 74)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(93, 22)
        Me.Label93.TabIndex = 17
        Me.Label93.Text = "تاريخ الانتهاء"
        '
        'DateTimePicker14
        '
        Me.DateTimePicker14.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker14.Location = New System.Drawing.Point(452, 67)
        Me.DateTimePicker14.Name = "DateTimePicker14"
        Me.DateTimePicker14.Size = New System.Drawing.Size(200, 29)
        Me.DateTimePicker14.TabIndex = 16
        '
        'TextBox33
        '
        Me.TextBox33.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox33.Location = New System.Drawing.Point(157, 9)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(349, 29)
        Me.TextBox33.TabIndex = 15
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label95.Location = New System.Drawing.Point(512, 12)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(81, 22)
        Me.Label95.TabIndex = 14
        Me.Label95.Text = "اسم المدرب"
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label92.Location = New System.Drawing.Point(1014, 74)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(90, 22)
        Me.Label92.TabIndex = 13
        Me.Label92.Text = "تاريخ الانعقاد"
        '
        'DateTimePicker13
        '
        Me.DateTimePicker13.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker13.Location = New System.Drawing.Point(806, 67)
        Me.DateTimePicker13.Name = "DateTimePicker13"
        Me.DateTimePicker13.Size = New System.Drawing.Size(200, 29)
        Me.DateTimePicker13.TabIndex = 12
        '
        'Button24
        '
        Me.Button24.BackColor = System.Drawing.Color.White
        Me.Button24.Location = New System.Drawing.Point(481, 129)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(116, 36)
        Me.Button24.TabIndex = 9
        Me.Button24.Text = "الغاء"
        Me.Button24.UseVisualStyleBackColor = False
        '
        'Button25
        '
        Me.Button25.BackColor = System.Drawing.Color.White
        Me.Button25.Location = New System.Drawing.Point(615, 129)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(116, 36)
        Me.Button25.TabIndex = 9
        Me.Button25.Text = "حفظ"
        Me.Button25.UseVisualStyleBackColor = False
        '
        'TextBox32
        '
        Me.TextBox32.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox32.Location = New System.Drawing.Point(679, 14)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(349, 29)
        Me.TextBox32.TabIndex = 1
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label94.Location = New System.Drawing.Point(1034, 17)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(77, 22)
        Me.Label94.TabIndex = 0
        Me.Label94.Text = "اسم الدورة"
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(572, 199)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(116, 36)
        Me.Button26.TabIndex = 17
        Me.Button26.Text = "تعديل"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(694, 199)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(116, 36)
        Me.Button27.TabIndex = 16
        Me.Button27.Text = "انشاء دورة"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Label91
        '
        Me.Label91.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label91.Location = New System.Drawing.Point(803, 248)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(76, 34)
        Me.Label91.TabIndex = 6
        Me.Label91.Text = "بحث :"
        Me.Label91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_C
        '
        Me.txt_C.Location = New System.Drawing.Point(402, 254)
        Me.txt_C.Name = "txt_C"
        Me.txt_C.Size = New System.Drawing.Size(395, 24)
        Me.txt_C.TabIndex = 7
        Me.txt_C.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'dgvCourses
        '
        Me.dgvCourses.AllowUserToAddRows = False
        Me.dgvCourses.AllowUserToDeleteRows = False
        Me.dgvCourses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvCourses.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Cours_Id, Me.Cours_Name, Me.M_Name, Me.Cours_Start, Me.Cours_End, Me.Period})
        Me.dgvCourses.Location = New System.Drawing.Point(14, 290)
        Me.dgvCourses.Name = "dgvCourses"
        Me.dgvCourses.ReadOnly = True
        Me.dgvCourses.RowTemplate.Height = 26
        Me.dgvCourses.Size = New System.Drawing.Size(1161, 393)
        Me.dgvCourses.TabIndex = 5
        '
        'Cours_Id
        '
        Me.Cours_Id.DataPropertyName = "Cours_Id"
        Me.Cours_Id.HeaderText = "رقم الدورة"
        Me.Cours_Id.Name = "Cours_Id"
        Me.Cours_Id.ReadOnly = True
        '
        'Cours_Name
        '
        Me.Cours_Name.DataPropertyName = "Cours_Name"
        Me.Cours_Name.HeaderText = "اسم الدورة"
        Me.Cours_Name.Name = "Cours_Name"
        Me.Cours_Name.ReadOnly = True
        '
        'M_Name
        '
        Me.M_Name.DataPropertyName = "M_Name"
        Me.M_Name.HeaderText = "اسم المدرب"
        Me.M_Name.Name = "M_Name"
        Me.M_Name.ReadOnly = True
        '
        'Cours_Start
        '
        Me.Cours_Start.DataPropertyName = "Cours_Start"
        Me.Cours_Start.HeaderText = "تاريخ الانعقاد"
        Me.Cours_Start.Name = "Cours_Start"
        Me.Cours_Start.ReadOnly = True
        '
        'Cours_End
        '
        Me.Cours_End.DataPropertyName = "Cours_End "
        Me.Cours_End.HeaderText = "تاريخ الانهاء"
        Me.Cours_End.Name = "Cours_End"
        Me.Cours_End.ReadOnly = True
        '
        'Period
        '
        Me.Period.DataPropertyName = "Period"
        Me.Period.HeaderText = "مدة الدورة"
        Me.Period.Name = "Period"
        Me.Period.ReadOnly = True
        '
        'TabPage14
        '
        Me.TabPage14.Controls.Add(Me.Button28)
        Me.TabPage14.Controls.Add(Me.Panel9)
        Me.TabPage14.Controls.Add(Me.Button31)
        Me.TabPage14.Controls.Add(Me.Button32)
        Me.TabPage14.Controls.Add(Me.Label97)
        Me.TabPage14.Controls.Add(Me.txt_T)
        Me.TabPage14.Controls.Add(Me.DataGridView7)
        Me.TabPage14.Location = New System.Drawing.Point(4, 26)
        Me.TabPage14.Name = "TabPage14"
        Me.TabPage14.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage14.Size = New System.Drawing.Size(1215, 745)
        Me.TabPage14.TabIndex = 1
        Me.TabPage14.Text = "المتدربون"
        Me.TabPage14.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Location = New System.Drawing.Point(430, 218)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(116, 36)
        Me.Button28.TabIndex = 19
        Me.Button28.Text = "الغاء"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel9.Controls.Add(Me.TextBox37)
        Me.Panel9.Controls.Add(Me.Label101)
        Me.Panel9.Controls.Add(Me.Label99)
        Me.Panel9.Controls.Add(Me.ComboBox24)
        Me.Panel9.Controls.Add(Me.Button29)
        Me.Panel9.Controls.Add(Me.Button30)
        Me.Panel9.Controls.Add(Me.TextBox36)
        Me.Panel9.Controls.Add(Me.Label100)
        Me.Panel9.Location = New System.Drawing.Point(15, 20)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(1161, 183)
        Me.Panel9.TabIndex = 18
        '
        'TextBox37
        '
        Me.TextBox37.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox37.Location = New System.Drawing.Point(102, 22)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(389, 29)
        Me.TextBox37.TabIndex = 15
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label101.Location = New System.Drawing.Point(497, 25)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(87, 22)
        Me.Label101.TabIndex = 14
        Me.Label101.Text = "اسم الموظف"
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label99.Location = New System.Drawing.Point(646, 84)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(77, 22)
        Me.Label99.TabIndex = 11
        Me.Label99.Text = "اسم الدورة"
        '
        'ComboBox24
        '
        Me.ComboBox24.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox24.FormattingEnabled = True
        Me.ComboBox24.Location = New System.Drawing.Point(461, 81)
        Me.ComboBox24.Name = "ComboBox24"
        Me.ComboBox24.Size = New System.Drawing.Size(179, 28)
        Me.ComboBox24.TabIndex = 10
        '
        'Button29
        '
        Me.Button29.BackColor = System.Drawing.Color.White
        Me.Button29.Location = New System.Drawing.Point(481, 129)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(116, 36)
        Me.Button29.TabIndex = 9
        Me.Button29.Text = "الغاء"
        Me.Button29.UseVisualStyleBackColor = False
        '
        'Button30
        '
        Me.Button30.BackColor = System.Drawing.Color.White
        Me.Button30.Location = New System.Drawing.Point(615, 129)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(116, 36)
        Me.Button30.TabIndex = 9
        Me.Button30.Text = "حفظ"
        Me.Button30.UseVisualStyleBackColor = False
        '
        'TextBox36
        '
        Me.TextBox36.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox36.Location = New System.Drawing.Point(642, 22)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(215, 29)
        Me.TextBox36.TabIndex = 1
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label100.Location = New System.Drawing.Point(863, 25)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(85, 22)
        Me.Label100.TabIndex = 0
        Me.Label100.Text = "رقم الموظف"
        '
        'Button31
        '
        Me.Button31.Location = New System.Drawing.Point(552, 218)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(116, 36)
        Me.Button31.TabIndex = 17
        Me.Button31.Text = "تعديل"
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.Location = New System.Drawing.Point(674, 218)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(116, 36)
        Me.Button32.TabIndex = 16
        Me.Button32.Text = "اضافة متدرب"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Label97
        '
        Me.Label97.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label97.Location = New System.Drawing.Point(748, 274)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(76, 35)
        Me.Label97.TabIndex = 9
        Me.Label97.Text = "بحث :"
        Me.Label97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_T
        '
        Me.txt_T.Location = New System.Drawing.Point(351, 280)
        Me.txt_T.Name = "txt_T"
        Me.txt_T.Size = New System.Drawing.Size(395, 24)
        Me.txt_T.TabIndex = 10
        Me.txt_T.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'DataGridView7
        '
        Me.DataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView7.Location = New System.Drawing.Point(10, 313)
        Me.DataGridView7.Name = "DataGridView7"
        Me.DataGridView7.RowTemplate.Height = 26
        Me.DataGridView7.Size = New System.Drawing.Size(1161, 370)
        Me.DataGridView7.TabIndex = 8
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.TabControl4)
        Me.TabPage3.Location = New System.Drawing.Point(4, 26)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1235, 813)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "الادارات والاقسام"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TabControl4
        '
        Me.TabControl4.Controls.Add(Me.TabPage1)
        Me.TabControl4.Controls.Add(Me.TabPage4)
        Me.TabControl4.Controls.Add(Me.TabPage18)
        Me.TabControl4.Location = New System.Drawing.Point(6, 6)
        Me.TabControl4.Name = "TabControl4"
        Me.TabControl4.RightToLeftLayout = True
        Me.TabControl4.SelectedIndex = 0
        Me.TabControl4.Size = New System.Drawing.Size(1219, 784)
        Me.TabControl4.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Button15)
        Me.TabPage1.Controls.Add(Me.dgv_Mang)
        Me.TabPage1.Controls.Add(Me.Panal_Mang)
        Me.TabPage1.Controls.Add(Me.Button14)
        Me.TabPage1.Controls.Add(Me.Button13)
        Me.TabPage1.Controls.Add(Me.Label85)
        Me.TabPage1.Controls.Add(Me.txt_mang)
        Me.TabPage1.Location = New System.Drawing.Point(4, 26)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1211, 754)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "الادارات"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(435, 252)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(116, 36)
        Me.Button15.TabIndex = 8
        Me.Button15.Text = "الغاء"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'dgv_Mang
        '
        Me.dgv_Mang.AllowUserToAddRows = False
        Me.dgv_Mang.AllowUserToDeleteRows = False
        Me.dgv_Mang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_Mang.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Mang_Id_D, Me.Mang_Name_D})
        Me.dgv_Mang.Location = New System.Drawing.Point(374, 373)
        Me.dgv_Mang.Name = "dgv_Mang"
        Me.dgv_Mang.ReadOnly = True
        Me.dgv_Mang.RowTemplate.Height = 26
        Me.dgv_Mang.Size = New System.Drawing.Size(463, 373)
        Me.dgv_Mang.TabIndex = 0
        '
        'Mang_Id_D
        '
        Me.Mang_Id_D.DataPropertyName = "Mang_Id"
        Me.Mang_Id_D.HeaderText = "رقم الادارة"
        Me.Mang_Id_D.Name = "Mang_Id_D"
        Me.Mang_Id_D.ReadOnly = True
        '
        'Mang_Name_D
        '
        Me.Mang_Name_D.DataPropertyName = "Mang_Name"
        Me.Mang_Name_D.HeaderText = "اسم الادارة"
        Me.Mang_Name_D.Name = "Mang_Name_D"
        Me.Mang_Name_D.ReadOnly = True
        '
        'Panal_Mang
        '
        Me.Panal_Mang.BackColor = System.Drawing.Color.Gainsboro
        Me.Panal_Mang.Controls.Add(Me.txt_Mane_Id_A)
        Me.Panal_Mang.Controls.Add(Me.Label16)
        Me.Panal_Mang.Controls.Add(Me.Button17)
        Me.Panal_Mang.Controls.Add(Me.Button16)
        Me.Panal_Mang.Controls.Add(Me.txt_Name_Mang)
        Me.Panal_Mang.Controls.Add(Me.Label86)
        Me.Panal_Mang.Location = New System.Drawing.Point(119, 40)
        Me.Panal_Mang.Name = "Panal_Mang"
        Me.Panal_Mang.Size = New System.Drawing.Size(918, 183)
        Me.Panal_Mang.TabIndex = 7
        '
        'txt_Mane_Id_A
        '
        Me.txt_Mane_Id_A.BackColor = System.Drawing.Color.White
        Me.txt_Mane_Id_A.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Mane_Id_A.Location = New System.Drawing.Point(537, 55)
        Me.txt_Mane_Id_A.Name = "txt_Mane_Id_A"
        Me.txt_Mane_Id_A.ReadOnly = True
        Me.txt_Mane_Id_A.Size = New System.Drawing.Size(200, 29)
        Me.txt_Mane_Id_A.TabIndex = 17
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(743, 58)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(80, 22)
        Me.Label16.TabIndex = 16
        Me.Label16.Text = "رقم الادارة:"
        '
        'Button17
        '
        Me.Button17.BackColor = System.Drawing.Color.White
        Me.Button17.Location = New System.Drawing.Point(460, 124)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(116, 36)
        Me.Button17.TabIndex = 9
        Me.Button17.Text = "الغاء"
        Me.Button17.UseVisualStyleBackColor = False
        '
        'Button16
        '
        Me.Button16.BackColor = System.Drawing.Color.White
        Me.Button16.Location = New System.Drawing.Point(316, 124)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(116, 36)
        Me.Button16.TabIndex = 9
        Me.Button16.Text = "حفظ"
        Me.Button16.UseVisualStyleBackColor = False
        '
        'txt_Name_Mang
        '
        Me.txt_Name_Mang.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Name_Mang.Location = New System.Drawing.Point(36, 55)
        Me.txt_Name_Mang.Name = "txt_Name_Mang"
        Me.txt_Name_Mang.Size = New System.Drawing.Size(349, 29)
        Me.txt_Name_Mang.TabIndex = 1
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label86.Location = New System.Drawing.Point(391, 58)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(82, 22)
        Me.Label86.TabIndex = 0
        Me.Label86.Text = "اسم الادارة:"
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(557, 252)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(116, 36)
        Me.Button14.TabIndex = 6
        Me.Button14.Text = "تعديل"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(679, 252)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(116, 36)
        Me.Button13.TabIndex = 5
        Me.Button13.Text = "اضافة ادارة "
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Label85
        '
        Me.Label85.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.Location = New System.Drawing.Point(729, 318)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(76, 35)
        Me.Label85.TabIndex = 3
        Me.Label85.Text = "بحث :"
        Me.Label85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_mang
        '
        Me.txt_mang.Location = New System.Drawing.Point(435, 325)
        Me.txt_mang.Name = "txt_mang"
        Me.txt_mang.Size = New System.Drawing.Size(292, 24)
        Me.txt_mang.TabIndex = 4
        Me.txt_mang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Button18)
        Me.TabPage4.Controls.Add(Me.panal_Dep)
        Me.TabPage4.Controls.Add(Me.Button21)
        Me.TabPage4.Controls.Add(Me.Button22)
        Me.TabPage4.Controls.Add(Me.Label88)
        Me.TabPage4.Controls.Add(Me.txt_dep)
        Me.TabPage4.Controls.Add(Me.dgvDep)
        Me.TabPage4.Location = New System.Drawing.Point(4, 26)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1211, 754)
        Me.TabPage4.TabIndex = 1
        Me.TabPage4.Text = "الاقسام"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(459, 222)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(116, 36)
        Me.Button18.TabIndex = 15
        Me.Button18.Text = "الغاء"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'panal_Dep
        '
        Me.panal_Dep.BackColor = System.Drawing.Color.Gainsboro
        Me.panal_Dep.Controls.Add(Me.txt_Dep_Id_A)
        Me.panal_Dep.Controls.Add(Me.Label8)
        Me.panal_Dep.Controls.Add(Me.Label90)
        Me.panal_Dep.Controls.Add(Me.D_O_D)
        Me.panal_Dep.Controls.Add(Me.Label89)
        Me.panal_Dep.Controls.Add(Me.CM_M_To_D)
        Me.panal_Dep.Controls.Add(Me.Button19)
        Me.panal_Dep.Controls.Add(Me.Button20)
        Me.panal_Dep.Controls.Add(Me.txt_Name_Dep)
        Me.panal_Dep.Controls.Add(Me.Label87)
        Me.panal_Dep.Location = New System.Drawing.Point(23, 18)
        Me.panal_Dep.Name = "panal_Dep"
        Me.panal_Dep.Size = New System.Drawing.Size(1155, 183)
        Me.panal_Dep.TabIndex = 14
        '
        'txt_Dep_Id_A
        '
        Me.txt_Dep_Id_A.BackColor = System.Drawing.Color.White
        Me.txt_Dep_Id_A.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Dep_Id_A.Location = New System.Drawing.Point(674, 21)
        Me.txt_Dep_Id_A.Name = "txt_Dep_Id_A"
        Me.txt_Dep_Id_A.ReadOnly = True
        Me.txt_Dep_Id_A.Size = New System.Drawing.Size(200, 29)
        Me.txt_Dep_Id_A.TabIndex = 15
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(880, 24)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(74, 22)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "رقم القسم:"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label90.Location = New System.Drawing.Point(813, 85)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(125, 22)
        Me.Label90.TabIndex = 13
        Me.Label90.Text = "تاريخ انشاء القسم:"
        '
        'D_O_D
        '
        Me.D_O_D.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.D_O_D.Location = New System.Drawing.Point(607, 78)
        Me.D_O_D.Name = "D_O_D"
        Me.D_O_D.Size = New System.Drawing.Size(200, 29)
        Me.D_O_D.TabIndex = 12
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label89.Location = New System.Drawing.Point(412, 85)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(112, 22)
        Me.Label89.TabIndex = 11
        Me.Label89.Text = "الادارة التابع لها:"
        '
        'CM_M_To_D
        '
        Me.CM_M_To_D.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CM_M_To_D.FormattingEnabled = True
        Me.CM_M_To_D.Location = New System.Drawing.Point(227, 82)
        Me.CM_M_To_D.Name = "CM_M_To_D"
        Me.CM_M_To_D.Size = New System.Drawing.Size(179, 28)
        Me.CM_M_To_D.TabIndex = 10
        '
        'Button19
        '
        Me.Button19.BackColor = System.Drawing.Color.White
        Me.Button19.Location = New System.Drawing.Point(599, 131)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(116, 36)
        Me.Button19.TabIndex = 9
        Me.Button19.Text = "الغاء"
        Me.Button19.UseVisualStyleBackColor = False
        '
        'Button20
        '
        Me.Button20.BackColor = System.Drawing.Color.White
        Me.Button20.Location = New System.Drawing.Point(447, 131)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(116, 36)
        Me.Button20.TabIndex = 9
        Me.Button20.Text = "حفظ"
        Me.Button20.UseVisualStyleBackColor = False
        '
        'txt_Name_Dep
        '
        Me.txt_Name_Dep.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Name_Dep.Location = New System.Drawing.Point(157, 21)
        Me.txt_Name_Dep.Name = "txt_Name_Dep"
        Me.txt_Name_Dep.Size = New System.Drawing.Size(349, 29)
        Me.txt_Name_Dep.TabIndex = 1
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label87.Location = New System.Drawing.Point(512, 27)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(76, 22)
        Me.Label87.TabIndex = 0
        Me.Label87.Text = "اسم القسم:"
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(581, 222)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(116, 36)
        Me.Button21.TabIndex = 13
        Me.Button21.Text = "تعديل"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(703, 222)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(116, 36)
        Me.Button22.TabIndex = 12
        Me.Button22.Text = "اضافة قسم"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Label88
        '
        Me.Label88.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label88.Location = New System.Drawing.Point(778, 279)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(76, 35)
        Me.Label88.TabIndex = 10
        Me.Label88.Text = "بحث :"
        Me.Label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_dep
        '
        Me.txt_dep.Location = New System.Drawing.Point(377, 285)
        Me.txt_dep.Name = "txt_dep"
        Me.txt_dep.Size = New System.Drawing.Size(395, 24)
        Me.txt_dep.TabIndex = 11
        Me.txt_dep.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'dgvDep
        '
        Me.dgvDep.AllowUserToAddRows = False
        Me.dgvDep.AllowUserToDeleteRows = False
        Me.dgvDep.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDep.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Dep_Id_D, Me.Dep_Name_D, Me.Dep_O_D, Me.Mang_Id_Dep})
        Me.dgvDep.Location = New System.Drawing.Point(180, 319)
        Me.dgvDep.Name = "dgvDep"
        Me.dgvDep.ReadOnly = True
        Me.dgvDep.RowTemplate.Height = 26
        Me.dgvDep.Size = New System.Drawing.Size(876, 395)
        Me.dgvDep.TabIndex = 9
        '
        'Dep_Id_D
        '
        Me.Dep_Id_D.DataPropertyName = "Dep_Id"
        Me.Dep_Id_D.HeaderText = "رقم القسم"
        Me.Dep_Id_D.Name = "Dep_Id_D"
        Me.Dep_Id_D.ReadOnly = True
        '
        'Dep_Name_D
        '
        Me.Dep_Name_D.DataPropertyName = "Dep_Name"
        Me.Dep_Name_D.HeaderText = "اسم القسم"
        Me.Dep_Name_D.Name = "Dep_Name_D"
        Me.Dep_Name_D.ReadOnly = True
        '
        'Dep_O_D
        '
        Me.Dep_O_D.DataPropertyName = "Dep_opening_date"
        Me.Dep_O_D.HeaderText = "ت/ فتح القسم"
        Me.Dep_O_D.Name = "Dep_O_D"
        Me.Dep_O_D.ReadOnly = True
        '
        'Mang_Id_Dep
        '
        Me.Mang_Id_Dep.DataPropertyName = "Mang_Id"
        Me.Mang_Id_Dep.HeaderText = "رقم الادارة"
        Me.Mang_Id_Dep.Name = "Mang_Id_Dep"
        Me.Mang_Id_Dep.ReadOnly = True
        '
        'TabPage18
        '
        Me.TabPage18.Location = New System.Drawing.Point(4, 26)
        Me.TabPage18.Name = "TabPage18"
        Me.TabPage18.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage18.Size = New System.Drawing.Size(1211, 754)
        Me.TabPage18.TabIndex = 2
        Me.TabPage18.Text = "رؤساء الاقسام"
        Me.TabPage18.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.TabControl3)
        Me.TabPage2.Location = New System.Drawing.Point(4, 26)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1235, 813)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "الاجازات"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'TabControl3
        '
        Me.TabControl3.Controls.Add(Me.TabPage10)
        Me.TabControl3.Controls.Add(Me.TabPage11)
        Me.TabControl3.Controls.Add(Me.TabPage12)
        Me.TabControl3.Location = New System.Drawing.Point(7, 6)
        Me.TabControl3.Name = "TabControl3"
        Me.TabControl3.RightToLeftLayout = True
        Me.TabControl3.SelectedIndex = 0
        Me.TabControl3.Size = New System.Drawing.Size(1218, 728)
        Me.TabControl3.TabIndex = 17
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.GroupBox1)
        Me.TabPage10.Controls.Add(Me.GroupBox2)
        Me.TabPage10.Location = New System.Drawing.Point(4, 26)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage10.Size = New System.Drawing.Size(1210, 698)
        Me.TabPage10.TabIndex = 0
        Me.TabPage10.Text = "طلب اجازة لموظف"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox1.Controls.Add(Me.txtEmp_name_H)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtEmp_id_H)
        Me.GroupBox1.Controls.Add(Me.txtDay_Emergency_H)
        Me.GroupBox1.Controls.Add(Me.txtDay_Annual_H)
        Me.GroupBox1.Location = New System.Drawing.Point(40, 8)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GroupBox1.Size = New System.Drawing.Size(1127, 173)
        Me.GroupBox1.TabIndex = 15
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "بيانات الموظف :"
        '
        'txtEmp_name_H
        '
        Me.txtEmp_name_H.BackColor = System.Drawing.Color.White
        Me.txtEmp_name_H.Location = New System.Drawing.Point(234, 46)
        Me.txtEmp_name_H.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtEmp_name_H.Name = "txtEmp_name_H"
        Me.txtEmp_name_H.ReadOnly = True
        Me.txtEmp_name_H.Size = New System.Drawing.Size(346, 24)
        Me.txtEmp_name_H.TabIndex = 30
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(588, 48)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(79, 17)
        Me.Label11.TabIndex = 29
        Me.Label11.Text = "اسم الموظف :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(868, 48)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(77, 17)
        Me.Label10.TabIndex = 7
        Me.Label10.Text = "رقم الموظف :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(828, 96)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(114, 17)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "ايام الاجازة السنوية :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(553, 96)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(112, 17)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "ايام الاجازة الطارئة :"
        '
        'txtEmp_id_H
        '
        Me.txtEmp_id_H.Location = New System.Drawing.Point(688, 46)
        Me.txtEmp_id_H.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtEmp_id_H.Name = "txtEmp_id_H"
        Me.txtEmp_id_H.Size = New System.Drawing.Size(134, 24)
        Me.txtEmp_id_H.TabIndex = 14
        '
        'txtDay_Emergency_H
        '
        Me.txtDay_Emergency_H.BackColor = System.Drawing.Color.White
        Me.txtDay_Emergency_H.Location = New System.Drawing.Point(417, 92)
        Me.txtDay_Emergency_H.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtDay_Emergency_H.Name = "txtDay_Emergency_H"
        Me.txtDay_Emergency_H.ReadOnly = True
        Me.txtDay_Emergency_H.Size = New System.Drawing.Size(134, 24)
        Me.txtDay_Emergency_H.TabIndex = 15
        '
        'txtDay_Annual_H
        '
        Me.txtDay_Annual_H.BackColor = System.Drawing.Color.White
        Me.txtDay_Annual_H.Location = New System.Drawing.Point(688, 92)
        Me.txtDay_Annual_H.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtDay_Annual_H.Name = "txtDay_Annual_H"
        Me.txtDay_Annual_H.ReadOnly = True
        Me.txtDay_Annual_H.Size = New System.Drawing.Size(134, 24)
        Me.txtDay_Annual_H.TabIndex = 15
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox2.Controls.Add(Me.L_D_H_A)
        Me.GroupBox2.Controls.Add(Me.CM_H_type_A)
        Me.GroupBox2.Controls.Add(Me.Button1)
        Me.GroupBox2.Controls.Add(Me.H_end_A)
        Me.GroupBox2.Controls.Add(Me.Button4)
        Me.GroupBox2.Controls.Add(Me.H_start_A)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Location = New System.Drawing.Point(40, 202)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GroupBox2.Size = New System.Drawing.Size(1127, 237)
        Me.GroupBox2.TabIndex = 16
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "معلومات الاجازة :"
        '
        'L_D_H_A
        '
        Me.L_D_H_A.AutoSize = True
        Me.L_D_H_A.Location = New System.Drawing.Point(454, 140)
        Me.L_D_H_A.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_D_H_A.Name = "L_D_H_A"
        Me.L_D_H_A.Size = New System.Drawing.Size(0, 17)
        Me.L_D_H_A.TabIndex = 29
        '
        'CM_H_type_A
        '
        Me.CM_H_type_A.FormattingEnabled = True
        Me.CM_H_type_A.Location = New System.Drawing.Point(424, 28)
        Me.CM_H_type_A.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.CM_H_type_A.Name = "CM_H_type_A"
        Me.CM_H_type_A.Size = New System.Drawing.Size(170, 25)
        Me.CM_H_type_A.TabIndex = 28
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(382, 182)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(112, 37)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "حفظ"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'H_end_A
        '
        Me.H_end_A.Location = New System.Drawing.Point(256, 79)
        Me.H_end_A.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.H_end_A.Name = "H_end_A"
        Me.H_end_A.Size = New System.Drawing.Size(172, 24)
        Me.H_end_A.TabIndex = 27
        Me.H_end_A.Value = New Date(2022, 6, 25, 0, 0, 0, 0)
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(532, 182)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(112, 37)
        Me.Button4.TabIndex = 14
        Me.Button4.Text = "الغاء الامر"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'H_start_A
        '
        Me.H_start_A.Location = New System.Drawing.Point(588, 79)
        Me.H_start_A.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.H_start_A.Name = "H_start_A"
        Me.H_start_A.Size = New System.Drawing.Size(188, 24)
        Me.H_start_A.TabIndex = 26
        Me.H_start_A.Value = New Date(2022, 6, 25, 0, 0, 0, 0)
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(605, 31)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 17)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "نوع الاجازة :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(436, 85)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(99, 17)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "ت/انتهاء الاجازة :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(783, 85)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 17)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "ت/بداية الاجازة :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(483, 140)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(59, 17)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "عدد الايام:"
        '
        'TabPage11
        '
        Me.TabPage11.Controls.Add(Me.GroupBox3)
        Me.TabPage11.Controls.Add(Me.GroupBox4)
        Me.TabPage11.Location = New System.Drawing.Point(4, 26)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage11.Size = New System.Drawing.Size(1210, 698)
        Me.TabPage11.TabIndex = 1
        Me.TabPage11.Text = "تعديل اجازة موظف"
        Me.TabPage11.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox3.Controls.Add(Me.txtEmp_name_E)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.txtEmp_id_E)
        Me.GroupBox3.Controls.Add(Me.txtDay_Emergency_E)
        Me.GroupBox3.Controls.Add(Me.txtDay_Annual_E)
        Me.GroupBox3.Location = New System.Drawing.Point(38, 20)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GroupBox3.Size = New System.Drawing.Size(1127, 173)
        Me.GroupBox3.TabIndex = 17
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "بيانات الموظف :"
        '
        'txtEmp_name_E
        '
        Me.txtEmp_name_E.BackColor = System.Drawing.Color.White
        Me.txtEmp_name_E.Location = New System.Drawing.Point(234, 46)
        Me.txtEmp_name_E.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtEmp_name_E.Name = "txtEmp_name_E"
        Me.txtEmp_name_E.ReadOnly = True
        Me.txtEmp_name_E.Size = New System.Drawing.Size(346, 24)
        Me.txtEmp_name_E.TabIndex = 30
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(588, 48)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(79, 17)
        Me.Label12.TabIndex = 29
        Me.Label12.Text = "اسم الموظف :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(868, 48)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(77, 17)
        Me.Label13.TabIndex = 7
        Me.Label13.Text = "رقم الموظف :"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(828, 96)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(114, 17)
        Me.Label14.TabIndex = 8
        Me.Label14.Text = "ايام الاجازة السنوية :"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(553, 96)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(112, 17)
        Me.Label15.TabIndex = 9
        Me.Label15.Text = "ايام الاجازة الطارئة :"
        '
        'txtEmp_id_E
        '
        Me.txtEmp_id_E.Location = New System.Drawing.Point(688, 46)
        Me.txtEmp_id_E.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtEmp_id_E.Name = "txtEmp_id_E"
        Me.txtEmp_id_E.Size = New System.Drawing.Size(134, 24)
        Me.txtEmp_id_E.TabIndex = 14
        '
        'txtDay_Emergency_E
        '
        Me.txtDay_Emergency_E.BackColor = System.Drawing.Color.White
        Me.txtDay_Emergency_E.Location = New System.Drawing.Point(418, 92)
        Me.txtDay_Emergency_E.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtDay_Emergency_E.Name = "txtDay_Emergency_E"
        Me.txtDay_Emergency_E.ReadOnly = True
        Me.txtDay_Emergency_E.Size = New System.Drawing.Size(134, 24)
        Me.txtDay_Emergency_E.TabIndex = 15
        '
        'txtDay_Annual_E
        '
        Me.txtDay_Annual_E.BackColor = System.Drawing.Color.White
        Me.txtDay_Annual_E.Location = New System.Drawing.Point(688, 92)
        Me.txtDay_Annual_E.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtDay_Annual_E.Name = "txtDay_Annual_E"
        Me.txtDay_Annual_E.ReadOnly = True
        Me.txtDay_Annual_E.Size = New System.Drawing.Size(134, 24)
        Me.txtDay_Annual_E.TabIndex = 15
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.Gainsboro
        Me.GroupBox4.Controls.Add(Me.L_D_H_E)
        Me.GroupBox4.Controls.Add(Me.CM_H_type_E)
        Me.GroupBox4.Controls.Add(Me.Button2)
        Me.GroupBox4.Controls.Add(Me.H_end_E)
        Me.GroupBox4.Controls.Add(Me.Button5)
        Me.GroupBox4.Controls.Add(Me.H_start_E)
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Controls.Add(Me.Label19)
        Me.GroupBox4.Controls.Add(Me.Label20)
        Me.GroupBox4.Location = New System.Drawing.Point(38, 215)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GroupBox4.Size = New System.Drawing.Size(1127, 237)
        Me.GroupBox4.TabIndex = 18
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "معلومات الاجازة :"
        '
        'L_D_H_E
        '
        Me.L_D_H_E.AutoSize = True
        Me.L_D_H_E.Location = New System.Drawing.Point(578, 139)
        Me.L_D_H_E.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_D_H_E.Name = "L_D_H_E"
        Me.L_D_H_E.Size = New System.Drawing.Size(0, 17)
        Me.L_D_H_E.TabIndex = 29
        '
        'CM_H_type_E
        '
        Me.CM_H_type_E.FormattingEnabled = True
        Me.CM_H_type_E.Location = New System.Drawing.Point(424, 28)
        Me.CM_H_type_E.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.CM_H_type_E.Name = "CM_H_type_E"
        Me.CM_H_type_E.Size = New System.Drawing.Size(170, 25)
        Me.CM_H_type_E.TabIndex = 28
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(382, 182)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(112, 37)
        Me.Button2.TabIndex = 12
        Me.Button2.Text = "حفظ"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'H_end_E
        '
        Me.H_end_E.Location = New System.Drawing.Point(257, 80)
        Me.H_end_E.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.H_end_E.Name = "H_end_E"
        Me.H_end_E.Size = New System.Drawing.Size(172, 24)
        Me.H_end_E.TabIndex = 27
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.White
        Me.Button5.Location = New System.Drawing.Point(514, 182)
        Me.Button5.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(112, 37)
        Me.Button5.TabIndex = 14
        Me.Button5.Text = "الغاء الامر"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'H_start_E
        '
        Me.H_start_E.Location = New System.Drawing.Point(588, 80)
        Me.H_start_E.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.H_start_E.Name = "H_start_E"
        Me.H_start_E.Size = New System.Drawing.Size(188, 24)
        Me.H_start_E.TabIndex = 26
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(605, 31)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(74, 17)
        Me.Label17.TabIndex = 25
        Me.Label17.Text = "نوع الاجازة :"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(436, 85)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(99, 17)
        Me.Label18.TabIndex = 21
        Me.Label18.Text = "ت/انتهاء الاجازة :"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(783, 85)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(92, 17)
        Me.Label19.TabIndex = 20
        Me.Label19.Text = "ت/بداية الاجازة :"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(607, 139)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(73, 17)
        Me.Label20.TabIndex = 12
        Me.Label20.Text = "المدة بالايام :"
        '
        'TabPage12
        '
        Me.TabPage12.Controls.Add(Me.Label21)
        Me.TabPage12.Controls.Add(Me.txt_H)
        Me.TabPage12.Controls.Add(Me.dgvHoli_Emp)
        Me.TabPage12.Location = New System.Drawing.Point(4, 26)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage12.Size = New System.Drawing.Size(1210, 698)
        Me.TabPage12.TabIndex = 2
        Me.TabPage12.Text = "الموظفون في اجازة"
        Me.TabPage12.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(792, 13)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(76, 35)
        Me.Label21.TabIndex = 3
        Me.Label21.Text = "بحث :"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_H
        '
        Me.txt_H.Location = New System.Drawing.Point(395, 19)
        Me.txt_H.Name = "txt_H"
        Me.txt_H.Size = New System.Drawing.Size(395, 24)
        Me.txt_H.TabIndex = 4
        Me.txt_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'dgvHoli_Emp
        '
        Me.dgvHoli_Emp.AllowUserToAddRows = False
        Me.dgvHoli_Emp.AllowUserToDeleteRows = False
        Me.dgvHoli_Emp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvHoli_Emp.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ID_H_D, Me.H_Id, Me.H_Period_D, Me.H_Start, Me.H_End_D, Me.Emp_Id_H_D})
        Me.dgvHoli_Emp.Location = New System.Drawing.Point(16, 64)
        Me.dgvHoli_Emp.Name = "dgvHoli_Emp"
        Me.dgvHoli_Emp.ReadOnly = True
        Me.dgvHoli_Emp.RowTemplate.Height = 26
        Me.dgvHoli_Emp.Size = New System.Drawing.Size(1161, 584)
        Me.dgvHoli_Emp.TabIndex = 0
        '
        'ID_H_D
        '
        Me.ID_H_D.DataPropertyName = "ID"
        Me.ID_H_D.HeaderText = "الرقم"
        Me.ID_H_D.Name = "ID_H_D"
        Me.ID_H_D.ReadOnly = True
        '
        'H_Id
        '
        Me.H_Id.DataPropertyName = "H_Id"
        Me.H_Id.HeaderText = "رقم الاجازة"
        Me.H_Id.Name = "H_Id"
        Me.H_Id.ReadOnly = True
        '
        'H_Period_D
        '
        Me.H_Period_D.DataPropertyName = "H_Period"
        Me.H_Period_D.HeaderText = "مدة الاجازة"
        Me.H_Period_D.Name = "H_Period_D"
        Me.H_Period_D.ReadOnly = True
        '
        'H_Start
        '
        Me.H_Start.DataPropertyName = "H_Start"
        Me.H_Start.HeaderText = "تاريخ البداية"
        Me.H_Start.Name = "H_Start"
        Me.H_Start.ReadOnly = True
        '
        'H_End_D
        '
        Me.H_End_D.DataPropertyName = "H_End"
        Me.H_End_D.HeaderText = "تاريخ النهاية"
        Me.H_End_D.Name = "H_End_D"
        Me.H_End_D.ReadOnly = True
        '
        'Emp_Id_H_D
        '
        Me.Emp_Id_H_D.DataPropertyName = "Emp_Id"
        Me.Emp_Id_H_D.HeaderText = "رقم الموظف"
        Me.Emp_Id_H_D.Name = "Emp_Id_H_D"
        Me.Emp_Id_H_D.ReadOnly = True
        '
        'Emp_P
        '
        Me.Emp_P.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Emp_P.Controls.Add(Me.Panel1)
        Me.Emp_P.Location = New System.Drawing.Point(4, 26)
        Me.Emp_P.Name = "Emp_P"
        Me.Emp_P.Padding = New System.Windows.Forms.Padding(3)
        Me.Emp_P.Size = New System.Drawing.Size(1235, 813)
        Me.Emp_P.TabIndex = 0
        Me.Emp_P.Text = "الموظفون"
        Me.Emp_P.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel1.Controls.Add(Me.TabEmp)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Panel4)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.txt_Emp)
        Me.Panel1.Controls.Add(Me.dgvEmp)
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1229, 789)
        Me.Panel1.TabIndex = 1
        '
        'TabEmp
        '
        Me.TabEmp.Controls.Add(Me.TabFamily)
        Me.TabEmp.Controls.Add(Me.tabcase_Emp)
        Me.TabEmp.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabEmp.Location = New System.Drawing.Point(0, 523)
        Me.TabEmp.Name = "TabEmp"
        Me.TabEmp.RightToLeftLayout = True
        Me.TabEmp.SelectedIndex = 0
        Me.TabEmp.Size = New System.Drawing.Size(1225, 262)
        Me.TabEmp.TabIndex = 3
        '
        'TabFamily
        '
        Me.TabFamily.Controls.Add(Me.Button53)
        Me.TabFamily.Controls.Add(Me.Button11)
        Me.TabFamily.Controls.Add(Me.Button9)
        Me.TabFamily.Controls.Add(Me.Label84)
        Me.TabFamily.Controls.Add(Me.TextBox26)
        Me.TabFamily.Controls.Add(Me.dgvFamily_Emp)
        Me.TabFamily.Location = New System.Drawing.Point(4, 29)
        Me.TabFamily.Name = "TabFamily"
        Me.TabFamily.Padding = New System.Windows.Forms.Padding(3)
        Me.TabFamily.Size = New System.Drawing.Size(1217, 229)
        Me.TabFamily.TabIndex = 2
        Me.TabFamily.Text = "عائلة الموظف"
        Me.TabFamily.UseVisualStyleBackColor = True
        '
        'Button53
        '
        Me.Button53.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button53.Location = New System.Drawing.Point(467, 182)
        Me.Button53.Name = "Button53"
        Me.Button53.Size = New System.Drawing.Size(88, 41)
        Me.Button53.TabIndex = 9
        Me.Button53.Text = "حذف فرد"
        Me.Button53.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(561, 182)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(149, 41)
        Me.Button11.TabIndex = 8
        Me.Button11.Text = "تعديل بيانات الفرد"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(716, 182)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(88, 41)
        Me.Button9.TabIndex = 7
        Me.Button9.Text = "اضافة فرد"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Label84
        '
        Me.Label84.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(785, -1)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(76, 35)
        Me.Label84.TabIndex = 5
        Me.Label84.Text = "بحث :"
        Me.Label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox26
        '
        Me.TextBox26.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox26.Location = New System.Drawing.Point(388, 5)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(395, 24)
        Me.TextBox26.TabIndex = 6
        Me.TextBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'dgvFamily_Emp
        '
        Me.dgvFamily_Emp.AllowUserToAddRows = False
        Me.dgvFamily_Emp.AllowUserToDeleteRows = False
        Me.dgvFamily_Emp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvFamily_Emp.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.family_NW_dg, Me.family_Name_D, Me.family_Adjective_D, Me.family_Gender_D, Me.family_Nationa_D, Me.family_Birth_Date_D, Me.family_Birth_Place_D, Me.family_Emp_Id_D})
        Me.dgvFamily_Emp.Location = New System.Drawing.Point(13, 38)
        Me.dgvFamily_Emp.Name = "dgvFamily_Emp"
        Me.dgvFamily_Emp.ReadOnly = True
        Me.dgvFamily_Emp.RowHeadersVisible = False
        Me.dgvFamily_Emp.RowTemplate.Height = 26
        Me.dgvFamily_Emp.Size = New System.Drawing.Size(1154, 138)
        Me.dgvFamily_Emp.TabIndex = 4
        '
        'family_NW_dg
        '
        Me.family_NW_dg.DataPropertyName = "F_NW"
        Me.family_NW_dg.HeaderText = "الرقم الوطني"
        Me.family_NW_dg.Name = "family_NW_dg"
        Me.family_NW_dg.ReadOnly = True
        '
        'family_Name_D
        '
        Me.family_Name_D.DataPropertyName = "F_Name"
        Me.family_Name_D.HeaderText = "الاسم"
        Me.family_Name_D.Name = "family_Name_D"
        Me.family_Name_D.ReadOnly = True
        '
        'family_Adjective_D
        '
        Me.family_Adjective_D.DataPropertyName = "Adjective"
        Me.family_Adjective_D.HeaderText = "الصفة"
        Me.family_Adjective_D.Name = "family_Adjective_D"
        Me.family_Adjective_D.ReadOnly = True
        '
        'family_Gender_D
        '
        Me.family_Gender_D.DataPropertyName = "Gender"
        Me.family_Gender_D.HeaderText = "الجنس"
        Me.family_Gender_D.Name = "family_Gender_D"
        Me.family_Gender_D.ReadOnly = True
        '
        'family_Nationa_D
        '
        Me.family_Nationa_D.DataPropertyName = "Nationa"
        Me.family_Nationa_D.HeaderText = "الجنسية"
        Me.family_Nationa_D.Name = "family_Nationa_D"
        Me.family_Nationa_D.ReadOnly = True
        '
        'family_Birth_Date_D
        '
        Me.family_Birth_Date_D.DataPropertyName = "Birth_Date"
        Me.family_Birth_Date_D.HeaderText = "تاريخ الميلاد"
        Me.family_Birth_Date_D.Name = "family_Birth_Date_D"
        Me.family_Birth_Date_D.ReadOnly = True
        '
        'family_Birth_Place_D
        '
        Me.family_Birth_Place_D.DataPropertyName = "Birth_Place"
        Me.family_Birth_Place_D.HeaderText = "مكان الميلاد"
        Me.family_Birth_Place_D.Name = "family_Birth_Place_D"
        Me.family_Birth_Place_D.ReadOnly = True
        '
        'family_Emp_Id_D
        '
        Me.family_Emp_Id_D.DataPropertyName = "Emp_Id"
        Me.family_Emp_Id_D.HeaderText = "رقم الموظف"
        Me.family_Emp_Id_D.Name = "family_Emp_Id_D"
        Me.family_Emp_Id_D.ReadOnly = True
        '
        'tabcase_Emp
        '
        Me.tabcase_Emp.Controls.Add(Me.Button3)
        Me.tabcase_Emp.Controls.Add(Me.Button7)
        Me.tabcase_Emp.Controls.Add(Me.Button8)
        Me.tabcase_Emp.Controls.Add(Me.Label54)
        Me.tabcase_Emp.Controls.Add(Me.dgvCaseEmp)
        Me.tabcase_Emp.Controls.Add(Me.TextBox1)
        Me.tabcase_Emp.Location = New System.Drawing.Point(4, 29)
        Me.tabcase_Emp.Name = "tabcase_Emp"
        Me.tabcase_Emp.Padding = New System.Windows.Forms.Padding(3)
        Me.tabcase_Emp.Size = New System.Drawing.Size(1217, 229)
        Me.tabcase_Emp.TabIndex = 3
        Me.tabcase_Emp.Text = "حالة الموظف"
        Me.tabcase_Emp.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(603, 185)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(83, 33)
        Me.Button3.TabIndex = 66
        Me.Button3.Text = "تعديل"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(705, 185)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(77, 33)
        Me.Button7.TabIndex = 64
        Me.Button7.Text = "الغاء"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(493, 185)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(91, 33)
        Me.Button8.TabIndex = 63
        Me.Button8.Text = "اضافة"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Label54
        '
        Me.Label54.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.Location = New System.Drawing.Point(872, 4)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(76, 35)
        Me.Label54.TabIndex = 4
        Me.Label54.Text = "بحث :"
        Me.Label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dgvCaseEmp
        '
        Me.dgvCaseEmp.AllowUserToAddRows = False
        Me.dgvCaseEmp.AllowUserToDeleteRows = False
        Me.dgvCaseEmp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvCaseEmp.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Case_Emp_id, Me.Case_Id, Me.Date_End_Emp, Me.Reason})
        Me.dgvCaseEmp.Location = New System.Drawing.Point(227, 42)
        Me.dgvCaseEmp.Name = "dgvCaseEmp"
        Me.dgvCaseEmp.ReadOnly = True
        Me.dgvCaseEmp.RowHeadersVisible = False
        Me.dgvCaseEmp.RowTemplate.Height = 26
        Me.dgvCaseEmp.Size = New System.Drawing.Size(793, 137)
        Me.dgvCaseEmp.TabIndex = 0
        '
        'Case_Emp_id
        '
        Me.Case_Emp_id.DataPropertyName = "Emp_id"
        Me.Case_Emp_id.HeaderText = "رقم الموظف"
        Me.Case_Emp_id.Name = "Case_Emp_id"
        Me.Case_Emp_id.ReadOnly = True
        '
        'Case_Id
        '
        Me.Case_Id.DataPropertyName = "Case_Id"
        Me.Case_Id.HeaderText = "حالة الموظف"
        Me.Case_Id.Name = "Case_Id"
        Me.Case_Id.ReadOnly = True
        '
        'Date_End_Emp
        '
        Me.Date_End_Emp.DataPropertyName = "Date_End"
        Me.Date_End_Emp.HeaderText = "تاريخ الانتهاء"
        Me.Date_End_Emp.Name = "Date_End_Emp"
        Me.Date_End_Emp.ReadOnly = True
        '
        'Reason
        '
        Me.Reason.DataPropertyName = "Reason"
        Me.Reason.HeaderText = "السبب"
        Me.Reason.Name = "Reason"
        Me.Reason.ReadOnly = True
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(471, 6)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(395, 26)
        Me.TextBox1.TabIndex = 5
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.btnedit_Emp)
        Me.Panel3.Controls.Add(Me.btnDelet_Emp)
        Me.Panel3.Controls.Add(Me.Label52)
        Me.Panel3.Controls.Add(Me.CM_Dep_Id)
        Me.Panel3.Controls.Add(Me.CM_Country)
        Me.Panel3.Controls.Add(Me.Label30)
        Me.Panel3.Controls.Add(Me.Getting_Date)
        Me.Panel3.Controls.Add(Me.btnexit_Emp)
        Me.Panel3.Controls.Add(Me.Label29)
        Me.Panel3.Controls.Add(Me.CM_Costing)
        Me.Panel3.Controls.Add(Me.btnadd_Emp)
        Me.Panel3.Controls.Add(Me.Label28)
        Me.Panel3.Controls.Add(Me.CM_Qual_Id)
        Me.Panel3.Controls.Add(Me.Label27)
        Me.Panel3.Controls.Add(Me.CM_Spec_Id)
        Me.Panel3.Controls.Add(Me.Label26)
        Me.Panel3.Controls.Add(Me.Label25)
        Me.Panel3.Controls.Add(Me.Cer_Id)
        Me.Panel3.Controls.Add(Me.CM_L_J_Id)
        Me.Panel3.Controls.Add(Me.CM_Job_Id)
        Me.Panel3.Controls.Add(Me.Annual_L_Balance)
        Me.Panel3.Controls.Add(Me.Label22)
        Me.Panel3.Controls.Add(Me.D_O_D_A)
        Me.Panel3.Controls.Add(Me.Label23)
        Me.Panel3.Controls.Add(Me.Label31)
        Me.Panel3.Controls.Add(Me.CM_F_Deg_Id)
        Me.Panel3.Controls.Add(Me.Label32)
        Me.Panel3.Controls.Add(Me.Label33)
        Me.Panel3.Controls.Add(Me.Label34)
        Me.Panel3.Controls.Add(Me.E_L_Balance)
        Me.Panel3.Controls.Add(Me.Label35)
        Me.Panel3.Controls.Add(Me.D_O_O_W)
        Me.Panel3.Controls.Add(Me.Label36)
        Me.Panel3.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel3.Location = New System.Drawing.Point(11, 6)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(591, 309)
        Me.Panel3.TabIndex = 38
        '
        'btnedit_Emp
        '
        Me.btnedit_Emp.Location = New System.Drawing.Point(216, 272)
        Me.btnedit_Emp.Name = "btnedit_Emp"
        Me.btnedit_Emp.Size = New System.Drawing.Size(83, 33)
        Me.btnedit_Emp.TabIndex = 62
        Me.btnedit_Emp.Text = "تعديل"
        Me.btnedit_Emp.UseVisualStyleBackColor = True
        '
        'btnDelet_Emp
        '
        Me.btnDelet_Emp.Location = New System.Drawing.Point(309, 271)
        Me.btnDelet_Emp.Name = "btnDelet_Emp"
        Me.btnDelet_Emp.Size = New System.Drawing.Size(83, 33)
        Me.btnDelet_Emp.TabIndex = 61
        Me.btnDelet_Emp.Text = "حذف"
        Me.btnDelet_Emp.UseVisualStyleBackColor = True
        '
        'Label52
        '
        Me.Label52.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label52.BackColor = System.Drawing.Color.White
        Me.Label52.Location = New System.Drawing.Point(452, 2)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(138, 23)
        Me.Label52.TabIndex = 58
        Me.Label52.Text = "بيانات المؤهل"
        Me.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CM_Dep_Id
        '
        Me.CM_Dep_Id.FormattingEnabled = True
        Me.CM_Dep_Id.Location = New System.Drawing.Point(6, 231)
        Me.CM_Dep_Id.Name = "CM_Dep_Id"
        Me.CM_Dep_Id.Size = New System.Drawing.Size(148, 24)
        Me.CM_Dep_Id.TabIndex = 57
        Me.CM_Dep_Id.UseWaitCursor = True
        '
        'CM_Country
        '
        Me.CM_Country.FormattingEnabled = True
        Me.CM_Country.Location = New System.Drawing.Point(6, 197)
        Me.CM_Country.Name = "CM_Country"
        Me.CM_Country.Size = New System.Drawing.Size(148, 24)
        Me.CM_Country.TabIndex = 56
        Me.CM_Country.UseWaitCursor = True
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(154, 201)
        Me.Label30.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(74, 17)
        Me.Label30.TabIndex = 55
        Me.Label30.Text = "مكان الاصدار"
        Me.Label30.UseWaitCursor = True
        '
        'Getting_Date
        '
        Me.Getting_Date.Location = New System.Drawing.Point(6, 162)
        Me.Getting_Date.Name = "Getting_Date"
        Me.Getting_Date.Size = New System.Drawing.Size(146, 24)
        Me.Getting_Date.TabIndex = 53
        Me.Getting_Date.UseWaitCursor = True
        '
        'btnexit_Emp
        '
        Me.btnexit_Emp.Location = New System.Drawing.Point(121, 272)
        Me.btnexit_Emp.Name = "btnexit_Emp"
        Me.btnexit_Emp.Size = New System.Drawing.Size(83, 33)
        Me.btnexit_Emp.TabIndex = 35
        Me.btnexit_Emp.Text = "الغاء"
        Me.btnexit_Emp.UseVisualStyleBackColor = True
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(154, 170)
        Me.Label29.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(77, 17)
        Me.Label29.TabIndex = 54
        Me.Label29.Text = "تاريخ الاصدار"
        Me.Label29.UseWaitCursor = True
        '
        'CM_Costing
        '
        Me.CM_Costing.FormattingEnabled = True
        Me.CM_Costing.Items.AddRange(New Object() {"ممتاز", "جيدجدا", "جيد", "مقبول"})
        Me.CM_Costing.Location = New System.Drawing.Point(6, 128)
        Me.CM_Costing.Name = "CM_Costing"
        Me.CM_Costing.Size = New System.Drawing.Size(146, 24)
        Me.CM_Costing.TabIndex = 52
        Me.CM_Costing.UseWaitCursor = True
        '
        'btnadd_Emp
        '
        Me.btnadd_Emp.Location = New System.Drawing.Point(21, 272)
        Me.btnadd_Emp.Name = "btnadd_Emp"
        Me.btnadd_Emp.Size = New System.Drawing.Size(91, 33)
        Me.btnadd_Emp.TabIndex = 34
        Me.btnadd_Emp.Text = "اضافة"
        Me.btnadd_Emp.UseVisualStyleBackColor = True
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(188, 138)
        Me.Label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(38, 17)
        Me.Label28.TabIndex = 51
        Me.Label28.Text = "التقدير"
        Me.Label28.UseWaitCursor = True
        '
        'CM_Qual_Id
        '
        Me.CM_Qual_Id.FormattingEnabled = True
        Me.CM_Qual_Id.Items.AddRange(New Object() {""})
        Me.CM_Qual_Id.Location = New System.Drawing.Point(6, 96)
        Me.CM_Qual_Id.Name = "CM_Qual_Id"
        Me.CM_Qual_Id.Size = New System.Drawing.Size(146, 24)
        Me.CM_Qual_Id.TabIndex = 50
        Me.CM_Qual_Id.UseWaitCursor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(189, 103)
        Me.Label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(41, 17)
        Me.Label27.TabIndex = 49
        Me.Label27.Text = "المؤهل"
        Me.Label27.UseWaitCursor = True
        '
        'CM_Spec_Id
        '
        Me.CM_Spec_Id.FormattingEnabled = True
        Me.CM_Spec_Id.Location = New System.Drawing.Point(6, 60)
        Me.CM_Spec_Id.Name = "CM_Spec_Id"
        Me.CM_Spec_Id.Size = New System.Drawing.Size(146, 24)
        Me.CM_Spec_Id.TabIndex = 48
        Me.CM_Spec_Id.UseWaitCursor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(174, 66)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(55, 17)
        Me.Label26.TabIndex = 47
        Me.Label26.Text = "التخصص"
        Me.Label26.UseWaitCursor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(452, 233)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(89, 17)
        Me.Label25.TabIndex = 46
        Me.Label25.Text = "رقم وثيقة التخرج"
        Me.Label25.UseWaitCursor = True
        '
        'Cer_Id
        '
        Me.Cer_Id.Location = New System.Drawing.Point(269, 231)
        Me.Cer_Id.Margin = New System.Windows.Forms.Padding(4)
        Me.Cer_Id.Name = "Cer_Id"
        Me.Cer_Id.Size = New System.Drawing.Size(143, 24)
        Me.Cer_Id.TabIndex = 45
        Me.Cer_Id.UseWaitCursor = True
        '
        'CM_L_J_Id
        '
        Me.CM_L_J_Id.FormattingEnabled = True
        Me.CM_L_J_Id.Items.AddRange(New Object() {"أعزب", "متزوج"})
        Me.CM_L_J_Id.Location = New System.Drawing.Point(270, 197)
        Me.CM_L_J_Id.Name = "CM_L_J_Id"
        Me.CM_L_J_Id.Size = New System.Drawing.Size(142, 24)
        Me.CM_L_J_Id.TabIndex = 44
        Me.CM_L_J_Id.UseWaitCursor = True
        '
        'CM_Job_Id
        '
        Me.CM_Job_Id.FormattingEnabled = True
        Me.CM_Job_Id.Items.AddRange(New Object() {"أعزب", "متزوج"})
        Me.CM_Job_Id.Location = New System.Drawing.Point(269, 165)
        Me.CM_Job_Id.Name = "CM_Job_Id"
        Me.CM_Job_Id.Size = New System.Drawing.Size(143, 24)
        Me.CM_Job_Id.TabIndex = 29
        Me.CM_Job_Id.UseWaitCursor = True
        '
        'Annual_L_Balance
        '
        Me.Annual_L_Balance.Location = New System.Drawing.Point(270, 100)
        Me.Annual_L_Balance.Margin = New System.Windows.Forms.Padding(4)
        Me.Annual_L_Balance.Name = "Annual_L_Balance"
        Me.Annual_L_Balance.Size = New System.Drawing.Size(143, 24)
        Me.Annual_L_Balance.TabIndex = 42
        Me.Annual_L_Balance.UseWaitCursor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(427, 102)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(122, 17)
        Me.Label22.TabIndex = 43
        Me.Label22.Text = "رصيد الاجازات السنوية"
        Me.Label22.UseWaitCursor = True
        '
        'D_O_D_A
        '
        Me.D_O_D_A.Location = New System.Drawing.Point(270, 38)
        Me.D_O_D_A.Name = "D_O_D_A"
        Me.D_O_D_A.Size = New System.Drawing.Size(143, 24)
        Me.D_O_D_A.TabIndex = 40
        Me.D_O_D_A.UseWaitCursor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(453, 39)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(100, 17)
        Me.Label23.TabIndex = 41
        Me.Label23.Text = "تاريخ مباشرة العمل"
        Me.Label23.UseWaitCursor = True
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(177, 233)
        Me.Label31.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(51, 17)
        Me.Label31.TabIndex = 39
        Me.Label31.Text = "رقم القسم"
        Me.Label31.UseWaitCursor = True
        '
        'CM_F_Deg_Id
        '
        Me.CM_F_Deg_Id.FormattingEnabled = True
        Me.CM_F_Deg_Id.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.CM_F_Deg_Id.Location = New System.Drawing.Point(6, 26)
        Me.CM_F_Deg_Id.Name = "CM_F_Deg_Id"
        Me.CM_F_Deg_Id.Size = New System.Drawing.Size(143, 24)
        Me.CM_F_Deg_Id.TabIndex = 38
        Me.CM_F_Deg_Id.UseWaitCursor = True
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(186, 29)
        Me.Label32.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(40, 17)
        Me.Label32.TabIndex = 37
        Me.Label32.Text = "الدرجة"
        Me.Label32.UseWaitCursor = True
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(453, 199)
        Me.Label33.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(90, 17)
        Me.Label33.TabIndex = 35
        Me.Label33.Text = "المستوي الوظيفي"
        Me.Label33.UseWaitCursor = True
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(479, 167)
        Me.Label34.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(63, 17)
        Me.Label34.TabIndex = 33
        Me.Label34.Text = "اسم الوظيفة"
        Me.Label34.UseWaitCursor = True
        '
        'E_L_Balance
        '
        Me.E_L_Balance.Location = New System.Drawing.Point(270, 132)
        Me.E_L_Balance.Margin = New System.Windows.Forms.Padding(4)
        Me.E_L_Balance.Name = "E_L_Balance"
        Me.E_L_Balance.Size = New System.Drawing.Size(143, 24)
        Me.E_L_Balance.TabIndex = 30
        Me.E_L_Balance.UseWaitCursor = True
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(426, 134)
        Me.Label35.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(123, 17)
        Me.Label35.TabIndex = 31
        Me.Label35.Text = "رصيد الاجازات الطارئة"
        Me.Label35.UseWaitCursor = True
        '
        'D_O_O_W
        '
        Me.D_O_O_W.Location = New System.Drawing.Point(270, 68)
        Me.D_O_O_W.Name = "D_O_O_W"
        Me.D_O_O_W.Size = New System.Drawing.Size(143, 24)
        Me.D_O_O_W.TabIndex = 28
        Me.D_O_O_W.UseWaitCursor = True
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(413, 73)
        Me.Label36.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(140, 17)
        Me.Label36.TabIndex = 29
        Me.Label36.Text = "تاريخ مباشرة العمل الاصلي"
        Me.Label36.UseWaitCursor = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Label53)
        Me.Panel4.Controls.Add(Me.CM_Birth_Place)
        Me.Panel4.Controls.Add(Me.Conf_Id)
        Me.Panel4.Controls.Add(Me.Emp_Id)
        Me.Panel4.Controls.Add(Me.Label38)
        Me.Panel4.Controls.Add(Me.Email)
        Me.Panel4.Controls.Add(Me.Emp_Name)
        Me.Panel4.Controls.Add(Me.Label39)
        Me.Panel4.Controls.Add(Me.Label40)
        Me.Panel4.Controls.Add(Me.Phone)
        Me.Panel4.Controls.Add(Me.Emp_M)
        Me.Panel4.Controls.Add(Me.Label41)
        Me.Panel4.Controls.Add(Me.Label42)
        Me.Panel4.Controls.Add(Me.Address)
        Me.Panel4.Controls.Add(Me.Label43)
        Me.Panel4.Controls.Add(Me.Label44)
        Me.Panel4.Controls.Add(Me.Emp_NW)
        Me.Panel4.Controls.Add(Me.Nationa)
        Me.Panel4.Controls.Add(Me.Label45)
        Me.Panel4.Controls.Add(Me.Label46)
        Me.Panel4.Controls.Add(Me.Conf_Type)
        Me.Panel4.Controls.Add(Me.CM_Gender)
        Me.Panel4.Controls.Add(Me.Label47)
        Me.Panel4.Controls.Add(Me.Label48)
        Me.Panel4.Controls.Add(Me.Birth_Data)
        Me.Panel4.Controls.Add(Me.CM_Social_Case)
        Me.Panel4.Controls.Add(Me.Label49)
        Me.Panel4.Controls.Add(Me.Label50)
        Me.Panel4.Controls.Add(Me.Label51)
        Me.Panel4.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel4.Location = New System.Drawing.Point(623, 5)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(600, 310)
        Me.Panel4.TabIndex = 36
        Me.Panel4.UseWaitCursor = True
        '
        'Label53
        '
        Me.Label53.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label53.BackColor = System.Drawing.Color.White
        Me.Label53.Location = New System.Drawing.Point(460, 2)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(139, 21)
        Me.Label53.TabIndex = 59
        Me.Label53.Text = "البيانات الشخصية"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label53.UseWaitCursor = True
        '
        'CM_Birth_Place
        '
        Me.CM_Birth_Place.FormattingEnabled = True
        Me.CM_Birth_Place.Location = New System.Drawing.Point(327, 210)
        Me.CM_Birth_Place.Name = "CM_Birth_Place"
        Me.CM_Birth_Place.Size = New System.Drawing.Size(144, 24)
        Me.CM_Birth_Place.TabIndex = 28
        Me.CM_Birth_Place.UseWaitCursor = True
        '
        'Conf_Id
        '
        Me.Conf_Id.Location = New System.Drawing.Point(327, 107)
        Me.Conf_Id.Margin = New System.Windows.Forms.Padding(4)
        Me.Conf_Id.Name = "Conf_Id"
        Me.Conf_Id.Size = New System.Drawing.Size(144, 24)
        Me.Conf_Id.TabIndex = 6
        Me.Conf_Id.UseWaitCursor = True
        '
        'Emp_Id
        '
        Me.Emp_Id.BackColor = System.Drawing.Color.White
        Me.Emp_Id.Location = New System.Drawing.Point(327, 35)
        Me.Emp_Id.Margin = New System.Windows.Forms.Padding(4)
        Me.Emp_Id.Name = "Emp_Id"
        Me.Emp_Id.ReadOnly = True
        Me.Emp_Id.Size = New System.Drawing.Size(144, 24)
        Me.Emp_Id.TabIndex = 0
        Me.Emp_Id.UseWaitCursor = True
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(477, 42)
        Me.Label38.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(67, 17)
        Me.Label38.TabIndex = 1
        Me.Label38.Text = "رقم الموظف"
        Me.Label38.UseWaitCursor = True
        '
        'Email
        '
        Me.Email.Location = New System.Drawing.Point(8, 206)
        Me.Email.Margin = New System.Windows.Forms.Padding(4)
        Me.Email.Name = "Email"
        Me.Email.Size = New System.Drawing.Size(210, 24)
        Me.Email.TabIndex = 27
        Me.Email.UseWaitCursor = True
        '
        'Emp_Name
        '
        Me.Emp_Name.Location = New System.Drawing.Point(8, 31)
        Me.Emp_Name.Margin = New System.Windows.Forms.Padding(4)
        Me.Emp_Name.Name = "Emp_Name"
        Me.Emp_Name.Size = New System.Drawing.Size(210, 24)
        Me.Emp_Name.TabIndex = 2
        Me.Emp_Name.UseWaitCursor = True
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(226, 210)
        Me.Label39.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(41, 17)
        Me.Label39.TabIndex = 26
        Me.Label39.Text = "الايميل"
        Me.Label39.UseWaitCursor = True
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(226, 38)
        Me.Label40.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(67, 17)
        Me.Label40.TabIndex = 3
        Me.Label40.Text = "اسم الموظف"
        Me.Label40.UseWaitCursor = True
        '
        'Phone
        '
        Me.Phone.Location = New System.Drawing.Point(8, 169)
        Me.Phone.Margin = New System.Windows.Forms.Padding(4)
        Me.Phone.Name = "Phone"
        Me.Phone.Size = New System.Drawing.Size(210, 24)
        Me.Phone.TabIndex = 25
        Me.Phone.UseWaitCursor = True
        '
        'Emp_M
        '
        Me.Emp_M.Location = New System.Drawing.Point(8, 65)
        Me.Emp_M.Margin = New System.Windows.Forms.Padding(4)
        Me.Emp_M.Name = "Emp_M"
        Me.Emp_M.Size = New System.Drawing.Size(210, 24)
        Me.Emp_M.TabIndex = 4
        Me.Emp_M.UseWaitCursor = True
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(226, 175)
        Me.Label41.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(39, 17)
        Me.Label41.TabIndex = 24
        Me.Label41.Text = "الهاتف"
        Me.Label41.UseWaitCursor = True
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(226, 71)
        Me.Label42.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(44, 17)
        Me.Label42.TabIndex = 5
        Me.Label42.Text = "اسم الام"
        Me.Label42.UseWaitCursor = True
        '
        'Address
        '
        Me.Address.Location = New System.Drawing.Point(8, 135)
        Me.Address.Margin = New System.Windows.Forms.Padding(4)
        Me.Address.Name = "Address"
        Me.Address.Size = New System.Drawing.Size(210, 24)
        Me.Address.TabIndex = 23
        Me.Address.UseWaitCursor = True
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(477, 75)
        Me.Label43.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(91, 17)
        Me.Label43.TabIndex = 7
        Me.Label43.Text = "نوع وثيقة الاثبات"
        Me.Label43.UseWaitCursor = True
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(228, 142)
        Me.Label44.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(41, 17)
        Me.Label44.TabIndex = 22
        Me.Label44.Text = "العنوان"
        Me.Label44.UseWaitCursor = True
        '
        'Emp_NW
        '
        Me.Emp_NW.Location = New System.Drawing.Point(327, 142)
        Me.Emp_NW.Margin = New System.Windows.Forms.Padding(4)
        Me.Emp_NW.Name = "Emp_NW"
        Me.Emp_NW.Size = New System.Drawing.Size(144, 24)
        Me.Emp_NW.TabIndex = 8
        Me.Emp_NW.UseWaitCursor = True
        '
        'Nationa
        '
        Me.Nationa.Location = New System.Drawing.Point(8, 102)
        Me.Nationa.Margin = New System.Windows.Forms.Padding(4)
        Me.Nationa.Name = "Nationa"
        Me.Nationa.Size = New System.Drawing.Size(210, 24)
        Me.Nationa.TabIndex = 21
        Me.Nationa.UseWaitCursor = True
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(477, 114)
        Me.Label45.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(58, 17)
        Me.Label45.TabIndex = 9
        Me.Label45.Text = "رقم الوثيقة"
        Me.Label45.UseWaitCursor = True
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(226, 109)
        Me.Label46.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(44, 17)
        Me.Label46.TabIndex = 20
        Me.Label46.Text = "الجنسية"
        Me.Label46.UseWaitCursor = True
        '
        'Conf_Type
        '
        Me.Conf_Type.FormattingEnabled = True
        Me.Conf_Type.Items.AddRange(New Object() {"جواز سفر", "بطاقة شخصية"})
        Me.Conf_Type.Location = New System.Drawing.Point(327, 68)
        Me.Conf_Type.Name = "Conf_Type"
        Me.Conf_Type.Size = New System.Drawing.Size(144, 24)
        Me.Conf_Type.TabIndex = 10
        Me.Conf_Type.UseWaitCursor = True
        '
        'CM_Gender
        '
        Me.CM_Gender.FormattingEnabled = True
        Me.CM_Gender.Items.AddRange(New Object() {"ذكر", "انثي"})
        Me.CM_Gender.Location = New System.Drawing.Point(8, 245)
        Me.CM_Gender.Name = "CM_Gender"
        Me.CM_Gender.Size = New System.Drawing.Size(210, 24)
        Me.CM_Gender.TabIndex = 19
        Me.CM_Gender.UseWaitCursor = True
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(477, 149)
        Me.Label47.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(68, 17)
        Me.Label47.TabIndex = 11
        Me.Label47.Text = "الرقم الوطني"
        Me.Label47.UseWaitCursor = True
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(227, 256)
        Me.Label48.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(38, 17)
        Me.Label48.TabIndex = 18
        Me.Label48.Text = "الجنس"
        Me.Label48.UseWaitCursor = True
        '
        'Birth_Data
        '
        Me.Birth_Data.Location = New System.Drawing.Point(327, 175)
        Me.Birth_Data.Name = "Birth_Data"
        Me.Birth_Data.Size = New System.Drawing.Size(144, 24)
        Me.Birth_Data.TabIndex = 12
        Me.Birth_Data.UseWaitCursor = True
        '
        'CM_Social_Case
        '
        Me.CM_Social_Case.FormattingEnabled = True
        Me.CM_Social_Case.Items.AddRange(New Object() {"أعزب", "متزوج"})
        Me.CM_Social_Case.Location = New System.Drawing.Point(330, 245)
        Me.CM_Social_Case.Name = "CM_Social_Case"
        Me.CM_Social_Case.Size = New System.Drawing.Size(141, 24)
        Me.CM_Social_Case.TabIndex = 17
        Me.CM_Social_Case.UseWaitCursor = True
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(477, 184)
        Me.Label49.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(68, 17)
        Me.Label49.TabIndex = 13
        Me.Label49.Text = "تاريخ الميلاد"
        Me.Label49.UseWaitCursor = True
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(480, 255)
        Me.Label50.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(88, 17)
        Me.Label50.TabIndex = 16
        Me.Label50.Text = "الحالة الاجتماعية"
        Me.Label50.UseWaitCursor = True
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(477, 217)
        Me.Label51.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(65, 17)
        Me.Label51.TabIndex = 15
        Me.Label51.Text = "مكان الميلاد"
        Me.Label51.UseWaitCursor = True
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(778, 318)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 35)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "بحث :"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_Emp
        '
        Me.txt_Emp.Location = New System.Drawing.Point(381, 325)
        Me.txt_Emp.Name = "txt_Emp"
        Me.txt_Emp.Size = New System.Drawing.Size(395, 24)
        Me.txt_Emp.TabIndex = 2
        Me.txt_Emp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'dgvEmp
        '
        Me.dgvEmp.AllowUserToAddRows = False
        Me.dgvEmp.AllowUserToDeleteRows = False
        Me.dgvEmp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvEmp.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Emp_Id_D, Me.Emp_Name_D, Me.Emp_M_D, Me.Conf_Type_D, Me.Conf_Id_D, Me.Emp_NW_D, Me.Birth_Date_D, Me.Birth_Place_D, Me.Social_Case_D, Me.Gender_D, Me.Nationa_D, Me.Address_D, Me.Phone_D, Me.Email_D, Me.D_O_D_A_D, Me.D_O_O_W_D, Me.A_L_B_D, Me.E_L_B_D, Me.Job_Id_D, Me.F_L_Id_D, Me.F_D_Id_D, Me.Cer_Id_D, Me.Spec_ID_D, Me.Qual_Id_D, Me.Costing_D, Me.Getting_Date_D, Me.Country_D, Me.Dep_Id_Emp_D})
        Me.dgvEmp.Location = New System.Drawing.Point(11, 359)
        Me.dgvEmp.Name = "dgvEmp"
        Me.dgvEmp.ReadOnly = True
        Me.dgvEmp.RowHeadersVisible = False
        Me.dgvEmp.RowTemplate.Height = 26
        Me.dgvEmp.Size = New System.Drawing.Size(1211, 158)
        Me.dgvEmp.TabIndex = 0
        '
        'Emp_Id_D
        '
        Me.Emp_Id_D.DataPropertyName = "Emp_Id"
        Me.Emp_Id_D.HeaderText = "رقم الموظف"
        Me.Emp_Id_D.Name = "Emp_Id_D"
        Me.Emp_Id_D.ReadOnly = True
        '
        'Emp_Name_D
        '
        Me.Emp_Name_D.DataPropertyName = "Emp_Name"
        Me.Emp_Name_D.HeaderText = "اسم الموظف"
        Me.Emp_Name_D.Name = "Emp_Name_D"
        Me.Emp_Name_D.ReadOnly = True
        '
        'Emp_M_D
        '
        Me.Emp_M_D.DataPropertyName = "Emp_M"
        Me.Emp_M_D.HeaderText = "اسم الام"
        Me.Emp_M_D.Name = "Emp_M_D"
        Me.Emp_M_D.ReadOnly = True
        '
        'Conf_Type_D
        '
        Me.Conf_Type_D.DataPropertyName = "Conf_Type"
        Me.Conf_Type_D.HeaderText = "ن/وثيقة الاثباب"
        Me.Conf_Type_D.Name = "Conf_Type_D"
        Me.Conf_Type_D.ReadOnly = True
        '
        'Conf_Id_D
        '
        Me.Conf_Id_D.DataPropertyName = "Conf_Id"
        Me.Conf_Id_D.HeaderText = "رقمها"
        Me.Conf_Id_D.Name = "Conf_Id_D"
        Me.Conf_Id_D.ReadOnly = True
        '
        'Emp_NW_D
        '
        Me.Emp_NW_D.DataPropertyName = "Emp_NW"
        Me.Emp_NW_D.HeaderText = "الرقم الوطني"
        Me.Emp_NW_D.Name = "Emp_NW_D"
        Me.Emp_NW_D.ReadOnly = True
        '
        'Birth_Date_D
        '
        Me.Birth_Date_D.DataPropertyName = "Birth_Date"
        Me.Birth_Date_D.HeaderText = "ت/الميلاد"
        Me.Birth_Date_D.Name = "Birth_Date_D"
        Me.Birth_Date_D.ReadOnly = True
        '
        'Birth_Place_D
        '
        Me.Birth_Place_D.DataPropertyName = "Birth_Place"
        Me.Birth_Place_D.HeaderText = "مكان الميلاد"
        Me.Birth_Place_D.Name = "Birth_Place_D"
        Me.Birth_Place_D.ReadOnly = True
        '
        'Social_Case_D
        '
        Me.Social_Case_D.DataPropertyName = "Social_Case"
        Me.Social_Case_D.HeaderText = "الحالة الاجتماعية"
        Me.Social_Case_D.Name = "Social_Case_D"
        Me.Social_Case_D.ReadOnly = True
        '
        'Gender_D
        '
        Me.Gender_D.DataPropertyName = "Gender"
        Me.Gender_D.HeaderText = "الجنس"
        Me.Gender_D.Name = "Gender_D"
        Me.Gender_D.ReadOnly = True
        '
        'Nationa_D
        '
        Me.Nationa_D.DataPropertyName = "Nationa"
        Me.Nationa_D.HeaderText = "الجنسية"
        Me.Nationa_D.Name = "Nationa_D"
        Me.Nationa_D.ReadOnly = True
        '
        'Address_D
        '
        Me.Address_D.DataPropertyName = "Address"
        Me.Address_D.HeaderText = "العنوان"
        Me.Address_D.Name = "Address_D"
        Me.Address_D.ReadOnly = True
        '
        'Phone_D
        '
        Me.Phone_D.DataPropertyName = "Phone"
        Me.Phone_D.HeaderText = "الهاتف"
        Me.Phone_D.Name = "Phone_D"
        Me.Phone_D.ReadOnly = True
        '
        'Email_D
        '
        Me.Email_D.DataPropertyName = "Email"
        Me.Email_D.HeaderText = "الايميل"
        Me.Email_D.Name = "Email_D"
        Me.Email_D.ReadOnly = True
        '
        'D_O_D_A_D
        '
        Me.D_O_D_A_D.DataPropertyName = "Data_of_direct_action"
        Me.D_O_D_A_D.HeaderText = "ت/مباشرة العمل"
        Me.D_O_D_A_D.Name = "D_O_D_A_D"
        Me.D_O_D_A_D.ReadOnly = True
        '
        'D_O_O_W_D
        '
        Me.D_O_O_W_D.DataPropertyName = "Data_of_original_work"
        Me.D_O_O_W_D.HeaderText = "ت/مباشرة العمل ص"
        Me.D_O_O_W_D.Name = "D_O_O_W_D"
        Me.D_O_O_W_D.ReadOnly = True
        '
        'A_L_B_D
        '
        Me.A_L_B_D.DataPropertyName = "Annual_leave_balance"
        Me.A_L_B_D.HeaderText = "ر/الاجازات س"
        Me.A_L_B_D.Name = "A_L_B_D"
        Me.A_L_B_D.ReadOnly = True
        '
        'E_L_B_D
        '
        Me.E_L_B_D.DataPropertyName = "Emergency_leave_balance"
        Me.E_L_B_D.HeaderText = "ر/ الاجازات ط"
        Me.E_L_B_D.Name = "E_L_B_D"
        Me.E_L_B_D.ReadOnly = True
        '
        'Job_Id_D
        '
        Me.Job_Id_D.DataPropertyName = "Job_Id"
        Me.Job_Id_D.HeaderText = "رقم الوظيفة"
        Me.Job_Id_D.Name = "Job_Id_D"
        Me.Job_Id_D.ReadOnly = True
        '
        'F_L_Id_D
        '
        Me.F_L_Id_D.DataPropertyName = "Fun_level_id"
        Me.F_L_Id_D.HeaderText = "ر/المستوي الوظيفي"
        Me.F_L_Id_D.Name = "F_L_Id_D"
        Me.F_L_Id_D.ReadOnly = True
        '
        'F_D_Id_D
        '
        Me.F_D_Id_D.DataPropertyName = "Fun_Deg_id"
        Me.F_D_Id_D.HeaderText = "الدرجة"
        Me.F_D_Id_D.Name = "F_D_Id_D"
        Me.F_D_Id_D.ReadOnly = True
        '
        'Cer_Id_D
        '
        Me.Cer_Id_D.DataPropertyName = "Cer_Id"
        Me.Cer_Id_D.HeaderText = "ر/وثيقة التخرج"
        Me.Cer_Id_D.Name = "Cer_Id_D"
        Me.Cer_Id_D.ReadOnly = True
        '
        'Spec_ID_D
        '
        Me.Spec_ID_D.DataPropertyName = "Spec_id"
        Me.Spec_ID_D.HeaderText = "التخصص"
        Me.Spec_ID_D.Name = "Spec_ID_D"
        Me.Spec_ID_D.ReadOnly = True
        '
        'Qual_Id_D
        '
        Me.Qual_Id_D.DataPropertyName = "Qual_Id"
        Me.Qual_Id_D.HeaderText = "المؤهل"
        Me.Qual_Id_D.Name = "Qual_Id_D"
        Me.Qual_Id_D.ReadOnly = True
        '
        'Costing_D
        '
        Me.Costing_D.DataPropertyName = "Costing"
        Me.Costing_D.HeaderText = "التقدير"
        Me.Costing_D.Name = "Costing_D"
        Me.Costing_D.ReadOnly = True
        '
        'Getting_Date_D
        '
        Me.Getting_Date_D.DataPropertyName = "Getting_Date"
        Me.Getting_Date_D.HeaderText = "ت/الاصدار"
        Me.Getting_Date_D.Name = "Getting_Date_D"
        Me.Getting_Date_D.ReadOnly = True
        '
        'Country_D
        '
        Me.Country_D.DataPropertyName = "Country"
        Me.Country_D.HeaderText = "م/جهة الاصدار"
        Me.Country_D.Name = "Country_D"
        Me.Country_D.ReadOnly = True
        '
        'Dep_Id_Emp_D
        '
        Me.Dep_Id_Emp_D.DataPropertyName = "Dep_Id"
        Me.Dep_Id_Emp_D.HeaderText = "رقم القسم"
        Me.Dep_Id_Emp_D.Name = "Dep_Id_Emp_D"
        Me.Dep_Id_Emp_D.ReadOnly = True
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.Emp_P)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.HotTrack = True
        Me.TabControl1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.TabControl1.Location = New System.Drawing.Point(-2, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TabControl1.RightToLeftLayout = True
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.ShowToolTips = True
        Me.TabControl1.Size = New System.Drawing.Size(1243, 843)
        Me.TabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl1.TabIndex = 3
        '
        'Home
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1243, 749)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Home"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.RightToLeftLayout = True
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "الشاشة الرئسية"
        Me.TopMost = True
        Me.TabPage6.ResumeLayout(False)
        Me.TabControl6.ResumeLayout(False)
        Me.TabPage15.ResumeLayout(False)
        Me.TabPage15.PerformLayout()
        Me.Panal_User.ResumeLayout(False)
        Me.Panal_User.PerformLayout()
        CType(Me.dgvuser, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage16.ResumeLayout(False)
        Me.GroupBox11.ResumeLayout(False)
        CType(Me.dgvS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox10.ResumeLayout(False)
        CType(Me.dgvD, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox9.ResumeLayout(False)
        CType(Me.dgvLJ, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox8.ResumeLayout(False)
        CType(Me.dgvJ, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        CType(Me.dgvTH, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        CType(Me.dgvQl, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.dgvPl, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.TabControl5.ResumeLayout(False)
        Me.TabPage13.ResumeLayout(False)
        Me.TabPage13.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        CType(Me.dgvCourses, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage14.ResumeLayout(False)
        Me.TabPage14.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        CType(Me.DataGridView7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabControl4.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.dgv_Mang, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panal_Mang.ResumeLayout(False)
        Me.Panal_Mang.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.panal_Dep.ResumeLayout(False)
        Me.panal_Dep.PerformLayout()
        CType(Me.dgvDep, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabControl3.ResumeLayout(False)
        Me.TabPage10.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.TabPage11.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.TabPage12.ResumeLayout(False)
        Me.TabPage12.PerformLayout()
        CType(Me.dgvHoli_Emp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Emp_P.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TabEmp.ResumeLayout(False)
        Me.TabFamily.ResumeLayout(False)
        Me.TabFamily.PerformLayout()
        CType(Me.dgvFamily_Emp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabcase_Emp.ResumeLayout(False)
        Me.tabcase_Emp.PerformLayout()
        CType(Me.dgvCaseEmp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.dgvEmp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabControl3 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage10 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtEmp_name_H As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtEmp_id_H As System.Windows.Forms.TextBox
    Friend WithEvents txtDay_Emergency_H As System.Windows.Forms.TextBox
    Friend WithEvents txtDay_Annual_H As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents L_D_H_A As System.Windows.Forms.Label
    Friend WithEvents CM_H_type_A As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents H_start_A As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TabPage11 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtEmp_name_E As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtEmp_id_E As System.Windows.Forms.TextBox
    Friend WithEvents txtDay_Emergency_E As System.Windows.Forms.TextBox
    Friend WithEvents txtDay_Annual_E As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents L_D_H_E As System.Windows.Forms.Label
    Friend WithEvents CM_H_type_E As System.Windows.Forms.ComboBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents H_end_E As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents H_start_E As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents TabPage12 As System.Windows.Forms.TabPage
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txt_H As System.Windows.Forms.TextBox
    Friend WithEvents dgvHoli_Emp As System.Windows.Forms.DataGridView
    Friend WithEvents Emp_P As System.Windows.Forms.TabPage
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_Emp As System.Windows.Forms.TextBox
    Friend WithEvents dgvEmp As System.Windows.Forms.DataGridView
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabControl4 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Panal_Mang As System.Windows.Forms.Panel
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents txt_Name_Mang As System.Windows.Forms.TextBox
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents txt_mang As System.Windows.Forms.TextBox
    Friend WithEvents dgv_Mang As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents panal_Dep As System.Windows.Forms.Panel
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents D_O_D As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents CM_M_To_D As System.Windows.Forms.ComboBox
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents txt_Name_Dep As System.Windows.Forms.TextBox
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents txt_dep As System.Windows.Forms.TextBox
    Friend WithEvents dgvDep As System.Windows.Forms.DataGridView
    Friend WithEvents TabControl5 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage13 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage14 As System.Windows.Forms.TabPage
    Friend WithEvents TabControl6 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage15 As System.Windows.Forms.TabPage
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents txt_U As System.Windows.Forms.TextBox
    Friend WithEvents dgvuser As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage16 As System.Windows.Forms.TabPage
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents TextBox34 As System.Windows.Forms.TextBox
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker14 As System.Windows.Forms.DateTimePicker
    Friend WithEvents TextBox33 As System.Windows.Forms.TextBox
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker13 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents TextBox32 As System.Windows.Forms.TextBox
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents txt_C As System.Windows.Forms.TextBox
    Friend WithEvents dgvCourses As System.Windows.Forms.DataGridView
    Friend WithEvents Button28 As System.Windows.Forms.Button
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents TextBox37 As System.Windows.Forms.TextBox
    Friend WithEvents Label101 As System.Windows.Forms.Label
    Friend WithEvents Label99 As System.Windows.Forms.Label
    Friend WithEvents ComboBox24 As System.Windows.Forms.ComboBox
    Friend WithEvents Button29 As System.Windows.Forms.Button
    Friend WithEvents Button30 As System.Windows.Forms.Button
    Friend WithEvents TextBox36 As System.Windows.Forms.TextBox
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents Button31 As System.Windows.Forms.Button
    Friend WithEvents Button32 As System.Windows.Forms.Button
    Friend WithEvents Label97 As System.Windows.Forms.Label
    Friend WithEvents txt_T As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView7 As System.Windows.Forms.DataGridView
    Friend WithEvents Button38 As System.Windows.Forms.Button
    Friend WithEvents Button33 As System.Windows.Forms.Button
    Friend WithEvents Panal_User As System.Windows.Forms.Panel
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents CO_User_Adj As System.Windows.Forms.ComboBox
    Friend WithEvents txt_User_email As System.Windows.Forms.TextBox
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents txt_User_pass As System.Windows.Forms.TextBox
    Friend WithEvents Label104 As System.Windows.Forms.Label
    Friend WithEvents Button34 As System.Windows.Forms.Button
    Friend WithEvents Button35 As System.Windows.Forms.Button
    Friend WithEvents txt_U_n As System.Windows.Forms.TextBox
    Friend WithEvents Label106 As System.Windows.Forms.Label
    Friend WithEvents Button36 As System.Windows.Forms.Button
    Friend WithEvents Button37 As System.Windows.Forms.Button
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Button41 As System.Windows.Forms.Button
    Friend WithEvents Button42 As System.Windows.Forms.Button
    Friend WithEvents Button39 As System.Windows.Forms.Button
    Friend WithEvents Button40 As System.Windows.Forms.Button
    Friend WithEvents dgvPl As System.Windows.Forms.DataGridView
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents Button43 As System.Windows.Forms.Button
    Friend WithEvents Button44 As System.Windows.Forms.Button
    Friend WithEvents dgvQl As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dgvTH As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents dgvD As System.Windows.Forms.DataGridView
    Friend WithEvents Button49 As System.Windows.Forms.Button
    Friend WithEvents Button50 As System.Windows.Forms.Button
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents dgvLJ As System.Windows.Forms.DataGridView
    Friend WithEvents Button47 As System.Windows.Forms.Button
    Friend WithEvents Button48 As System.Windows.Forms.Button
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents dgvJ As System.Windows.Forms.DataGridView
    Friend WithEvents Button45 As System.Windows.Forms.Button
    Friend WithEvents Button46 As System.Windows.Forms.Button
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents dgvS As System.Windows.Forms.DataGridView
    Friend WithEvents Button51 As System.Windows.Forms.Button
    Friend WithEvents Button52 As System.Windows.Forms.Button
    Friend WithEvents Mang_Id_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Mang_Name_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TabPage18 As System.Windows.Forms.TabPage
    Friend WithEvents Dep_Id_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Dep_Name_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Dep_O_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Mang_Id_Dep As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ID_H_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents H_Id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents H_Period_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents H_Start As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents H_End_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Emp_Id_H_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Emp_Id_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Emp_Name_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Emp_M_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Conf_Type_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Conf_Id_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Emp_NW_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Birth_Date_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Birth_Place_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Social_Case_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Gender_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Nationa_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Address_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Phone_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Email_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents D_O_D_A_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents D_O_O_W_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents A_L_B_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents E_L_B_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Job_Id_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents F_L_Id_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents F_D_Id_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cer_Id_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Spec_ID_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Qual_Id_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Costing_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Getting_Date_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Country_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Dep_Id_Emp_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents H_end_A As System.Windows.Forms.DateTimePicker
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents txt_Dep_Id_A As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txt_Mane_Id_A As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TabEmp As System.Windows.Forms.TabControl
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents btnDelet_Emp As System.Windows.Forms.Button
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents CM_Dep_Id As System.Windows.Forms.ComboBox
    Friend WithEvents CM_Country As System.Windows.Forms.ComboBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Getting_Date As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnexit_Emp As System.Windows.Forms.Button
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents CM_Costing As System.Windows.Forms.ComboBox
    Friend WithEvents btnadd_Emp As System.Windows.Forms.Button
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents CM_Qual_Id As System.Windows.Forms.ComboBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents CM_Spec_Id As System.Windows.Forms.ComboBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Cer_Id As System.Windows.Forms.TextBox
    Friend WithEvents CM_L_J_Id As System.Windows.Forms.ComboBox
    Friend WithEvents CM_Job_Id As System.Windows.Forms.ComboBox
    Friend WithEvents Annual_L_Balance As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents D_O_D_A As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents CM_F_Deg_Id As System.Windows.Forms.ComboBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents E_L_Balance As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents D_O_O_W As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents CM_Birth_Place As System.Windows.Forms.ComboBox
    Friend WithEvents Conf_Id As System.Windows.Forms.TextBox
    Friend WithEvents Emp_Id As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Email As System.Windows.Forms.TextBox
    Friend WithEvents Emp_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Phone As System.Windows.Forms.TextBox
    Friend WithEvents Emp_M As System.Windows.Forms.TextBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Address As System.Windows.Forms.TextBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Emp_NW As System.Windows.Forms.TextBox
    Friend WithEvents Nationa As System.Windows.Forms.TextBox
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Conf_Type As System.Windows.Forms.ComboBox
    Friend WithEvents CM_Gender As System.Windows.Forms.ComboBox
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Birth_Data As System.Windows.Forms.DateTimePicker
    Friend WithEvents CM_Social_Case As System.Windows.Forms.ComboBox
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents TabFamily As System.Windows.Forms.TabPage
    Friend WithEvents Button53 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents dgvFamily_Emp As System.Windows.Forms.DataGridView
    Friend WithEvents family_NW_dg As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents family_Name_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents family_Adjective_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents family_Gender_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents family_Nationa_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents family_Birth_Date_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents family_Birth_Place_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents family_Emp_Id_D As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents tabcase_Emp As System.Windows.Forms.TabPage
    Friend WithEvents btnedit_Emp As System.Windows.Forms.Button
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents dgvCaseEmp As System.Windows.Forms.DataGridView
    Friend WithEvents Case_Emp_id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Case_Id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Date_End_Emp As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Reason As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Cours_Id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cours_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents M_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cours_Start As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cours_End As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Period As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents User_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents User_Pass As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents User_Email As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Adjective As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
