﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Form1
    Dim con As SqlConnection = New SqlConnection("Data Source=DESKTOP-65D1KO0\SQLSERVE2012;Initial Catalog=forgotvb;Integrated Security=True")
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        Dim cmd As SqlCommand = New SqlCommand("select * from loginforget where username ='" + txtUser.Text + "' and password ='" + txtPass.Text + "'", con)
        Dim sda As SqlDataAdapter = New SqlDataAdapter(cmd)
        Dim dt As DataTable = New DataTable()
        sda.Fill(dt)
        If (dt.Rows.Count > 0) Then
            MessageBox.Show("تم تسجيل الدخول بنجاح")
        Else
            MessageBox.Show("هناك خطأ ")
        End If
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Dim sc As SendCode = New SendCode()
        sc.Show()
        Dim f As Form1 = New Form1()
        f.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Close()

    End Sub
End Class
