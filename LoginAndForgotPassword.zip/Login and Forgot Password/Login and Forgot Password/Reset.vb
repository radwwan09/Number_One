﻿Imports System.Data
Imports System.Data.SqlClient


Public Class Reset

    Dim username As String = SendCode.toUser
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim con As SqlConnection = New SqlConnection("Data Source=DESKTOP-65D1KO0\SQLSERVE2012;Initial Catalog=forgotvb;Integrated Security=True")

        Dim cmd As SqlCommand = New SqlCommand("UPDATE [dbo].[loginforget]  SET [username] = '" + username + "',   ,[password] = '" + txtVerNewPass.Text + "' WHERE [username] = '" + username + "'", con)



        con.Open()
        cmd.ExecuteNonQuery()
        MessageBox.Show("أعيد تعيين كلمة المرور بنجاح ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)


        con.Close()



    End Sub
End Class